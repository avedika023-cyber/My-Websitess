export type DestinationCategory =
  | 'All'
  | 'City & Culture'
  | 'Beach & Tropics'
  | 'Alpine & Mountains';

export interface Destination {
  id: string;
  name: string;
  country: string;
  locationLabel: string;
  category: Exclude<DestinationCategory, 'All'>;
  shortDescription: string;
  fullDescription: string;
  bestTime: string;
  suggestedDays: number;
  startingPrice: number;
  climate: string;
  currency: string;
  highlights: string[];
  image: string;
}

export interface TravelPackage {
  id: string;
  title: string;
  destination: string;
  days: number;
  nights: number;
  price: number;
  summary: string;
  includes: string[];
  image: string;
}

export interface Hotel {
  id: string;
  name: string;
  location: string;
  destinationName: string;
  rating: number;
  reviewCount: number;
  pricePerNight: number;
  shortDescription: string;
  fullDescription: string;
  roomType: string;
  amenities: string[];
  image: string;
}

export interface WhyChooseUsItem {
  number: string;
  title: string;
  description: string;
}

export interface TravelTip {
  id: string;
  topic: string;
  readTime: string;
  title: string;
  summary: string;
}

export const HERO_IMAGE = '/src/assets/images/hero_wanderly_coast_1795613593910.jpg';

export const DESTINATIONS: Destination[] = [
  {
    id: 'paris',
    name: 'Paris',
    country: 'France',
    locationLabel: 'Paris, France',
    category: 'City & Culture',
    shortDescription:
      'Sunlit boulevards, riverside bookstalls, world-class art collections, and intimate neighborhood bistros.',
    fullDescription:
      'Spend unhurried mornings in Saint-Germain cafés, walk across historic limestone bridges along the Seine, and explore hidden courtyard galleries in Le Marais. From golden-hour views near the Eiffel Tower to late-evening brasseries, Paris rewards travelers who wander on foot.',
    bestTime: 'April – October',
    suggestedDays: 5,
    startingPrice: 1290,
    climate: 'Temperate · 14°C – 25°C',
    currency: 'Euro (EUR)',
    highlights: [
      'Private sunrise Seine river walk & Île Saint-Louis cafés',
      'Skip-the-line museum passes for Louvre & Musée d’Orsay',
      'Artisan patisserie & market tasting in Le Marais',
      'Evening architectural cruise at twilight',
    ],
    image: '/src/assets/images/dest_paris_1795613594747.jpg',
  },
  {
    id: 'dubai',
    name: 'Dubai',
    country: 'United Arab Emirates',
    locationLabel: 'Dubai, UAE',
    category: 'City & Culture',
    shortDescription:
      'Futuristic waterfront towers, golden desert dunes, traditional spice souks, and serene marina evenings.',
    fullDescription:
      'Experience striking contrasts between sleek modern architecture along Dubai Marina and the quiet wind-sculpted dunes of the Arabian desert. Glide across Dubai Creek in a wooden abra, dine beside illuminated fountains, and unwind at private Gulf beachfront retreats.',
    bestTime: 'November – March',
    suggestedDays: 4,
    startingPrice: 1150,
    climate: 'Arid Sunny · 22°C – 32°C',
    currency: 'UAE Dirham (AED)',
    highlights: [
      'Twilight yacht cruise through Dubai Marina skyline',
      'Al Fahidi historical district & traditional spice souks',
      'Late-afternoon desert conservation drive & stargazing dinner',
      'Observatory deck access overlooking Downtown Dubai',
    ],
    image: '/src/assets/images/dest_dubai_1795613594271.jpg',
  },
  {
    id: 'goa',
    name: 'Goa',
    country: 'India',
    locationLabel: 'Goa, India',
    category: 'Beach & Tropics',
    shortDescription:
      'Palm-lined golden coves, Portuguese-era heritage lanes, coastal spice kitchens, and unhurried sunsets.',
    fullDescription:
      'From quiet southern bays framed by coconut groves to heritage Latin Quarter alleys in Fontainhas, Goa moves at an effortless coastal rhythm. Spend days swimming in warm Arabian Sea waters and evenings enjoying fresh catch spiced with kokum and roasted coconut.',
    bestTime: 'November – February',
    suggestedDays: 4,
    startingPrice: 540,
    climate: 'Tropical Coastal · 24°C – 31°C',
    currency: 'Indian Rupee (INR)',
    highlights: [
      'Guided heritage walk through Fontainhas pastel lanes',
      'Calm sunrise kayak along palm-shaded backwaters',
      'Sunset beachfront dining in South Goa coves',
      'Organic spice plantation tour in the Sahyadri foothills',
    ],
    image: '/src/assets/images/dest_goa_1795613595674.jpg',
  },
  {
    id: 'bali',
    name: 'Bali',
    country: 'Indonesia',
    locationLabel: 'Bali, Indonesia',
    category: 'Beach & Tropics',
    shortDescription:
      'Emerald terraced rice valleys, cliffside sea temples, serene wellness sanctuaries, and reef coastlines.',
    fullDescription:
      'Discover Bali beyond the guidebooks—wake to morning mist rising over Ubud’s emerald terraces, visit centuries-old water temples, and spend afternoons snorkeling clear coral lagoons in Nusa Lembongan before returning to open-air teak villas.',
    bestTime: 'May – September',
    suggestedDays: 6,
    startingPrice: 890,
    climate: 'Tropical Warm · 25°C – 30°C',
    currency: 'Indonesian Rupiah (IDR)',
    highlights: [
      'Early-morning walk through Tegalalang & Sidemen terraces',
      'Traditional Balinese purification ceremony & botanical spa',
      'Sunset cliffside visit at Uluwatu ocean sanctuary',
      'Full-day catamaran trip to Nusa Penida coves',
    ],
    image: '/src/assets/images/dest_bali_1795613596048.jpg',
  },
  {
    id: 'switzerland',
    name: 'Switzerland',
    country: 'Switzerland',
    locationLabel: 'Interlaken & Zermatt, Switzerland',
    category: 'Alpine & Mountains',
    shortDescription:
      'Glacial turquoise lakes, panoramic alpine rail routes, timber chalet villages, and crisp mountain air.',
    fullDescription:
      'Board panoramic express trains winding past dramatic limestone peaks and crystal mountain lakes. Whether hiking flower-filled meadows above Lauterbrunnen or taking a mountain cogwheel railway toward snow-draped summits, Switzerland delivers effortless alpine precision.',
    bestTime: 'June – September & December – March',
    suggestedDays: 7,
    startingPrice: 1890,
    climate: 'Alpine Crisp · 4°C – 21°C',
    currency: 'Swiss Franc (CHF)',
    highlights: [
      'First-class panoramic rail pass across alpine valleys',
      'Glacier viewpoint excursion & cogwheel summit ride',
      'Lake Brienz boat crossing & lakeside promenade stroll',
      'Traditional alpine cheese & artisan chocolate workshop',
    ],
    image: '/src/assets/images/dest_switzerland_1795613595623.jpg',
  },
  {
    id: 'manali',
    name: 'Manali',
    country: 'India',
    locationLabel: 'Manali, Himachal Pradesh',
    category: 'Alpine & Mountains',
    shortDescription:
      'Cedar pine forests, snow-rimmed Himalayan passes, rushing glacial rivers, and cozy mountain timber stays.',
    fullDescription:
      'Tucked high in the Kullu Valley, Manali pairs crisp cedar-scented mountain trails with roaring glacial streams. Cross the scenic Rohtang corridor into stark high-altitude valleys, warm up beside stone hearths in Old Manali, and wake to sunlit Himalayan ridges.',
    bestTime: 'March – June & October – January',
    suggestedDays: 5,
    startingPrice: 460,
    climate: 'Himalayan Cool · 2°C – 20°C',
    currency: 'Indian Rupee (INR)',
    highlights: [
      'Guided pine-ridge hike to Jogini Waterfall & Vashisht',
      'Scenic drive through Solang Valley & Atal Tunnel',
      'Riverside café afternoon in Old Manali lanes',
      'Apple orchard stay with locally sourced Himachali meals',
    ],
    image: '/src/assets/images/dest_manali_1795613597152.jpg',
  },
];

export const TRAVEL_PACKAGES: TravelPackage[] = [
  {
    id: 'pkg-paris',
    title: 'Parisian Art & Riverfront Escape',
    destination: 'Paris',
    days: 5,
    nights: 4,
    price: 1450,
    summary:
      'Boutique Left Bank stay, guided Louvre & Orsay access, Seine twilight cruise, and neighborhood market tasting.',
    includes: ['4 Nights Boutique Hotel', 'Daily Breakfast', 'Museum Priority Entry', 'Airport Transfers'],
    image: '/src/assets/images/dest_paris_1795613594747.jpg',
  },
  {
    id: 'pkg-bali',
    title: 'Ubud Terraces & Coastal Calm',
    destination: 'Bali',
    days: 6,
    nights: 5,
    price: 1090,
    summary:
      'Three nights amid emerald Ubud rice valleys followed by two coastal nights on the Bukit Peninsula.',
    includes: ['5 Nights Villa Stay', 'Private Island Driver', 'Snorkeling Excursion', 'Spa Ritual'],
    image: '/src/assets/images/dest_bali_1795613596048.jpg',
  },
  {
    id: 'pkg-swiss',
    title: 'Swiss Alpine Rail & Peaks',
    destination: 'Switzerland',
    days: 7,
    nights: 6,
    price: 2190,
    summary:
      'Seamless scenic rail journey connecting Lucerne, Interlaken, and Zermatt with mountain excursions included.',
    includes: ['6 Nights Alpine Chalet', 'Swiss Travel Pass', 'Summit Cable Car', 'Lake Cruise'],
    image: '/src/assets/images/dest_switzerland_1795613595623.jpg',
  },
  {
    id: 'pkg-dubai',
    title: 'Dubai Skyline & Desert Horizon',
    destination: 'Dubai',
    days: 4,
    nights: 3,
    price: 1280,
    summary:
      'Marina waterfront suite paired with an evening desert conservation safari and historic creek tour.',
    includes: ['3 Nights Marina Hotel', 'Desert Dinner Safari', 'Marina Yacht Cruise', 'Private Transfers'],
    image: '/src/assets/images/dest_dubai_1795613594271.jpg',
  },
  {
    id: 'pkg-goa',
    title: 'South Goa Shoreline Retreat',
    destination: 'Goa',
    days: 4,
    nights: 3,
    price: 620,
    summary:
      'Laid-back palm-grove resort stay with heritage Fontainhas walking tour and private backwater kayaking.',
    includes: ['3 Nights Beach Resort', 'Coastal Breakfasts', 'Heritage Tour', 'Sunset Kayaking'],
    image: '/src/assets/images/dest_goa_1795613595674.jpg',
  },
  {
    id: 'pkg-manali',
    title: 'Himalayan Pine & River Trail',
    destination: 'Manali',
    days: 5,
    nights: 4,
    price: 540,
    summary:
      'Cozy timber lodge in Old Manali with guided mountain valley trails, Solang ridge views, and fireside dining.',
    includes: ['4 Nights Timber Lodge', 'Guided Valley Hikes', 'Local Cab Transfers', 'Breakfast & Dinner'],
    image: '/src/assets/images/dest_manali_1795613597152.jpg',
  },
];

export const HOTELS: Hotel[] = [
  {
    id: 'hotel-orangerie',
    name: 'Hôtel L’Orangerie Marais',
    location: 'Le Marais, Paris',
    destinationName: 'Paris',
    rating: 4.9,
    reviewCount: 418,
    pricePerNight: 320,
    shortDescription:
      'Restored 18th-century limestone townhouse with a serene olive-tree courtyard just steps from the Seine.',
    fullDescription:
      'Tucked behind arched carriage doors in Paris’s 3rd arrondissement, Hôtel L’Orangerie blends classic tall French windows, oak herringbone floors, and quiet garden breakfasts away from city bustle.',
    roomType: 'Courtyard Deluxe King',
    amenities: [
      'Private limestone courtyard dining',
      'Artisan morning croissant & espresso service',
      'High-speed fiber Wi-Fi & workspace',
      '24-hour neighborhood concierge',
    ],
    image: '/src/assets/images/hotel_urban_palace_1795613597911.jpg',
  },
  {
    id: 'hotel-vela',
    name: 'Vela Shoreline Sanctuary',
    location: 'Agonda Cove, Goa',
    destinationName: 'Goa',
    rating: 4.8,
    reviewCount: 286,
    pricePerNight: 215,
    shortDescription:
      'Sun-washed coastal villas and limestone infinity pool opening directly onto golden Arabian Sea sands.',
    fullDescription:
      'Designed around coastal breezes and natural travertine stone, Vela Shoreline Sanctuary offers panoramic horizon views, open-air seafood dining, and quiet beachfront cabanas.',
    roomType: 'Oceanfront Infinity Suite',
    amenities: [
      'Heated horizon infinity pool',
      'Direct private beach access',
      'Daily coastal yoga & wellness pavilion',
      'Complimentary airport chauffeur',
    ],
    image: '/src/assets/images/hotel_coastal_resort_1795613596607.jpg',
  },
  {
    id: 'hotel-ridgewood',
    name: 'The Ridgewood Alpine Chalet',
    location: 'Zermatt Valley, Switzerland',
    destinationName: 'Switzerland',
    rating: 4.9,
    reviewCount: 354,
    pricePerNight: 445,
    shortDescription:
      'Warm oak-beamed suites with stone hearths and floor-to-ceiling glass framing snow-covered Swiss peaks.',
    fullDescription:
      'Perched quietly above the car-free village of Zermatt, The Ridgewood pairs timber craftsmanship with private mountain balconies, thermal cedar saunas, and ski-in trail access.',
    roomType: 'Panoramic Peak Hearth Suite',
    amenities: [
      'Wood-burning stone fireplace in every suite',
      'Alpine thermal spa & cedar sauna',
      'Complimentary electric station shuttle',
      'Farm-to-table mountain breakfast included',
    ],
    image: '/src/assets/images/hotel_alpine_lodge_1795613597046.jpg',
  },
];

export const WHY_CHOOSE_US: WhyChooseUsItem[] = [
  {
    number: '01',
    title: 'Safe Travel',
    description:
      'Every partner hotel, regional driver, and local guide is personally vetted against strict safety, licensing, and hygiene benchmarks before entering our catalog.',
  },
  {
    number: '02',
    title: 'Best Prices',
    description:
      'Direct contracts with boutique stays and regional operators eliminate middleman markups, giving you transparent pricing with zero hidden booking fees.',
  },
  {
    number: '03',
    title: 'Easy Booking',
    description:
      'Reserve custom packages or individual stays in minutes with flexible date changes and clear cancellation policies outlined up front.',
  },
  {
    number: '04',
    title: '24/7 Support',
    description:
      'Real travel specialists remain reachable around the clock for flight adjustments, local recommendations, or unexpected itinerary updates.',
  },
];

export const TRAVEL_TIPS: TravelTip[] = [
  {
    id: 'tip-packing',
    topic: 'Preparation',
    readTime: '3 min read',
    title: 'Pack in Breathable Layers for Mountain-to-Coast Trips',
    summary:
      'Destinations like Manali or Switzerland shift rapidly between sunlit valleys and crisp evening ridges. Merino base layers and a packable shell keep luggage light without sacrificing warmth.',
  },
  {
    id: 'tip-shoulder',
    topic: 'Planning',
    readTime: '4 min read',
    title: 'Target Shoulder Months for Quieter Landmarks & Better Rates',
    summary:
      'Visiting Paris in late April or Bali in May gives you mild dry weather, shorter museum lines, and up to 30% lower nightly rates on boutique properties.',
  },
  {
    id: 'tip-transit',
    topic: 'Logistics',
    readTime: '2 min read',
    title: 'Download Offline Maps & Local Rail Passes Before Departure',
    summary:
      'Saving offline city areas and loading transit cards—like Swiss Half Fare passes or Paris Navigo passes—before landing saves an hour at arrival terminals.',
  },
  {
    id: 'tip-currency',
    topic: 'Budgeting',
    readTime: '3 min read',
    title: 'Pay in Local Currency & Keep Small Notes for Markets',
    summary:
      'When paying by card abroad, always select the local currency rather than home-currency conversion to avoid hidden exchange spreads, and carry small bills for village cafés.',
  },
];
