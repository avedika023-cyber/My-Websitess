/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { ContactSection } from './components/ContactSection';
import { DestinationSection } from './components/DestinationSection';
import { Footer } from './components/Footer';
import { HeroSection } from './components/HeroSection';
import { HotelsSection } from './components/HotelsSection';
import {
  BookingInitialContext,
  BookingModal,
  DestinationDetailModal,
  HotelDetailModal,
} from './components/Modals';
import { Navbar } from './components/Navbar';
import { PackagesSection } from './components/PackagesSection';
import { TravelTipsSection } from './components/TravelTipsSection';
import { WhyChooseUsSection } from './components/WhyChooseUsSection';
import {
  Destination,
  DestinationCategory,
  Hotel,
  TravelPackage,
} from './data/travelData';

const FAVORITES_STORAGE_KEY = 'wanderly_saved_destinations';

export default function App() {
  const [searchInput, setSearchInput] = useState('');
  const [activeSearchQuery, setActiveSearchQuery] = useState('');
  const [travelDate, setTravelDate] = useState('');
  const [travelers, setTravelers] = useState('2');
  const [selectedCategory, setSelectedCategory] = useState<
    DestinationCategory | 'Saved'
  >('All');

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(FAVORITES_STORAGE_KEY);
      return stored ? (JSON.parse(stored) as string[]) : [];
    } catch {
      return [];
    }
  });

  const [exploredDestination, setExploredDestination] =
    useState<Destination | null>(null);
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [bookingContext, setBookingContext] = useState<BookingInitialContext>({
    destination: 'Paris',
    date: '',
    travelers: '2',
  });

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
    } catch {
      // Ignore storage errors in restricted environments
    }
  }, [favorites]);

  const handleToggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleHeroSearch = () => {
    setActiveSearchQuery(searchInput);
    setSelectedCategory('All');
    const destSection = document.getElementById('destinations');
    if (destSection) {
      destSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleClearSearch = () => {
    setSearchInput('');
    setActiveSearchQuery('');
  };

  const openBookingModal = (
    destinationName?: string,
    packageTitle?: string
  ) => {
    setBookingContext({
      destination: destinationName || 'Paris',
      date: travelDate,
      travelers,
      packageTitle,
    });
    setBookingOpen(true);
  };

  const handleBookPackage = (pkg: TravelPackage) => {
    openBookingModal(pkg.destination, `${pkg.title} (${pkg.days} Days)`);
  };

  const handleBookFromDestination = (destinationName: string) => {
    setExploredDestination(null);
    openBookingModal(destinationName);
  };

  const handleBookFromHotel = (hotel: Hotel) => {
    setSelectedHotel(null);
    openBookingModal(hotel.destinationName, hotel.name);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar onOpenBooking={() => openBookingModal()} />

      <main>
        <HeroSection
          searchDestination={searchInput}
          travelDate={travelDate}
          travelers={travelers}
          onChangeDestination={(val) => {
            setSearchInput(val);
            setActiveSearchQuery(val);
          }}
          onChangeDate={setTravelDate}
          onChangeTravelers={setTravelers}
          onSearchSubmit={handleHeroSearch}
        />

        <DestinationSection
          searchQuery={activeSearchQuery}
          selectedCategory={selectedCategory}
          favorites={favorites}
          onSelectCategory={setSelectedCategory}
          onClearSearch={handleClearSearch}
          onToggleFavorite={handleToggleFavorite}
          onExplore={setExploredDestination}
        />

        <PackagesSection onBookPackage={handleBookPackage} />

        <HotelsSection onViewHotel={setSelectedHotel} />

        <WhyChooseUsSection />

        <TravelTipsSection />

        <ContactSection />
      </main>

      <Footer />

      <DestinationDetailModal
        destination={exploredDestination}
        onClose={() => setExploredDestination(null)}
        onBookDestination={handleBookFromDestination}
      />

      <HotelDetailModal
        hotel={selectedHotel}
        onClose={() => setSelectedHotel(null)}
        onBookHotel={handleBookFromHotel}
      />

      <BookingModal
        isOpen={bookingOpen}
        initialContext={bookingContext}
        onClose={() => setBookingOpen(false)}
      />
    </div>
  );
}
