import { FormEvent, useEffect, useState } from 'react';
import {
  Calendar,
  Check,
  CheckCircle2,
  MapPin,
  Star,
  Sun,
  Users,
  X,
} from 'lucide-react';
import { DESTINATIONS, Destination, Hotel } from '../data/travelData';
import { SafeImage } from './SafeImage';

interface DestinationModalProps {
  destination: Destination | null;
  onClose: () => void;
  onBookDestination: (destinationName: string) => void;
}

export function DestinationDetailModal({
  destination,
  onClose,
  onBookDestination,
}: DestinationModalProps) {
  useEffect(() => {
    if (!destination) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [destination, onClose]);

  if (!destination) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="dest-modal-title"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-2xl"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close destination details"
          className="absolute top-4 right-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-slate-700 shadow-sm hover:bg-white hover:text-slate-950 cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="aspect-[16/9] w-full overflow-hidden bg-slate-100">
          <SafeImage
            src={destination.image}
            alt={destination.name}
            fallbackTitle={destination.name}
            className="h-full w-full object-cover"
          />
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500">
            <span className="inline-flex items-center gap-1 text-cyan-800 font-semibold">
              <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
              {destination.locationLabel}
            </span>
            <span aria-hidden="true">·</span>
            <span>{destination.category}</span>
            <span aria-hidden="true">·</span>
            <span>{destination.suggestedDays} Days Recommended</span>
          </div>

          <h3
            id="dest-modal-title"
            className="mt-2 font-display text-3xl font-semibold text-slate-900"
          >
            {destination.name}
          </h3>

          <p className="mt-3 text-sm leading-relaxed text-slate-600 sm:text-base">
            {destination.fullDescription}
          </p>

          <div className="mt-6 grid grid-cols-1 gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 sm:grid-cols-3 text-xs">
            <div>
              <span className="block text-slate-500">Best Season</span>
              <span className="mt-1 inline-flex items-center gap-1 font-semibold text-slate-900">
                <Calendar className="h-3.5 w-3.5 text-cyan-800" aria-hidden="true" />
                {destination.bestTime}
              </span>
            </div>
            <div>
              <span className="block text-slate-500">Climate</span>
              <span className="mt-1 inline-flex items-center gap-1 font-semibold text-slate-900">
                <Sun className="h-3.5 w-3.5 text-cyan-800" aria-hidden="true" />
                {destination.climate}
              </span>
            </div>
            <div>
              <span className="block text-slate-500">Local Currency</span>
              <span className="mt-1 block font-semibold text-slate-900">
                {destination.currency}
              </span>
            </div>
          </div>

          <div className="mt-6">
            <h4 className="text-sm font-semibold text-slate-900">
              Trip Highlights
            </h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-600">
              {destination.highlights.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <Check
                    className="mt-0.5 h-4 w-4 shrink-0 text-cyan-800"
                    aria-hidden="true"
                  />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 pt-5">
            <div>
              <span className="block text-xs text-slate-500">
                Packages starting from
              </span>
              <span className="text-2xl font-semibold text-slate-900 tabular-nums">
                ${destination.startingPrice.toLocaleString()}
              </span>
            </div>

            <button
              type="button"
              onClick={() => onBookDestination(destination.name)}
              className="inline-flex min-h-[44px] items-center justify-center rounded-full bg-cyan-800 px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-cyan-900 cursor-pointer"
            >
              Book This Destination
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface HotelModalProps {
  hotel: Hotel | null;
  onClose: () => void;
  onBookHotel: (hotel: Hotel) => void;
}

export function HotelDetailModal({
  hotel,
  onClose,
  onBookHotel,
}: HotelModalProps) {
  useEffect(() => {
    if (!hotel) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [hotel, onClose]);

  if (!hotel) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="hotel-modal-title"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white shadow-2xl"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close hotel details"
          className="absolute top-4 right-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-white/95 text-slate-700 shadow-sm hover:bg-white hover:text-slate-950 cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="aspect-[16/9] w-full overflow-hidden bg-slate-100">
          <SafeImage
            src={hotel.image}
            alt={hotel.name}
            fallbackTitle={hotel.name}
            className="h-full w-full object-cover"
          />
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-medium text-slate-500">
            <span className="inline-flex items-center gap-1 text-cyan-800 font-semibold">
              <MapPin className="h-3.5 w-3.5" aria-hidden="true" />
              {hotel.location}
            </span>
            <span className="inline-flex items-center gap-1 font-semibold text-slate-900 tabular-nums">
              <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" aria-hidden="true" />
              {hotel.rating.toFixed(1)} · {hotel.reviewCount} verified reviews
            </span>
          </div>

          <h3
            id="hotel-modal-title"
            className="mt-2 font-display text-3xl font-semibold text-slate-900"
          >
            {hotel.name}
          </h3>
          <p className="mt-1 text-xs font-medium text-slate-500">
            Featured Suite: {hotel.roomType}
          </p>

          <p className="mt-3 text-sm leading-relaxed text-slate-600 sm:text-base">
            {hotel.fullDescription}
          </p>

          <div className="mt-6">
            <h4 className="text-sm font-semibold text-slate-900">
              Included Amenities
            </h4>
            <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 text-sm text-slate-600">
              {hotel.amenities.map((amenity) => (
                <li key={amenity} className="flex items-start gap-2">
                  <Check
                    className="mt-0.5 h-4 w-4 shrink-0 text-cyan-800"
                    aria-hidden="true"
                  />
                  <span>{amenity}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 pt-5">
            <div>
              <span className="text-2xl font-semibold text-slate-900 tabular-nums">
                ${hotel.pricePerNight}
              </span>
              <span className="text-xs text-slate-500"> / night</span>
            </div>

            <button
              type="button"
              onClick={() => onBookHotel(hotel)}
              className="inline-flex min-h-[44px] items-center justify-center rounded-full bg-cyan-800 px-6 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-cyan-900 cursor-pointer"
            >
              Book Stay
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export interface BookingInitialContext {
  destination: string;
  date: string;
  travelers: string;
  packageTitle?: string;
}

interface BookingModalProps {
  isOpen: boolean;
  initialContext: BookingInitialContext;
  onClose: () => void;
}

interface ConfirmedBooking {
  reference: string;
  name: string;
  destination: string;
  date: string;
  travelers: string;
  packageTitle?: string;
}

export function BookingModal({
  isOpen,
  initialContext,
  onClose,
}: BookingModalProps) {
  const [name, setName] = useState('');
  const [destination, setDestination] = useState(
    initialContext.destination || 'Paris'
  );
  const [date, setDate] = useState(initialContext.date);
  const [travelers, setTravelers] = useState(initialContext.travelers || '2');
  const [error, setError] = useState('');
  const [confirmation, setConfirmation] = useState<ConfirmedBooking | null>(
    null
  );

  useEffect(() => {
    if (isOpen) {
      setDestination(initialContext.destination || 'Paris');
      setDate(initialContext.date || '');
      setTravelers(initialContext.travelers || '2');
      setError('');
      setConfirmation(null);
    }
  }, [isOpen, initialContext]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedName = name.trim();
    if (!trimmedName) {
      setError('Please enter the primary traveler’s name.');
      return;
    }
    if (!destination) {
      setError('Please select a destination.');
      return;
    }
    if (!date) {
      setError('Please select your preferred travel date.');
      return;
    }

    const randomRef = `WND-${Math.floor(100000 + Math.random() * 900000)}`;
    setConfirmation({
      reference: randomRef,
      name: trimmedName,
      destination,
      date,
      travelers,
      packageTitle: initialContext.packageTitle,
    });
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl sm:p-8"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close booking form"
          className="absolute top-4 right-4 flex h-10 w-10 items-center justify-center rounded-full text-slate-500 hover:bg-slate-100 hover:text-slate-900 cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {confirmation ? (
          <div role="status" aria-live="polite" className="py-4 text-center">
            <CheckCircle2
              className="mx-auto h-12 w-12 text-emerald-700"
              strokeWidth={1.75}
              aria-hidden="true"
            />
            <h3
              id="booking-modal-title"
              className="mt-4 font-display text-2xl font-semibold text-slate-900"
            >
              Booking Confirmed
            </h3>
            <p className="mt-2 text-sm text-slate-600">
              Your trip request has been reserved. Keep your booking reference handy for itinerary updates.
            </p>

            <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-4 text-left text-sm space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Booking Reference</span>
                <span className="font-semibold text-cyan-800 tabular-nums">
                  {confirmation.reference}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Traveler Name</span>
                <span className="font-medium text-slate-900">
                  {confirmation.name}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Destination</span>
                <span className="font-medium text-slate-900">
                  {confirmation.destination}
                </span>
              </div>
              {confirmation.packageTitle && (
                <div className="flex items-center justify-between gap-4">
                  <span className="text-slate-500 shrink-0">Selection</span>
                  <span className="font-medium text-slate-900 text-right">
                    {confirmation.packageTitle}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Departure Date</span>
                <span className="font-medium text-slate-900 tabular-nums">
                  {confirmation.date}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Travelers</span>
                <span className="font-medium text-slate-900 tabular-nums">
                  {confirmation.travelers}{' '}
                  {confirmation.travelers === '1' ? 'Traveler' : 'Travelers'}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setName('');
                onClose();
              }}
              className="mt-6 inline-flex min-h-[44px] w-full items-center justify-center rounded-full bg-cyan-800 px-6 py-2.5 text-sm font-semibold text-white hover:bg-cyan-900 cursor-pointer"
            >
              Done
            </button>
          </div>
        ) : (
          <div>
            <p className="text-xs font-semibold text-cyan-800">
              Trip Reservation
            </p>
            <h3
              id="booking-modal-title"
              className="mt-1 font-display text-2xl font-semibold text-slate-900"
            >
              Book Your Journey
            </h3>
            {initialContext.packageTitle && (
              <p className="mt-1 text-sm text-slate-600">
                Selected: <strong className="font-semibold text-slate-900">{initialContext.packageTitle}</strong>
              </p>
            )}

            <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-4">
              <div>
                <label
                  htmlFor="booking-name"
                  className="block text-xs font-semibold text-slate-700"
                >
                  Full Name
                </label>
                <input
                  id="booking-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter your full name"
                  className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-cyan-700 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="booking-destination"
                  className="block text-xs font-semibold text-slate-700"
                >
                  Destination
                </label>
                <select
                  id="booking-destination"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 focus:border-cyan-700 focus:outline-none cursor-pointer"
                >
                  {DESTINATIONS.map((dest) => (
                    <option key={dest.id} value={dest.name}>
                      {dest.name} ({dest.country})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="booking-date"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Travel Date
                  </label>
                  <input
                    id="booking-date"
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 focus:border-cyan-700 focus:outline-none tabular-nums"
                  />
                </div>

                <div>
                  <label
                    htmlFor="booking-travelers"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    Travelers
                  </label>
                  <div className="relative mt-1.5">
                    <Users
                      className="pointer-events-none absolute top-3.5 left-3.5 h-4 w-4 text-slate-400"
                      aria-hidden="true"
                    />
                    <select
                      id="booking-travelers"
                      value={travelers}
                      onChange={(e) => setTravelers(e.target.value)}
                      className="w-full rounded-xl border border-slate-300 bg-white py-3 pr-4 pl-10 text-sm text-slate-900 focus:border-cyan-700 focus:outline-none cursor-pointer"
                    >
                      <option value="1">1 Traveler</option>
                      <option value="2">2 Travelers</option>
                      <option value="3">3 Travelers</option>
                      <option value="4">4 Travelers</option>
                      <option value="5">5+ Travelers</option>
                    </select>
                  </div>
                </div>
              </div>

              {error && (
                <p
                  role="alert"
                  className="rounded-lg bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-800 border border-rose-200"
                >
                  {error}
                </p>
              )}

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="min-h-[44px] rounded-full border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] rounded-full bg-cyan-800 px-6 py-2.5 text-sm font-semibold text-white hover:bg-cyan-900 transition-colors cursor-pointer"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
