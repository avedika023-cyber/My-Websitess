import { Check, Clock, MapPin } from 'lucide-react';
import { TRAVEL_PACKAGES, TravelPackage } from '../data/travelData';
import { SafeImage } from './SafeImage';

interface PackagesSectionProps {
  onBookPackage: (pkg: TravelPackage) => void;
}

export function PackagesSection({ onBookPackage }: PackagesSectionProps) {
  return (
    <section
      id="trips"
      className="border-y border-slate-200/80 bg-white py-16 lg:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold text-cyan-800">
            Travel Packages
          </p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl text-balance">
            Complete Multi-Day Trips Ready to Reserve
          </h2>
          <p className="mt-3 text-base leading-relaxed text-slate-600">
            Each itinerary pairs vetted accommodations, local transfers, and signature cultural experiences at one transparent price.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
          {TRAVEL_PACKAGES.map((pkg) => (
            <article
              key={pkg.id}
              className="flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-slate-50/50 transition-transform duration-200 hover:-translate-y-1"
            >
              <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
                <SafeImage
                  src={pkg.image}
                  alt={pkg.title}
                  fallbackTitle={pkg.destination}
                  className="h-full w-full object-cover"
                />
              </div>

              <div className="flex flex-1 flex-col p-6">
                {/* Unboxed metadata with typographic separator */}
                <div className="flex items-center gap-2 text-xs font-medium text-slate-500 tabular-nums">
                  <span className="inline-flex items-center gap-1 text-cyan-800">
                    <MapPin className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    {pkg.destination}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    {pkg.days} Days / {pkg.nights} Nights
                  </span>
                </div>

                <h3 className="mt-2 font-display text-xl font-semibold text-slate-900">
                  {pkg.title}
                </h3>

                <p className="mt-2 text-sm leading-relaxed text-slate-600">
                  {pkg.summary}
                </p>

                <ul className="mt-4 space-y-1.5 border-t border-slate-200/80 pt-4 text-xs text-slate-600">
                  {pkg.includes.map((item) => (
                    <li key={item} className="flex items-center gap-2">
                      <Check
                        className="h-3.5 w-3.5 shrink-0 text-cyan-800"
                        aria-hidden="true"
                      />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-6 flex items-center justify-between gap-4 border-t border-slate-200/80 pt-4">
                  <div>
                    <span className="block text-xs text-slate-500">
                      Per traveler
                    </span>
                    <span className="text-xl font-semibold text-slate-900 tabular-nums">
                      ${pkg.price.toLocaleString()}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onBookPackage(pkg)}
                    className="inline-flex min-h-[42px] items-center justify-center rounded-full bg-cyan-800 px-5 py-2 text-sm font-semibold text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-cyan-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-700 cursor-pointer"
                  >
                    Book Now
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
