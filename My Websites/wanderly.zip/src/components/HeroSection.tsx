import { FormEvent } from 'react';
import { Calendar, MapPin, Search, Users } from 'lucide-react';
import { HERO_IMAGE } from '../data/travelData';
import { SafeImage } from './SafeImage';

interface HeroSectionProps {
  searchDestination: string;
  travelDate: string;
  travelers: string;
  onChangeDestination: (val: string) => void;
  onChangeDate: (val: string) => void;
  onChangeTravelers: (val: string) => void;
  onSearchSubmit: () => void;
}

export function HeroSection({
  searchDestination,
  travelDate,
  travelers,
  onChangeDestination,
  onChangeDate,
  onChangeTravelers,
  onSearchSubmit,
}: HeroSectionProps) {
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSearchSubmit();
  };

  return (
    <section
      id="home"
      className="relative flex min-h-[580px] lg:min-h-[660px] w-full items-center overflow-hidden bg-slate-900"
    >
      {/* Background Hero Image */}
      <SafeImage
        src={HERO_IMAGE}
        alt="Sunlit coastal cliffside overlooking turquoise sea at golden hour"
        className="absolute inset-0 h-full w-full object-cover object-center"
        fallbackTitle="Wanderly Coastal Horizon"
      />

      {/* Measured contrast scrim */}
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-slate-950/60 via-slate-950/40 to-slate-950/80"
      />

      {/* Foreground Content */}
      <div className="relative z-10 mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="max-w-3xl">
          <p className="mb-4 text-sm font-medium tracking-wide text-cyan-200">
            Curated journeys across Europe, Asia &amp; the Alps
          </p>
          <h1
            className="font-display text-balance font-semibold tracking-tight text-white"
            style={{ fontSize: 'clamp(2.45rem, 5vw, 4.25rem)', lineHeight: 1.08 }}
          >
            Explore the World, Your Way
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-100/90 sm:text-lg">
            Discover handpicked destinations, boutique stays, and effortless multi-day itineraries crafted around your pace.
          </p>
        </div>

        {/* Search Box */}
        <form
          onSubmit={handleSubmit}
          aria-label="Search destinations and travel dates"
          className="mt-10 rounded-2xl bg-white p-3 shadow-2xl shadow-slate-950/25 sm:p-4 lg:mt-12"
        >
          <div className="grid grid-cols-1 gap-3 md:grid-cols-12 md:items-center md:gap-2">
            {/* Destination Field */}
            <div className="md:col-span-5 flex items-center gap-3 rounded-xl px-3.5 py-2.5 bg-slate-50 border border-slate-200/80 focus-within:border-cyan-700 focus-within:bg-white transition-colors">
              <MapPin className="h-5 w-5 shrink-0 text-cyan-800" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <label
                  htmlFor="hero-destination"
                  className="block text-xs font-semibold text-slate-500"
                >
                  Destination
                </label>
                <input
                  id="hero-destination"
                  type="text"
                  list="wanderly-destinations"
                  value={searchDestination}
                  onChange={(e) => onChangeDestination(e.target.value)}
                  placeholder="Paris, Bali, Switzerland..."
                  className="w-full bg-transparent text-sm font-medium text-slate-900 placeholder:text-slate-400 focus:outline-none"
                />
                <datalist id="wanderly-destinations">
                  <option value="Paris" />
                  <option value="Dubai" />
                  <option value="Goa" />
                  <option value="Bali" />
                  <option value="Switzerland" />
                  <option value="Manali" />
                </datalist>
              </div>
            </div>

            {/* Travel Date Field */}
            <div className="md:col-span-3 flex items-center gap-3 rounded-xl px-3.5 py-2.5 bg-slate-50 border border-slate-200/80 focus-within:border-cyan-700 focus-within:bg-white transition-colors">
              <Calendar className="h-5 w-5 shrink-0 text-cyan-800" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <label
                  htmlFor="hero-date"
                  className="block text-xs font-semibold text-slate-500"
                >
                  Travel Date
                </label>
                <input
                  id="hero-date"
                  type="date"
                  value={travelDate}
                  onChange={(e) => onChangeDate(e.target.value)}
                  className="w-full bg-transparent text-sm font-medium text-slate-900 focus:outline-none tabular-nums"
                />
              </div>
            </div>

            {/* Travelers Field */}
            <div className="md:col-span-2 flex items-center gap-3 rounded-xl px-3.5 py-2.5 bg-slate-50 border border-slate-200/80 focus-within:border-cyan-700 focus-within:bg-white transition-colors">
              <Users className="h-5 w-5 shrink-0 text-cyan-800" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <label
                  htmlFor="hero-travelers"
                  className="block text-xs font-semibold text-slate-500"
                >
                  Travelers
                </label>
                <select
                  id="hero-travelers"
                  value={travelers}
                  onChange={(e) => onChangeTravelers(e.target.value)}
                  className="w-full bg-transparent text-sm font-medium text-slate-900 focus:outline-none cursor-pointer"
                >
                  <option value="1">1 Traveler</option>
                  <option value="2">2 Travelers</option>
                  <option value="3">3 Travelers</option>
                  <option value="4">4 Travelers</option>
                  <option value="5">5+ Travelers</option>
                </select>
              </div>
            </div>

            {/* Submit Search Button */}
            <div className="md:col-span-2">
              <button
                type="submit"
                className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-full bg-cyan-800 px-5 py-3 text-sm font-semibold text-white whitespace-nowrap transition-colors duration-150 hover:bg-cyan-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-700 cursor-pointer"
              >
                <Search className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>Search</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </section>
  );
}
