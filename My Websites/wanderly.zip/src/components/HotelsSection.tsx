import { MapPin, Star } from 'lucide-react';
import { HOTELS, Hotel } from '../data/travelData';
import { SafeImage } from './SafeImage';

interface HotelsSectionProps {
  onViewHotel: (hotel: Hotel) => void;
}

export function HotelsSection({ onViewHotel }: HotelsSectionProps) {
  return (
    <section
      id="hotels"
      className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24"
    >
      <div className="max-w-2xl">
        <p className="text-sm font-semibold text-cyan-800">
          Curated Stays
        </p>
        <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl text-balance">
          Boutique Hotels Selected for Character &amp; Comfort
        </h2>
        <p className="mt-3 text-base leading-relaxed text-slate-600">
          Architecture-forward residences and serene retreats chosen for hospitality, walkability, and memorable views.
        </p>
      </div>

      <div className="mt-10 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
        {HOTELS.map((hotel) => (
          <article
            key={hotel.id}
            className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition-transform duration-200 hover:-translate-y-1"
          >
            <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
              <SafeImage
                src={hotel.image}
                alt={`${hotel.name} in ${hotel.location}`}
                fallbackTitle={hotel.name}
                className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>

            <div className="flex flex-1 flex-col p-6">
              {/* Unboxed rating & location metadata */}
              <div className="flex items-center justify-between gap-2 text-xs font-medium text-slate-500">
                <span className="inline-flex items-center gap-1 text-slate-700">
                  <MapPin className="h-3.5 w-3.5 shrink-0 text-cyan-800" aria-hidden="true" />
                  {hotel.location}
                </span>
                <span className="inline-flex items-center gap-1 text-slate-900 font-semibold tabular-nums shrink-0">
                  <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" aria-hidden="true" />
                  {hotel.rating.toFixed(1)}
                  <span className="font-normal text-slate-500">
                    ({hotel.reviewCount})
                  </span>
                </span>
              </div>

              <h3 className="mt-2 font-display text-xl font-semibold text-slate-900">
                {hotel.name}
              </h3>

              <p className="mt-2.5 flex-1 text-sm leading-relaxed text-slate-600">
                {hotel.shortDescription}
              </p>

              <div className="mt-6 flex items-center justify-between gap-4 border-t border-slate-100 pt-4">
                <div>
                  <span className="text-lg font-semibold text-slate-900 tabular-nums">
                    ${hotel.pricePerNight}
                  </span>
                  <span className="text-xs text-slate-500"> / night</span>
                </div>

                <button
                  type="button"
                  onClick={() => onViewHotel(hotel)}
                  className="inline-flex min-h-[40px] items-center justify-center rounded-full border border-slate-300 bg-white px-5 py-2 text-sm font-semibold text-slate-900 whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-slate-900 hover:bg-slate-900 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-700 cursor-pointer"
                >
                  View Hotel
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
