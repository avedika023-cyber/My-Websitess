import { Heart, MapPin, RotateCcw } from 'lucide-react';
import {
  DESTINATIONS,
  Destination,
  DestinationCategory,
} from '../data/travelData';
import { SafeImage } from './SafeImage';

interface DestinationSectionProps {
  searchQuery: string;
  selectedCategory: DestinationCategory | 'Saved';
  favorites: string[];
  onSelectCategory: (category: DestinationCategory | 'Saved') => void;
  onClearSearch: () => void;
  onToggleFavorite: (id: string) => void;
  onExplore: (destination: Destination) => void;
}

const FILTER_OPTIONS: Array<DestinationCategory | 'Saved'> = [
  'All',
  'City & Culture',
  'Beach & Tropics',
  'Alpine & Mountains',
  'Saved',
];

export function DestinationSection({
  searchQuery,
  selectedCategory,
  favorites,
  onSelectCategory,
  onClearSearch,
  onToggleFavorite,
  onExplore,
}: DestinationSectionProps) {
  const normalizedQuery = searchQuery.trim().toLowerCase();

  const filteredDestinations = DESTINATIONS.filter((dest) => {
    const matchesSearch =
      normalizedQuery === '' ||
      dest.name.toLowerCase().includes(normalizedQuery) ||
      dest.country.toLowerCase().includes(normalizedQuery) ||
      dest.locationLabel.toLowerCase().includes(normalizedQuery) ||
      dest.shortDescription.toLowerCase().includes(normalizedQuery);

    if (!matchesSearch) return false;

    if (selectedCategory === 'Saved') {
      return favorites.includes(dest.id);
    }
    if (selectedCategory === 'All') {
      return true;
    }
    return dest.category === selectedCategory;
  });

  return (
    <section
      id="destinations"
      className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24"
    >
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold text-cyan-800">
            Popular Destinations
          </p>
          <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl text-balance">
            Places Worth Crossing Continents For
          </h2>
          <p className="mt-3 text-base leading-relaxed text-slate-600">
            Filter by landscape or save your favorite routes while planning your next departure.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div
          role="tablist"
          aria-label="Filter destinations"
          className="flex flex-wrap items-center gap-1.5 rounded-xl bg-slate-100 p-1.5 self-start lg:self-auto"
        >
          {FILTER_OPTIONS.map((option) => {
            const isActive = selectedCategory === option;
            const label =
              option === 'Saved' ? `Saved (${favorites.length})` : option;
            return (
              <button
                key={option}
                role="tab"
                type="button"
                aria-selected={isActive}
                onClick={() => onSelectCategory(option)}
                className={`min-h-[38px] rounded-lg px-3.5 py-1.5 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-cyan-700 ${
                  isActive
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Search Indicator */}
      {normalizedQuery !== '' && (
        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700">
          <span>
            Showing results for <strong className="font-semibold text-slate-900">&ldquo;{searchQuery}&rdquo;</strong>
            {' '}({filteredDestinations.length} {filteredDestinations.length === 1 ? 'destination' : 'destinations'})
          </span>
          <button
            type="button"
            onClick={onClearSearch}
            className="inline-flex items-center gap-1.5 font-semibold text-cyan-800 hover:text-cyan-950 whitespace-nowrap cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Clear search</span>
          </button>
        </div>
      )}

      {/* Destination Grid */}
      {filteredDestinations.length > 0 ? (
        <div className="mt-10 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
          {filteredDestinations.map((dest) => {
            const isSaved = favorites.includes(dest.id);
            return (
              <article
                key={dest.id}
                className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition-transform duration-200 hover:-translate-y-1"
              >
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-slate-100">
                  <SafeImage
                    src={dest.image}
                    alt={`${dest.name}, ${dest.country}`}
                    fallbackTitle={dest.name}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <button
                    type="button"
                    onClick={() => onToggleFavorite(dest.id)}
                    aria-label={
                      isSaved
                        ? `Remove ${dest.name} from favorites`
                        : `Save ${dest.name} to favorites`
                    }
                    aria-pressed={isSaved}
                    className="absolute top-3 right-3 flex h-11 w-11 items-center justify-center rounded-full bg-white/90 text-slate-700 shadow-sm backdrop-blur-sm transition-colors duration-150 hover:bg-white hover:text-rose-600 focus-visible:outline-2 focus-visible:outline-cyan-700 cursor-pointer"
                  >
                    <Heart
                      className={`h-5 w-5 transition-colors ${
                        isSaved ? 'fill-rose-600 text-rose-600' : 'text-slate-700'
                      }`}
                    />
                  </button>
                </div>

                <div className="flex flex-1 flex-col p-6">
                  {/* Unboxed location & season metadata */}
                  <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                    <span className="inline-flex items-center gap-1 text-cyan-800">
                      <MapPin className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                      {dest.locationLabel}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{dest.category}</span>
                  </div>

                  <h3 className="mt-2 font-display text-2xl font-semibold text-slate-900">
                    {dest.name}
                  </h3>

                  <p className="mt-2.5 flex-1 text-sm leading-relaxed text-slate-600">
                    {dest.shortDescription}
                  </p>

                  <div className="mt-6 flex items-center justify-between gap-4 border-t border-slate-100 pt-4">
                    <div>
                      <span className="block text-xs text-slate-500">From</span>
                      <span className="text-lg font-semibold text-slate-900 tabular-nums">
                        ${dest.startingPrice.toLocaleString()}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onExplore(dest)}
                      className="inline-flex min-h-[40px] items-center justify-center rounded-full bg-slate-900 px-5 py-2 text-sm font-semibold text-white whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-cyan-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-700 cursor-pointer"
                    >
                      Explore
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <div className="mt-10 rounded-2xl border border-slate-200 bg-white px-6 py-14 text-center">
          <h3 className="font-display text-xl font-semibold text-slate-900">
            {selectedCategory === 'Saved'
              ? 'No saved destinations yet'
              : 'No matching destinations found'}
          </h3>
          <p className="mx-auto mt-2 max-w-md text-sm text-slate-600">
            {selectedCategory === 'Saved'
              ? 'Tap the heart icon on any destination card to save it to your travel shortlist.'
              : 'Try clearing your search query or switching to All destinations to explore our full catalog.'}
          </p>
          <button
            type="button"
            onClick={() => {
              onClearSearch();
              onSelectCategory('All');
            }}
            className="mt-5 inline-flex min-h-[44px] items-center justify-center rounded-full bg-cyan-800 px-6 py-2.5 text-sm font-semibold text-white hover:bg-cyan-900 cursor-pointer"
          >
            Show All Destinations
          </button>
        </div>
      )}
    </section>
  );
}
