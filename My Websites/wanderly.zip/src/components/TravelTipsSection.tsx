import { TRAVEL_TIPS } from '../data/travelData';

export function TravelTipsSection() {
  return (
    <section
      id="tips"
      className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24"
    >
      <div className="max-w-2xl">
        <p className="text-sm font-semibold text-cyan-800">
          Travel Tips
        </p>
        <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl text-balance">
          Field Notes for Smoother Departures
        </h2>
        <p className="mt-3 text-base leading-relaxed text-slate-600">
          Practical preparation advice gathered from our regional trip planners and seasoned travelers.
        </p>
      </div>

      <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2">
        {TRAVEL_TIPS.map((tip) => (
          <article
            key={tip.id}
            className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 sm:p-7"
          >
            <div>
              {/* Clean unboxed metadata with typographic separator */}
              <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                <span className="text-cyan-800 font-semibold">{tip.topic}</span>
                <span aria-hidden="true">·</span>
                <span>{tip.readTime}</span>
              </div>

              <h3 className="mt-3 font-display text-xl font-semibold text-slate-900">
                {tip.title}
              </h3>

              <p className="mt-2.5 text-sm leading-relaxed text-slate-600">
                {tip.summary}
              </p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
