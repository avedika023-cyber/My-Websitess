import { Camera, Compass, Globe, Share2 } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-300">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-12">
          {/* Brand Summary */}
          <div className="md:col-span-5">
            <a
              href="#home"
              className="font-display text-2xl font-semibold tracking-tight text-white"
            >
              Wanderly
            </a>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-slate-400">
              Curated destinations, boutique hotels, and effortless multi-day journeys designed for thoughtful travelers.
            </p>

            {/* Social Media Links */}
            <div className="mt-6 flex items-center gap-3">
              <a
                href="#contact"
                aria-label="Wanderly on Instagram"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-800 text-slate-300 transition-colors hover:border-cyan-600 hover:text-white"
              >
                <Camera className="h-4 w-4" aria-hidden="true" />
              </a>
              <a
                href="#contact"
                aria-label="Wanderly Global Journal"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-800 text-slate-300 transition-colors hover:border-cyan-600 hover:text-white"
              >
                <Globe className="h-4 w-4" aria-hidden="true" />
              </a>
              <a
                href="#contact"
                aria-label="Wanderly Travel Guides"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-800 text-slate-300 transition-colors hover:border-cyan-600 hover:text-white"
              >
                <Compass className="h-4 w-4" aria-hidden="true" />
              </a>
              <a
                href="#contact"
                aria-label="Share Wanderly"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-800 text-slate-300 transition-colors hover:border-cyan-600 hover:text-white"
              >
                <Share2 className="h-4 w-4" aria-hidden="true" />
              </a>
            </div>
          </div>

          {/* Explore Links */}
          <div className="md:col-span-3">
            <h3 className="text-sm font-semibold text-white">Explore</h3>
            <ul className="mt-4 space-y-2.5 text-sm text-slate-400">
              <li>
                <a href="#home" className="hover:text-white transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Destinations
                </a>
              </li>
              <li>
                <a href="#hotels" className="hover:text-white transition-colors">
                  Hotels
                </a>
              </li>
              <li>
                <a href="#trips" className="hover:text-white transition-colors">
                  Trips
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  About
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-white transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Destinations Mirror */}
          <div className="md:col-span-4">
            <h3 className="text-sm font-semibold text-white">Featured Routes</h3>
            <ul className="mt-4 grid grid-cols-2 gap-y-2.5 gap-x-4 text-sm text-slate-400">
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Paris, France
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Dubai, UAE
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Goa, India
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Bali, Indonesia
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Switzerland
                </a>
              </li>
              <li>
                <a href="#destinations" className="hover:text-white transition-colors">
                  Manali, India
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-slate-800/80 pt-8 text-xs text-slate-500 sm:flex-row">
          <p>&copy; {new Date().getFullYear()} Wanderly Travel. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#about" className="hover:text-slate-300 transition-colors">
              Travel Terms
            </a>
            <a href="#contact" className="hover:text-slate-300 transition-colors">
              Privacy Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
