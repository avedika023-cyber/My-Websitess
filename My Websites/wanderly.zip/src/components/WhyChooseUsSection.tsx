import { Headphones, LockKeyhole, ShieldCheck, Tag } from 'lucide-react';
import { WHY_CHOOSE_US } from '../data/travelData';

const PILLAR_ICONS = [ShieldCheck, Tag, LockKeyhole, Headphones];

export function WhyChooseUsSection() {
  return (
    <section
      id="about"
      className="border-y border-slate-200/80 bg-white py-16 lg:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:items-start">
          <div className="lg:col-span-4">
            <p className="text-sm font-semibold text-cyan-800">
              Why Choose Us
            </p>
            <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl text-balance">
              Thoughtful Travel Planning Without the Friction
            </h2>
            <p className="mt-4 text-base leading-relaxed text-slate-600">
              Wanderly combines local destination expertise with clear pricing and dependable human support before, during, and after every journey.
            </p>
          </div>

          <div className="lg:col-span-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
            {WHY_CHOOSE_US.map((item, idx) => {
              const Icon = PILLAR_ICONS[idx % PILLAR_ICONS.length];
              return (
                <div
                  key={item.title}
                  className="rounded-2xl border border-slate-200 bg-slate-50/70 p-6 sm:p-7"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold tracking-wide text-cyan-800 tabular-nums">
                      {item.number}.
                    </span>
                    <Icon
                      className="h-5 w-5 text-cyan-800"
                      strokeWidth={1.75}
                      aria-hidden="true"
                    />
                  </div>
                  <h3 className="mt-4 font-display text-xl font-semibold text-slate-900">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
