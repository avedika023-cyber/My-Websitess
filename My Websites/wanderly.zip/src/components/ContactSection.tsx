import { FormEvent, useState } from 'react';
import { CheckCircle2, Mail, MapPin, Phone, Send } from 'lucide-react';

export function ContactSection() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [submittedName, setSubmittedName] = useState<string | null>(null);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const trimmedMessage = message.trim();

    if (!trimmedName) {
      setError('Please enter your full name.');
      return;
    }
    if (!trimmedEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!trimmedMessage) {
      setError('Please write a brief message about your travel plans.');
      return;
    }

    setSubmittedName(trimmedName);
    setName('');
    setEmail('');
    setSubject('');
    setMessage('');
  };

  return (
    <section
      id="contact"
      className="border-t border-slate-200/80 bg-white py-16 lg:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:items-start">
          {/* Contact Details */}
          <div className="lg:col-span-5">
            <p className="text-sm font-semibold text-cyan-800">
              Contact Us
            </p>
            <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl text-balance">
              Plan Your Next Journey With a Specialist
            </h2>
            <p className="mt-4 text-base leading-relaxed text-slate-600">
              Questions about custom itineraries, group dates, or hotel preferences? Send our travel desk a note and receive a tailored response within one business day.
            </p>

            <div className="mt-8 space-y-5 border-t border-slate-200 pt-8 text-sm text-slate-700">
              <div className="flex items-start gap-3.5">
                <Mail className="mt-0.5 h-5 w-5 shrink-0 text-cyan-800" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-900">Email Desk</p>
                  <p className="text-slate-600">hello@wanderly.travel</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <Phone className="mt-0.5 h-5 w-5 shrink-0 text-cyan-800" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-900">Traveler Helpline</p>
                  <p className="text-slate-600 tabular-nums">+1 (800) 555-0194</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-cyan-800" aria-hidden="true" />
                <div>
                  <p className="font-semibold text-slate-900">Headquarters</p>
                  <p className="text-slate-600">240 Harborview Promenade, Suite 410</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-6 sm:p-8">
              {submittedName ? (
                <div
                  role="status"
                  aria-live="polite"
                  className="py-8 text-center"
                >
                  <CheckCircle2
                    className="mx-auto h-12 w-12 text-emerald-700"
                    strokeWidth={1.75}
                    aria-hidden="true"
                  />
                  <h3 className="mt-4 font-display text-2xl font-semibold text-slate-900">
                    Message Received, {submittedName}
                  </h3>
                  <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-600">
                    Thank you for reaching out to Wanderly. A dedicated trip specialist will review your note and get back to you shortly.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubmittedName(null)}
                    className="mt-6 inline-flex min-h-[44px] items-center justify-center rounded-full bg-slate-900 px-6 py-2.5 text-sm font-semibold text-white hover:bg-cyan-800 transition-colors cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-5">
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="contact-name"
                        className="block text-xs font-semibold text-slate-700"
                      >
                        Full Name
                      </label>
                      <input
                        id="contact-name"
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Maya Lin"
                        className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-cyan-700 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="contact-email"
                        className="block text-xs font-semibold text-slate-700"
                      >
                        Email Address
                      </label>
                      <input
                        id="contact-email"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="maya@example.com"
                        className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-cyan-700 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-subject"
                      className="block text-xs font-semibold text-slate-700"
                    >
                      Destination or Topic (Optional)
                    </label>
                    <input
                      id="contact-subject"
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="e.g., Custom 7-day Switzerland rail itinerary"
                      className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-cyan-700 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="contact-message"
                      className="block text-xs font-semibold text-slate-700"
                    >
                      Message
                    </label>
                    <textarea
                      id="contact-message"
                      rows={4}
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Tell us about your preferred travel dates, destinations, or group size..."
                      className="mt-1.5 w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-cyan-700 focus:outline-none"
                    />
                  </div>

                  {error && (
                    <p
                      role="alert"
                      className="rounded-lg bg-rose-50 px-3.5 py-2.5 text-xs font-medium text-rose-800 border border-rose-200"
                    >
                      {error}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-full bg-cyan-800 px-7 py-3 text-sm font-semibold text-white transition-colors duration-150 hover:bg-cyan-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-700 cursor-pointer"
                  >
                    <Send className="h-4 w-4" aria-hidden="true" />
                    <span>Send Message</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
