import { Heart, Play, Star } from 'lucide-react';
import type { Movie } from '../types/movie';
import { PosterImage } from './PosterImage';

interface FeaturedMovieProps {
  movie: Movie;
  isFavorite: boolean;
  onViewDetails: (movie: Movie) => void;
  onToggleFavorite: (movieId: string) => void;
}

export function FeaturedMovie({
  movie,
  isFavorite,
  onViewDetails,
  onToggleFavorite,
}: FeaturedMovieProps) {
  return (
    <section
      id="featured"
      aria-labelledby="featured-heading"
      className="mx-auto max-w-[1280px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16"
    >
      <div className="mb-6 flex items-baseline justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-[#E5A93C]">Featured Spotlight</p>
          <h2
            id="featured-heading"
            className="font-display mt-1 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
          >
            Tonight&apos;s Featured Movie
          </h2>
        </div>
      </div>

      <div className="grid grid-cols-1 overflow-hidden rounded-2xl border border-white/10 bg-[#111318] lg:grid-cols-12">
        {/* Poster Column */}
        <div className="relative aspect-[3/4] max-h-[460px] w-full overflow-hidden bg-[#0B0D11] lg:col-span-4 lg:aspect-auto lg:max-h-none">
          <PosterImage
            src={movie.poster}
            title={movie.title}
            year={movie.year}
            accentColor={movie.accentColor}
            className="transition-transform duration-300 ease-out hover:scale-[1.02]"
          />
        </div>

        {/* Details Column */}
        <div className="flex flex-col justify-between p-6 sm:p-8 lg:col-span-8 lg:p-10">
          <div>
            {/* Unboxed metadata line */}
            <div className="flex flex-wrap items-center gap-2.5 text-sm text-zinc-400">
              <span className="font-medium text-[#E5A93C]">Editor&apos;s Pick</span>
              <span aria-hidden="true">·</span>
              <span>
                {movie.genre}
                {movie.secondaryGenre ? ` / ${movie.secondaryGenre}` : ''}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{movie.year}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{movie.runtime}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1 font-mono font-medium tabular-nums text-[#F4F4F5]">
                <Star className="h-3.5 w-3.5 fill-[#E5A93C] text-[#E5A93C]" aria-hidden="true" />
                {movie.rating.toFixed(1)}
              </span>
            </div>

            <h3 className="font-display mt-4 text-3xl font-bold tracking-tight text-[#F4F4F5] sm:text-4xl">
              {movie.title}
            </h3>

            <p className="mt-4 max-w-2xl text-base leading-relaxed text-zinc-300">
              {movie.description}
            </p>

            <div className="mt-6 grid grid-cols-1 gap-4 border-t border-white/10 pt-6 sm:grid-cols-2">
              <div>
                <p className="text-xs font-medium text-zinc-500">Director</p>
                <p className="mt-1 text-sm font-medium text-zinc-200">{movie.director}</p>
              </div>
              <div>
                <p className="text-xs font-medium text-zinc-500">Starring</p>
                <p className="mt-1 text-sm text-zinc-200">{movie.cast.join(', ')}</p>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onViewDetails(movie)}
              className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#E5A93C] px-5 py-2.5 text-sm font-semibold text-[#07080A] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#f0b94f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C]"
            >
              <Play className="h-4 w-4 fill-current" aria-hidden="true" />
              <span>View Details</span>
            </button>

            <button
              type="button"
              onClick={() => onToggleFavorite(movie.id)}
              aria-pressed={isFavorite}
              className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg border px-5 py-2.5 text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C] ${
                isFavorite
                  ? 'border-[#E5A93C]/50 bg-[#E5A93C]/10 text-[#E5A93C] hover:bg-[#E5A93C]/20'
                  : 'border-white/15 bg-white/[0.03] text-zinc-200 hover:border-white/30 hover:bg-white/[0.07]'
              }`}
            >
              <Heart
                className={`h-4 w-4 ${isFavorite ? 'fill-[#E5A93C]' : ''}`}
                aria-hidden="true"
              />
              <span>{isFavorite ? 'Saved to Favorites' : 'Add to Favorites'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
