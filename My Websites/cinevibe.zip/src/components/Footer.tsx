interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const links = [
    { id: 'home', label: 'Home' },
    { id: 'movies', label: 'Movies' },
    { id: 'genres', label: 'Genres' },
    { id: 'favorites', label: 'Favorites' },
    { id: 'about', label: 'About' },
  ];

  return (
    <footer className="border-t border-white/10 bg-[#07080A]">
      <div className="mx-auto flex max-w-[1280px] flex-col items-start justify-between gap-6 px-4 py-10 sm:flex-row sm:items-center sm:px-6 lg:px-8">
        <div>
          <span className="font-display text-lg font-bold tracking-tight text-[#F4F4F5]">
            CineVibe
          </span>
          <p className="mt-1 text-xs text-zinc-500">
            &copy; {new Date().getFullYear()} CineVibe. Curated movie discovery for every screen.
          </p>
        </div>

        <nav aria-label="Footer Navigation" className="flex flex-wrap items-center gap-6">
          {links.map((link) => (
            <a
              key={link.id}
              href={`#${link.id}`}
              onClick={(e) => {
                e.preventDefault();
                onNavigate(link.id);
              }}
              className="text-sm text-zinc-400 transition-colors hover:text-[#F4F4F5]"
            >
              {link.label}
            </a>
          ))}
        </nav>
      </div>
    </footer>
  );
}
