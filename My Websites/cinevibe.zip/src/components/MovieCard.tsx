import { Heart, Star } from 'lucide-react';
import type { Movie } from '../types/movie';
import { PosterImage } from './PosterImage';

interface MovieCardProps {
  movie: Movie;
  isFavorite: boolean;
  onViewDetails: (movie: Movie) => void;
  onToggleFavorite: (movieId: string) => void;
}

export function MovieCard({
  movie,
  isFavorite,
  onViewDetails,
  onToggleFavorite,
}: MovieCardProps) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-xl border border-white/10 bg-[#111318] transition-all duration-150 ease-out hover:-translate-y-1 hover:border-[#E5A93C]/40">
      {/* Clickable Poster Area */}
      <button
        type="button"
        onClick={() => onViewDetails(movie)}
        className="relative aspect-[3/4] w-full overflow-hidden bg-[#0B0D11] text-left focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#E5A93C]"
        aria-label={`View details for ${movie.title}`}
      >
        <PosterImage
          src={movie.poster}
          title={movie.title}
          year={movie.year}
          accentColor={movie.accentColor}
          className="transition-transform duration-200 ease-out group-hover:scale-[1.03]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#111318] via-[#111318]/40 to-transparent"
        />
      </button>

      {/* Card Body */}
      <div className="flex flex-1 flex-col justify-between p-4 sm:p-5">
        <div>
          <h3
            className="font-display truncate text-lg font-semibold tracking-tight text-[#F4F4F5]"
            title={movie.title}
          >
            {movie.title}
          </h3>

          {/* Clean Unboxed Metadata */}
          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-zinc-400">
            <span>{movie.genre}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{movie.year}</span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1 font-mono font-medium tabular-nums text-[#F4F4F5]">
              <Star
                className="h-3.5 w-3.5 fill-[#E5A93C] text-[#E5A93C]"
                aria-hidden="true"
              />
              {movie.rating.toFixed(1)}
            </span>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-4 flex items-center gap-2 pt-3 border-t border-white/8">
          <button
            type="button"
            onClick={() => onViewDetails(movie)}
            className="inline-flex min-h-[40px] flex-1 items-center justify-center rounded-lg bg-[#E5A93C] px-3 py-2 text-xs font-semibold text-[#07080A] whitespace-nowrap transition-colors duration-150 hover:bg-[#f0b94f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C]"
          >
            View Details
          </button>

          <button
            type="button"
            onClick={() => onToggleFavorite(movie.id)}
            aria-pressed={isFavorite}
            aria-label={
              isFavorite
                ? `Remove ${movie.title} from Favorites`
                : `Add ${movie.title} to Favorites`
            }
            className={`inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-medium whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C] ${
              isFavorite
                ? 'border-[#E5A93C]/50 bg-[#E5A93C]/12 text-[#E5A93C] hover:bg-[#E5A93C]/20'
                : 'border-white/15 bg-white/[0.03] text-zinc-300 hover:border-white/30 hover:bg-white/[0.08] hover:text-white'
            }`}
          >
            <Heart
              className={`h-3.5 w-3.5 ${isFavorite ? 'fill-[#E5A93C]' : ''}`}
              aria-hidden="true"
            />
            <span>{isFavorite ? 'Favorited' : 'Favorite'}</span>
          </button>
        </div>
      </div>
    </article>
  );
}
