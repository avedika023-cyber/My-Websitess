export function AboutSection() {
  return (
    <section
      id="about"
      aria-labelledby="about-heading"
      className="border-t border-white/10 bg-[#0B0D12]"
    >
      <div className="mx-auto max-w-[1280px] px-4 py-14 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:gap-12">
          <div className="lg:col-span-5">
            <p className="text-sm font-medium text-[#E5A93C]">About CineVibe</p>
            <h2
              id="about-heading"
              className="font-display mt-2 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
              style={{ textWrap: 'balance' }}
            >
              Built to make choosing tonight&apos;s film effortless.
            </h2>
          </div>

          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:col-span-7">
            <div>
              <h3 className="font-display text-base font-semibold text-[#F4F4F5]">
                01. Curated Discovery
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                Instead of endless scrolling through thousands of unranked titles, CineVibe highlights acclaimed sci-fi epics, animated landmarks, and modern thrillers with verified ratings and concise story overviews.
              </p>
            </div>

            <div>
              <h3 className="font-display text-base font-semibold text-[#F4F4F5]">
                02. Instant Personal Watchlist
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-zinc-400">
                Filter by genre, minimum rating, or release decade in real time. Save movies to your Favorites list—stored locally in your browser so your movie night lineup stays ready whenever you return.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
