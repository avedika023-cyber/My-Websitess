import { useState } from 'react';
import { Film } from 'lucide-react';

interface PosterImageProps {
  src: string;
  title: string;
  year?: number;
  accentColor?: string;
  className?: string;
}

export function PosterImage({
  src,
  title,
  year,
  accentColor = '#E5A93C',
  className = '',
}: PosterImageProps) {
  const [hasError, setHasError] = useState(false);

  if (!src || hasError) {
    return (
      <div
        className={`relative flex h-full w-full flex-col justify-between overflow-hidden bg-[#101219] p-5 ${className}`}
        role="img"
        aria-label={`${title} poster artwork`}
      >
        {/* Bespoke cosmic horizon & portal artwork */}
        <svg
          viewBox="0 0 300 400"
          className="pointer-events-none absolute inset-0 h-full w-full object-cover"
          preserveAspectRatio="xMidYMid slice"
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="nebulaGlow" cx="50%" cy="42%" r="60%">
              <stop offset="0%" stopColor={accentColor} stopOpacity="0.42" />
              <stop offset="55%" stopColor="#1E1B4B" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#07080A" stopOpacity="1" />
            </radialGradient>
            <linearGradient id="horizonFade" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#07080A" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#07080A" stopOpacity="0.92" />
            </linearGradient>
          </defs>
          <rect width="300" height="400" fill="url(#nebulaGlow)" />
          <circle cx="150" cy="165" r="88" fill="none" stroke={accentColor} strokeOpacity="0.35" strokeWidth="1.5" />
          <circle cx="150" cy="165" r="68" fill="none" stroke={accentColor} strokeOpacity="0.65" strokeWidth="2.5" strokeDasharray="10 6" />
          <circle cx="150" cy="165" r="46" fill="none" stroke="#F4F4F5" strokeOpacity="0.28" strokeWidth="1" />
          <circle cx="62" cy="78" r="1.5" fill="#F4F4F5" fillOpacity="0.7" />
          <circle cx="242" cy="96" r="1.8" fill="#F4F4F5" fillOpacity="0.6" />
          <circle cx="212" cy="54" r="1.2" fill={accentColor} fillOpacity="0.8" />
          <circle cx="88" cy="240" r="1.4" fill="#F4F4F5" fillOpacity="0.5" />
          <path d="M0 320 L85 286 L150 305 L235 276 L300 310 L300 400 L0 400 Z" fill="#0B0D13" />
          <rect width="300" height="400" fill="url(#horizonFade)" />
        </svg>

        <div className="relative z-10 flex items-center justify-between text-xs text-zinc-300/80">
          <span className="font-mono tabular-nums">{year ?? ''}</span>
          <Film className="h-4 w-4 text-zinc-400" aria-hidden="true" />
        </div>

        <div className="relative z-10 mt-auto">
          <p className="font-display text-xl font-bold leading-tight tracking-tight text-zinc-100">
            {title}
          </p>
        </div>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={`${title} movie poster`}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={`h-full w-full object-cover ${className}`}
      loading="lazy"
    />
  );
}
