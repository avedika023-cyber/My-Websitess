import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Heart,
  Pause,
  Play,
  Star,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import type { Movie } from '../types/movie';
import { PosterImage } from './PosterImage';

interface MovieModalProps {
  movie: Movie | null;
  isFavorite: boolean;
  onClose: () => void;
  onToggleFavorite: (movieId: string) => void;
}

export function MovieModal({
  movie,
  isFavorite,
  onClose,
  onToggleFavorite,
}: MovieModalProps) {
  const [showTrailer, setShowTrailer] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [sceneIndex, setSceneIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);

  // Reset trailer state whenever a new movie is opened
  useEffect(() => {
    setShowTrailer(false);
    setIsPlaying(true);
    setSceneIndex(0);
    setIsMuted(true);
  }, [movie?.id]);

  // Close on Escape key & lock background scroll while modal is open
  useEffect(() => {
    if (!movie) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [movie, onClose]);

  // Advance trailer preview scenes automatically when playing
  useEffect(() => {
    if (!movie || !showTrailer || !isPlaying) return;

    const timer = window.setInterval(() => {
      setSceneIndex((prev) => (prev + 1) % movie.trailerScenes.length);
    }, 3500);

    return () => window.clearInterval(timer);
  }, [movie, showTrailer, isPlaying]);

  // Subtle optional Web Audio ambient chord when user unmutes trailer preview
  useEffect(() => {
    if (!showTrailer || isMuted || !isPlaying) return;

    let audioCtx: AudioContext | null = null;
    try {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioContextClass) return;

      audioCtx = new AudioContextClass();
      const masterGain = audioCtx.createGain();
      masterGain.gain.setValueAtTime(0.03, audioCtx.currentTime);
      masterGain.connect(audioCtx.destination);

      const freqs = [110, 164.81, 220];
      const oscillators = freqs.map((freq) => {
        const osc = audioCtx!.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, audioCtx!.currentTime);
        osc.connect(masterGain);
        osc.start();
        return osc;
      });

      return () => {
        oscillators.forEach((osc) => {
          try {
            osc.stop();
          } catch {
            // Ignore cleanup errors if already stopped
          }
        });
        audioCtx?.close();
      };
    } catch {
      return undefined;
    }
  }, [showTrailer, isMuted, isPlaying]);

  return (
    <AnimatePresence>
      {movie && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-movie-title"
        >
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            aria-hidden="true"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-white/15 bg-[#111318] shadow-2xl"
          >
            {/* High-Contrast Close Button */}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close movie details"
              className="absolute top-4 right-4 z-20 flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 bg-[#07080A]/85 text-zinc-200 transition-colors hover:bg-[#E5A93C] hover:text-[#07080A] focus-visible:outline-2 focus-visible:outline-[#E5A93C]"
            >
              <X className="h-5 w-5" />
            </button>

            {showTrailer ? (
              /* Interactive Trailer Preview Player */
              <div className="p-6 sm:p-8">
                <div className="mb-4 flex items-center justify-between gap-4 pr-12">
                  <button
                    type="button"
                    onClick={() => setShowTrailer(false)}
                    className="inline-flex min-h-[40px] items-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] px-3.5 py-2 text-xs font-medium text-zinc-200 transition-colors hover:bg-white/[0.09]"
                  >
                    <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                    <span>Back to Details</span>
                  </button>
                  <p className="truncate font-display text-sm font-semibold text-zinc-300">
                    {movie.title} — Official Trailer Preview
                  </p>
                </div>

                {/* Widescreen 16:9 Screening Frame */}
                <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl border border-white/10 bg-[#07080A]">
                  <div
                    className={`h-full w-full ${
                      isPlaying ? 'animate-trailer-pan' : ''
                    }`}
                  >
                    <PosterImage
                      src={movie.poster}
                      title={movie.title}
                      year={movie.year}
                      accentColor={movie.accentColor}
                      className="opacity-85"
                    />
                  </div>

                  {/* Letterbox Vignette & Scrim */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/60"
                  />

                  {/* Tagline & Active Storyboard Caption */}
                  <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
                    <p className="text-xs font-medium text-[#E5A93C]">
                      {movie.trailerTagline}
                    </p>
                    <p className="mt-1.5 font-display text-lg font-semibold text-white sm:text-xl">
                      {movie.trailerScenes[sceneIndex]?.caption}
                    </p>

                    {/* Player Controls */}
                    <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/15 pt-3">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setIsPlaying((prev) => !prev)}
                          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-md bg-[#E5A93C] px-3 py-1.5 text-xs font-semibold text-[#07080A] hover:bg-[#f0b94f]"
                        >
                          {isPlaying ? (
                            <>
                              <Pause className="h-3.5 w-3.5" aria-hidden="true" />
                              <span>Pause</span>
                            </>
                          ) : (
                            <>
                              <Play className="h-3.5 w-3.5 fill-current" aria-hidden="true" />
                              <span>Play</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => setIsMuted((prev) => !prev)}
                          aria-label={isMuted ? 'Unmute ambient score' : 'Mute ambient score'}
                          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-md border border-white/20 bg-black/50 px-3 py-1.5 text-xs font-medium text-zinc-200 hover:bg-white/10"
                        >
                          {isMuted ? (
                            <>
                              <VolumeX className="h-3.5 w-3.5" aria-hidden="true" />
                              <span>Muted</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="h-3.5 w-3.5 text-[#E5A93C]" aria-hidden="true" />
                              <span>Ambient Audio</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* Scene Selector Dots */}
                      <div className="flex items-center gap-2">
                        {movie.trailerScenes.map((scene, idx) => (
                          <button
                            key={scene.timestamp}
                            type="button"
                            onClick={() => setSceneIndex(idx)}
                            className={`rounded-md px-2.5 py-1 font-mono text-xs tabular-nums transition-colors ${
                              idx === sceneIndex
                                ? 'bg-white text-[#07080A] font-semibold'
                                : 'bg-white/10 text-zinc-300 hover:bg-white/20'
                            }`}
                          >
                            {scene.timestamp}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Movie Details View */
              <div className="grid grid-cols-1 md:grid-cols-12">
                {/* Poster */}
                <div className="aspect-[3/4] max-h-[420px] w-full overflow-hidden bg-[#0B0D11] md:col-span-5 md:aspect-auto md:max-h-none">
                  <PosterImage
                    src={movie.poster}
                    title={movie.title}
                    year={movie.year}
                    accentColor={movie.accentColor}
                  />
                </div>

                {/* Info */}
                <div className="flex flex-col justify-between p-6 sm:p-8 md:col-span-7">
                  <div className="pr-8">
                    <div className="flex flex-wrap items-center gap-2 text-sm text-zinc-400">
                      <span>
                        {movie.genre}
                        {movie.secondaryGenre ? ` / ${movie.secondaryGenre}` : ''}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{movie.year}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{movie.runtime}</span>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1 font-mono font-semibold tabular-nums text-[#E5A93C]">
                        <Star className="h-4 w-4 fill-[#E5A93C]" aria-hidden="true" />
                        {movie.rating.toFixed(1)}
                      </span>
                    </div>

                    <h2
                      id="modal-movie-title"
                      className="font-display mt-3 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
                    >
                      {movie.title}
                    </h2>

                    <p className="mt-4 text-sm leading-relaxed text-zinc-300 sm:text-base">
                      {movie.description}
                    </p>

                    <dl className="mt-6 space-y-3 border-t border-white/10 pt-5 text-sm">
                      <div className="flex flex-col gap-0.5 sm:flex-row sm:gap-3">
                        <dt className="w-24 shrink-0 text-zinc-500">Director</dt>
                        <dd className="font-medium text-zinc-200">{movie.director}</dd>
                      </div>
                      <div className="flex flex-col gap-0.5 sm:flex-row sm:gap-3">
                        <dt className="w-24 shrink-0 text-zinc-500">Cast</dt>
                        <dd className="text-zinc-200">{movie.cast.join(', ')}</dd>
                      </div>
                    </dl>
                  </div>

                  <div className="mt-8 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setShowTrailer(true)}
                      className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#E5A93C] px-5 py-2.5 text-sm font-semibold text-[#07080A] whitespace-nowrap transition-colors duration-150 hover:bg-[#f0b94f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C]"
                    >
                      <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                      <span>Watch Trailer</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onToggleFavorite(movie.id)}
                      aria-pressed={isFavorite}
                      className={`inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg border px-5 py-2.5 text-sm font-medium whitespace-nowrap transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C] ${
                        isFavorite
                          ? 'border-[#E5A93C]/50 bg-[#E5A93C]/12 text-[#E5A93C] hover:bg-[#E5A93C]/20'
                          : 'border-white/15 bg-white/[0.03] text-zinc-200 hover:border-white/30 hover:bg-white/[0.07]'
                      }`}
                    >
                      <Heart
                        className={`h-4 w-4 ${isFavorite ? 'fill-[#E5A93C]' : ''}`}
                        aria-hidden="true"
                      />
                      <span>
                        {isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
