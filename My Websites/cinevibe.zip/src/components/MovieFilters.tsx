import { RotateCcw, Search, X } from 'lucide-react';
import { GENRES } from '../data/movies';
import type { Genre } from '../types/movie';

export type RatingFilter = 'all' | '8.0' | '8.5' | '9.0';
export type YearFilter = 'all' | '2020s' | '2010s' | '2000s';

interface MovieFiltersProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  selectedGenre: Genre | 'All';
  onGenreChange: (genre: Genre | 'All') => void;
  selectedRating: RatingFilter;
  onRatingChange: (rating: RatingFilter) => void;
  selectedYear: YearFilter;
  onYearChange: (year: YearFilter) => void;
  onResetFilters: () => void;
  resultCount: number;
  totalCount: number;
  searchInputRef?: React.RefObject<HTMLInputElement | null>;
}

export function MovieFilters({
  searchQuery,
  onSearchChange,
  selectedGenre,
  onGenreChange,
  selectedRating,
  onRatingChange,
  selectedYear,
  onYearChange,
  onResetFilters,
  resultCount,
  totalCount,
  searchInputRef,
}: MovieFiltersProps) {
  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedGenre !== 'All' ||
    selectedRating !== 'all' ||
    selectedYear !== 'all';

  return (
    <div className="space-y-5">
      {/* Search + Select Dropdowns */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-12">
        {/* Search Input */}
        <div className="relative md:col-span-6">
          <label htmlFor="movie-search" className="sr-only">
            Search movies by title
          </label>
          <Search
            className="pointer-events-none absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-zinc-400"
            aria-hidden="true"
          />
          <input
            ref={searchInputRef}
            id="movie-search"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search movies by title..."
            className="h-11 w-full rounded-lg border border-white/15 bg-[#111318] pr-10 pl-10 text-sm text-[#F4F4F5] placeholder:text-zinc-500 transition-colors focus:border-[#E5A93C] focus:outline-none"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              aria-label="Clear search query"
              className="absolute top-1/2 right-2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded text-zinc-400 hover:bg-white/10 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Rating Filter */}
        <div className="md:col-span-3">
          <label htmlFor="rating-filter" className="sr-only">
            Filter by rating
          </label>
          <select
            id="rating-filter"
            value={selectedRating}
            onChange={(e) => onRatingChange(e.target.value as RatingFilter)}
            className="h-11 w-full rounded-lg border border-white/15 bg-[#111318] px-3.5 text-sm text-[#F4F4F5] transition-colors focus:border-[#E5A93C] focus:outline-none"
          >
            <option value="all">All Ratings</option>
            <option value="8.0">Rating 8.0+</option>
            <option value="8.5">Rating 8.5+</option>
            <option value="9.0">Rating 9.0+</option>
          </select>
        </div>

        {/* Year Filter */}
        <div className="md:col-span-3">
          <label htmlFor="year-filter" className="sr-only">
            Filter by release year
          </label>
          <select
            id="year-filter"
            value={selectedYear}
            onChange={(e) => onYearChange(e.target.value as YearFilter)}
            className="h-11 w-full rounded-lg border border-white/15 bg-[#111318] px-3.5 text-sm text-[#F4F4F5] transition-colors focus:border-[#E5A93C] focus:outline-none"
          >
            <option value="all">All Release Years</option>
            <option value="2020s">2020 – Present</option>
            <option value="2010s">2010 – 2019</option>
            <option value="2000s">2000 – 2009</option>
          </select>
        </div>
      </div>

      {/* Genre Tabs + Result Count */}
      <div
        id="genres"
        className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4"
      >
        <div
          role="group"
          aria-label="Filter movies by genre"
          className="flex flex-wrap items-center gap-2"
        >
          <button
            type="button"
            onClick={() => onGenreChange('All')}
            aria-pressed={selectedGenre === 'All'}
            className={`min-h-[40px] rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-[#E5A93C] ${
              selectedGenre === 'All'
                ? 'bg-[#E5A93C] text-[#07080A]'
                : 'border border-white/10 bg-[#111318] text-zinc-300 hover:border-white/25 hover:text-white'
            }`}
          >
            All Genres
          </button>

          {GENRES.map((genre) => {
            const isSelected = selectedGenre === genre;
            return (
              <button
                key={genre}
                type="button"
                onClick={() => onGenreChange(genre)}
                aria-pressed={isSelected}
                className={`min-h-[40px] rounded-lg px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-[#E5A93C] ${
                  isSelected
                    ? 'bg-[#E5A93C] text-[#07080A]'
                    : 'border border-white/10 bg-[#111318] text-zinc-300 hover:border-white/25 hover:text-white'
                }`}
              >
                {genre}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-3 text-xs text-zinc-400">
          <span className="font-mono tabular-nums">
            Showing {resultCount} of {totalCount} movies
          </span>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={onResetFilters}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-white/15 px-3 py-1.5 text-xs font-medium text-zinc-200 whitespace-nowrap transition-colors hover:bg-white/5"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
