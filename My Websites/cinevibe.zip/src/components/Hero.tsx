import { ArrowDownRight } from 'lucide-react';
import { motion } from 'motion/react';
import { HERO_CINEMA_IMAGE } from '../data/movies';

interface HeroProps {
  totalMovies: number;
  totalGenres: number;
  averageRating: string;
  favoritesCount: number;
  onExploreClick: () => void;
  onJumpFeatured: () => void;
}

export function Hero({
  totalMovies,
  totalGenres,
  averageRating,
  favoritesCount,
  onExploreClick,
  onJumpFeatured,
}: HeroProps) {
  return (
    <section
      id="home"
      className="border-b border-white/10 bg-[#07080A]"
    >
      <div className="mx-auto max-w-[1280px] px-4 pt-10 pb-12 sm:px-6 lg:px-8 lg:pt-14 lg:pb-16">
        <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12 lg:gap-10">
          {/* Left Column: Editorial Headline & Primary CTA */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-center lg:col-span-6"
          >
            <p className="text-sm font-medium tracking-wide text-[#E5A93C]">
              Curated Cinema Guide
            </p>
            <h1
              className="font-display mt-3 text-[clamp(2.25rem,4vw,3.75rem)] font-bold leading-[1.06] tracking-tight text-[#F4F4F5]"
              style={{ textWrap: 'balance' }}
            >
              Your Next Movie Night Starts Here.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-zinc-400 sm:text-lg">
              Discover movies you&apos;ll love, from timeless classics to the latest releases.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onExploreClick}
                className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-lg bg-[#E5A93C] px-6 py-3 text-sm font-semibold text-[#07080A] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[#f0b94f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C]"
              >
                <span>Explore Movies</span>
                <ArrowDownRight className="h-4 w-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={onJumpFeatured}
                className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-white/15 bg-white/[0.03] px-5 py-3 text-sm font-medium text-zinc-200 whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-white/30 hover:bg-white/[0.07] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E5A93C]"
              >
                Featured Pick
              </button>
            </div>
          </motion.div>

          {/* Right Column: Cinematic Screening Showcase */}
          <motion.div
            initial={{ opacity: 0, scale: 0.985 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.45, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
            className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#111318] lg:col-span-6"
          >
            <div className="aspect-[16/9] h-full w-full lg:aspect-auto lg:min-h-[380px]">
              <img
                src={HERO_CINEMA_IMAGE}
                alt="Atmospheric cinema screening room illuminated by a warm projector beam"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
            </div>
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#07080A]/90 via-[#07080A]/25 to-transparent"
            />
            <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-6">
              <div>
                <p className="text-xs font-medium text-[#E5A93C]">
                  Now Showing on CineVibe
                </p>
                <p className="mt-1 font-display text-lg font-semibold text-[#F4F4F5]">
                  Handpicked films, ratings, and interactive trailer previews
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-Width 4-Column Catalog Summary Strip */}
        <div className="mt-10 grid grid-cols-2 gap-6 border-t border-white/10 pt-8 sm:grid-cols-4">
          <div>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F4F5]">
              {totalMovies}
            </p>
            <p className="mt-1 text-sm text-zinc-400">Curated Films</p>
          </div>
          <div>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F4F5]">
              {totalGenres}
            </p>
            <p className="mt-1 text-sm text-zinc-400">Distinct Genres</p>
          </div>
          <div>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#E5A93C]">
              {averageRating}
            </p>
            <p className="mt-1 text-sm text-zinc-400">Average IMDb Score</p>
          </div>
          <div>
            <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F4F5]">
              {favoritesCount}
            </p>
            <p className="mt-1 text-sm text-zinc-400">Saved Favorites</p>
          </div>
        </div>
      </div>
    </section>
  );
}
