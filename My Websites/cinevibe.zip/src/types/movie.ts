export type Genre =
  | 'Sci-Fi'
  | 'Action'
  | 'Animation'
  | 'Drama'
  | 'Crime'
  | 'Thriller';

export interface TrailerScene {
  timestamp: string;
  caption: string;
}

export interface Movie {
  id: string;
  title: string;
  genre: Genre;
  secondaryGenre?: Genre;
  year: number;
  rating: number;
  runtime: string;
  director: string;
  cast: string[];
  description: string;
  poster: string;
  accentColor: string;
  isFeatured?: boolean;
  isTrending?: boolean;
  isTopRated?: boolean;
  trailerTagline: string;
  trailerScenes: TrailerScene[];
}
