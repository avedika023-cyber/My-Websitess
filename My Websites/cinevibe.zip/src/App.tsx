/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { Film, Heart, RotateCcw, Sparkles, TrendingUp, Trophy } from 'lucide-react';
import { AboutSection } from './components/AboutSection';
import { FeaturedMovie } from './components/FeaturedMovie';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { MovieCard } from './components/MovieCard';
import {
  MovieFilters,
  type RatingFilter,
  type YearFilter,
} from './components/MovieFilters';
import { MovieModal } from './components/MovieModal';
import { Navbar } from './components/Navbar';
import { GENRES, MOVIES } from './data/movies';
import type { Genre, Movie } from './types/movie';

const FAVORITES_STORAGE_KEY = 'cinevibe_favorites_v1';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>('home');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGenre, setSelectedGenre] = useState<Genre | 'All'>('All');
  const [selectedRating, setSelectedRating] = useState<RatingFilter>('all');
  const [selectedYear, setSelectedYear] = useState<YearFilter>('all');
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);

  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    try {
      const saved = window.localStorage.getItem(FAVORITES_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : [];
      }
    } catch {
      // Ignore storage read errors in restricted environments
    }
    return ['inception', 'interstellar'];
  });

  const searchInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem(
        FAVORITES_STORAGE_KEY,
        JSON.stringify(favoriteIds)
      );
    } catch {
      // Ignore storage write errors
    }
  }, [favoriteIds]);

  const toggleFavorite = (movieId: string) => {
    setFavoriteIds((prev) =>
      prev.includes(movieId)
        ? prev.filter((id) => id !== movieId)
        : [...prev, movieId]
    );
  };

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedGenre('All');
    setSelectedRating('all');
    setSelectedYear('all');
  };

  const navigateToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const target = document.getElementById(sectionId);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (sectionId === 'movies') {
      window.setTimeout(() => {
        searchInputRef.current?.focus({ preventScroll: true });
      }, 350);
    }
  };

  const featuredMovie = useMemo(
    () => MOVIES.find((m) => m.isFeatured) ?? MOVIES[0],
    []
  );

  const trendingMovies = useMemo(
    () => MOVIES.filter((m) => m.isTrending).slice(0, 4),
    []
  );

  const topRatedMovies = useMemo(
    () =>
      [...MOVIES]
        .filter((m) => m.isTopRated)
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 4),
    []
  );

  const filteredMovies = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return MOVIES.filter((movie) => {
      const matchesTitle =
        query === '' || movie.title.toLowerCase().includes(query);

      const matchesGenre =
        selectedGenre === 'All' ||
        movie.genre === selectedGenre ||
        movie.secondaryGenre === selectedGenre;

      const matchesRating =
        selectedRating === 'all' || movie.rating >= Number(selectedRating);

      const matchesYear =
        selectedYear === 'all' ||
        (selectedYear === '2020s' && movie.year >= 2020) ||
        (selectedYear === '2010s' && movie.year >= 2010 && movie.year <= 2019) ||
        (selectedYear === '2000s' && movie.year >= 2000 && movie.year <= 2009);

      return matchesTitle && matchesGenre && matchesRating && matchesYear;
    });
  }, [searchQuery, selectedGenre, selectedRating, selectedYear]);

  const favoriteMovies = useMemo(
    () => MOVIES.filter((movie) => favoriteIds.includes(movie.id)),
    [favoriteIds]
  );

  const averageRating = useMemo(() => {
    const sum = MOVIES.reduce((acc, m) => acc + m.rating, 0);
    return (sum / MOVIES.length).toFixed(1);
  }, []);

  return (
    <div className="min-h-screen bg-[#07080A] text-[#F4F4F5]">
      <Navbar activeSection={activeSection} onNavigate={navigateToSection} />

      <main>
        {/* Hero Section */}
        <Hero
          totalMovies={MOVIES.length}
          totalGenres={GENRES.length}
          averageRating={averageRating}
          favoritesCount={favoriteMovies.length}
          onExploreClick={() => navigateToSection('movies')}
          onJumpFeatured={() => navigateToSection('featured')}
        />

        {/* Featured Movie Spotlight */}
        <FeaturedMovie
          movie={featuredMovie}
          isFavorite={favoriteIds.includes(featuredMovie.id)}
          onViewDetails={setSelectedMovie}
          onToggleFavorite={toggleFavorite}
        />

        {/* Trending This Week */}
        <section
          aria-labelledby="trending-heading"
          className="border-t border-white/10 bg-[#07080A]"
        >
          <div className="mx-auto max-w-[1280px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
            <div className="mb-8 flex items-end justify-between gap-4">
              <div>
                <p className="flex items-center gap-2 text-sm font-medium text-[#E5A93C]">
                  <TrendingUp className="h-4 w-4" aria-hidden="true" />
                  <span>Popular Right Now</span>
                </p>
                <h2
                  id="trending-heading"
                  className="font-display mt-1 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
                >
                  Trending This Week
                </h2>
              </div>
              <button
                type="button"
                onClick={() => navigateToSection('movies')}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-[#E5A93C] whitespace-nowrap"
              >
                See all movies
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {trendingMovies.map((movie) => (
                <MovieCard
                  key={`trending-${movie.id}`}
                  movie={movie}
                  isFavorite={favoriteIds.includes(movie.id)}
                  onViewDetails={setSelectedMovie}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Top Rated Section */}
        <section
          aria-labelledby="top-rated-heading"
          className="border-t border-white/10 bg-[#0A0C10]"
        >
          <div className="mx-auto max-w-[1280px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
            <div className="mb-8 flex items-end justify-between gap-4">
              <div>
                <p className="flex items-center gap-2 text-sm font-medium text-[#E5A93C]">
                  <Trophy className="h-4 w-4" aria-hidden="true" />
                  <span>Critically Acclaimed</span>
                </p>
                <h2
                  id="top-rated-heading"
                  className="font-display mt-1 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
                >
                  Top Rated
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedRating('8.5');
                  navigateToSection('movies');
                }}
                className="text-sm font-medium text-zinc-400 transition-colors hover:text-[#E5A93C] whitespace-nowrap"
              >
                Filter 8.5+ rated
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {topRatedMovies.map((movie) => (
                <MovieCard
                  key={`top-rated-${movie.id}`}
                  movie={movie}
                  isFavorite={favoriteIds.includes(movie.id)}
                  onViewDetails={setSelectedMovie}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Full Movies Catalog + Search & Filters */}
        <section
          id="movies"
          aria-labelledby="catalog-heading"
          className="border-t border-white/10 bg-[#07080A]"
        >
          <div className="mx-auto max-w-[1280px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
            <div className="mb-8">
              <p className="flex items-center gap-2 text-sm font-medium text-[#E5A93C]">
                <Film className="h-4 w-4" aria-hidden="true" />
                <span>Complete Catalog</span>
              </p>
              <h2
                id="catalog-heading"
                className="font-display mt-1 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
              >
                Browse Movies &amp; Genres
              </h2>
            </div>

            <MovieFilters
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              selectedGenre={selectedGenre}
              onGenreChange={setSelectedGenre}
              selectedRating={selectedRating}
              onRatingChange={setSelectedRating}
              selectedYear={selectedYear}
              onYearChange={setSelectedYear}
              onResetFilters={resetFilters}
              resultCount={filteredMovies.length}
              totalCount={MOVIES.length}
              searchInputRef={searchInputRef}
            />

            {filteredMovies.length > 0 ? (
              <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {filteredMovies.map((movie) => (
                  <MovieCard
                    key={movie.id}
                    movie={movie}
                    isFavorite={favoriteIds.includes(movie.id)}
                    onViewDetails={setSelectedMovie}
                    onToggleFavorite={toggleFavorite}
                  />
                ))}
              </div>
            ) : (
              <div className="mt-10 flex flex-col items-center justify-center rounded-2xl border border-white/10 bg-[#111318] px-6 py-14 text-center">
                <Sparkles className="h-8 w-8 text-zinc-500" aria-hidden="true" />
                <h3 className="font-display mt-4 text-lg font-semibold text-[#F4F4F5]">
                  No movies match your filters
                </h3>
                <p className="mt-2 max-w-md text-sm text-zinc-400">
                  Try clearing your search query or adjusting the genre, rating, or release year filter.
                </p>
                <button
                  type="button"
                  onClick={resetFilters}
                  className="mt-6 inline-flex min-h-[42px] items-center gap-2 rounded-lg bg-[#E5A93C] px-5 py-2 text-sm font-semibold text-[#07080A] transition-colors hover:bg-[#f0b94f]"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  <span>Reset All Filters</span>
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Favorites Watchlist Section */}
        <section
          id="favorites"
          aria-labelledby="favorites-heading"
          className="border-t border-white/10 bg-[#0A0C10]"
        >
          <div className="mx-auto max-w-[1280px] px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
            <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="flex items-center gap-2 text-sm font-medium text-[#E5A93C]">
                  <Heart className="h-4 w-4 fill-[#E5A93C]" aria-hidden="true" />
                  <span>Your Saved Lineup</span>
                </p>
                <h2
                  id="favorites-heading"
                  className="font-display mt-1 text-2xl font-bold tracking-tight text-[#F4F4F5] sm:text-3xl"
                >
                  Favorites{' '}
                  <span className="font-mono text-xl font-medium tabular-nums text-zinc-400">
                    ({favoriteMovies.length})
                  </span>
                </h2>
              </div>

              {favoriteMovies.length > 0 && (
                <button
                  type="button"
                  onClick={() => setFavoriteIds([])}
                  className="inline-flex min-h-[40px] items-center rounded-lg border border-white/15 px-4 py-2 text-xs font-medium text-zinc-300 transition-colors hover:border-white/30 hover:bg-white/[0.06] hover:text-white"
                >
                  Clear Favorites
                </button>
              )}
            </div>

            {favoriteMovies.length > 0 ? (
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {favoriteMovies.map((movie) => (
                  <MovieCard
                    key={`fav-${movie.id}`}
                    movie={movie}
                    isFavorite={true}
                    onViewDetails={setSelectedMovie}
                    onToggleFavorite={toggleFavorite}
                  />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center rounded-2xl border border-white/10 bg-[#111318] px-6 py-14 text-center">
                <Heart className="h-8 w-8 text-zinc-500" aria-hidden="true" />
                <h3 className="font-display mt-4 text-lg font-semibold text-[#F4F4F5]">
                  Your Favorites list is empty
                </h3>
                <p className="mt-2 max-w-md text-sm text-zinc-400">
                  Click the Favorite button on any movie card to save films here for your next movie night.
                </p>
                <button
                  type="button"
                  onClick={() => navigateToSection('movies')}
                  className="mt-6 inline-flex min-h-[42px] items-center rounded-lg bg-[#E5A93C] px-5 py-2 text-sm font-semibold text-[#07080A] transition-colors hover:bg-[#f0b94f]"
                >
                  Discover Movies
                </button>
              </div>
            )}
          </div>
        </section>

        {/* About Section */}
        <AboutSection />
      </main>

      <Footer onNavigate={navigateToSection} />

      {/* Movie Details & Trailer Modal */}
      <MovieModal
        movie={selectedMovie}
        isFavorite={selectedMovie ? favoriteIds.includes(selectedMovie.id) : false}
        onClose={() => setSelectedMovie(null)}
        onToggleFavorite={toggleFavorite}
      />
    </div>
  );
}
