import { ArrowDown, RotateCcw } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Header } from './components/Header';
import { PomodoroTimer } from './components/PomodoroTimer';
import { ProgressPanel } from './components/ProgressPanel';
import { QuoteCard } from './components/QuoteCard';
import { SubjectCards } from './components/SubjectCards';
import { TaskBoard } from './components/TaskBoard';
import { WeeklyTimetable } from './components/WeeklyTimetable';
import {
  INITIAL_SUBJECTS,
  INITIAL_TASKS,
  INITIAL_TIMETABLE,
  MOTIVATIONAL_QUOTES,
} from './data/initialData';
import { StudyTask, SubjectId, SubjectInfo, TimetableEntry } from './types';

const STORAGE_KEYS = {
  subjects: 'studysphere_subjects_v1',
  tasks: 'studysphere_tasks_v1',
  timetable: 'studysphere_timetable_v1',
  sessions: 'studysphere_sessions_v1',
};

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [subjects, setSubjects] = useState<SubjectInfo[]>(() =>
    readStorage(STORAGE_KEYS.subjects, INITIAL_SUBJECTS)
  );
  const [tasks, setTasks] = useState<StudyTask[]>(() =>
    readStorage(STORAGE_KEYS.tasks, INITIAL_TASKS)
  );
  const [timetable, setTimetable] = useState<TimetableEntry[]>(() =>
    readStorage(STORAGE_KEYS.timetable, INITIAL_TIMETABLE)
  );
  const [sessionsCompleted, setSessionsCompleted] = useState<number>(() =>
    readStorage(STORAGE_KEYS.sessions, 2)
  );

  const [activeSubjectId, setActiveSubjectId] = useState<SubjectId>('java');
  const [activeSection, setActiveSection] = useState<string>('home');
  const timerSectionRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.subjects, JSON.stringify(subjects));
      window.localStorage.setItem(STORAGE_KEYS.tasks, JSON.stringify(tasks));
      window.localStorage.setItem(STORAGE_KEYS.timetable, JSON.stringify(timetable));
      window.localStorage.setItem(STORAGE_KEYS.sessions, JSON.stringify(sessionsCompleted));
    } catch {
      // Ignore storage quota errors
    }
  }, [subjects, tasks, timetable, sessionsCompleted]);

  const activeSubject =
    subjects.find((s) => s.id === activeSubjectId) ?? subjects[0];

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleStartFocusCTA = () => {
    setActiveSection('tasks');
    timerSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const handleFocusSubject = (id: SubjectId) => {
    setActiveSubjectId(id);
    timerSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const handleLogStudyTime = (id: SubjectId, minutes: number) => {
    setSubjects((prev) =>
      prev.map((subj) => {
        if (subj.id !== id) return subj;
        const nextMinutes = subj.minutesStudied + minutes;
        const nextModules =
          subj.modulesCompleted < subj.totalModules && nextMinutes % 60 === 0
            ? subj.modulesCompleted + 1
            : subj.modulesCompleted;
        return {
          ...subj,
          minutesStudied: nextMinutes,
          modulesCompleted: nextModules,
        };
      })
    );
  };

  const handleSessionComplete = (minutesEarned: number) => {
    setSessionsCompleted((prev) => prev + 1);
    handleLogStudyTime(activeSubjectId, minutesEarned);
  };

  const handleAddTask = (title: string, subjectId: SubjectId | 'general') => {
    const newTask: StudyTask = {
      id: `task-${Date.now()}`,
      title,
      subjectId,
      completed: false,
      createdAt: 'Today',
    };
    setTasks((prev) => [newTask, ...prev]);
  };

  const handleToggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== id));
  };

  const handleClearCompleted = () => {
    setTasks((prev) => prev.filter((task) => !task.completed));
  };

  const handleToggleTimetableEntry = (id: string) => {
    setTimetable((prev) =>
      prev.map((entry) =>
        entry.id === id ? { ...entry, completed: !entry.completed } : entry
      )
    );
  };

  const handleUpdateTimetableEntry = (
    id: string,
    subjectId: SubjectId | 'review',
    topic: string
  ) => {
    setTimetable((prev) =>
      prev.map((entry) =>
        entry.id === id ? { ...entry, subjectId, topic } : entry
      )
    );
  };

  const handleResetDemoData = () => {
    setSubjects(INITIAL_SUBJECTS);
    setTasks(INITIAL_TASKS);
    setTimetable(INITIAL_TIMETABLE);
    setSessionsCompleted(2);
    setActiveSubjectId('java');
    try {
      Object.values(STORAGE_KEYS).forEach((k) => window.localStorage.removeItem(k));
    } catch {
      // Ignore
    }
  };

  const completedTasksCount = tasks.filter((t) => t.completed).length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      <Header
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onStartFocus={handleStartFocusCTA}
      />

      <main className="mx-auto w-full max-w-6xl flex-1 space-y-10 px-4 py-8 sm:px-6 lg:px-8">
        {/* Home Hero + Motivational Quote Section */}
        <section
          id="home"
          aria-labelledby="welcome-heading"
          className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-12 scroll-mt-20"
        >
          <div className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 sm:p-8 lg:col-span-7">
            <div>
              <p className="text-xs font-medium text-indigo-600">
                Student Study Dashboard · {subjects.length} Active Courses
              </p>
              <h1
                id="welcome-heading"
                className="mt-3 font-display text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl [text-wrap:balance]"
              >
                Study Smarter, Not Harder.
              </h1>
              <p className="mt-3 max-w-xl text-base leading-relaxed text-slate-600">
                Keep your subjects, daily tasks, 25-minute Pomodoro focus blocks, and weekly timetable organized in one calm workspace.
              </p>
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleStartFocusCTA}
                className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
              >
                <span>Open Focus Timer</span>
              </button>

              <button
                type="button"
                onClick={() => handleNavigate('tasks')}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
              >
                <span>Manage Tasks ({completedTasksCount}/{tasks.length})</span>
                <ArrowDown className="h-4 w-4 text-slate-400" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 flex">
            <QuoteCard quotes={MOTIVATIONAL_QUOTES} />
          </div>
        </section>

        {/* 4 Subject Cards */}
        <SubjectCards
          subjects={subjects}
          activeSubjectId={activeSubjectId}
          onFocusSubject={handleFocusSubject}
          onLogStudyTime={handleLogStudyTime}
        />

        {/* Tasks + Pomodoro Timer & Progress */}
        <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <TaskBoard
              tasks={tasks}
              subjects={subjects}
              onAddTask={handleAddTask}
              onToggleTask={handleToggleTask}
              onDeleteTask={handleDeleteTask}
              onClearCompleted={handleClearCompleted}
            />
          </div>

          <div className="space-y-6 lg:col-span-5">
            <PomodoroTimer
              activeSubject={activeSubject}
              sessionsCompleted={sessionsCompleted}
              onSessionComplete={handleSessionComplete}
              timerSectionRef={timerSectionRef}
            />

            <ProgressPanel
              tasks={tasks}
              subjects={subjects}
              sessionsCompleted={sessionsCompleted}
            />
          </div>
        </div>

        {/* Weekly Study Timetable */}
        <WeeklyTimetable
          entries={timetable}
          subjects={subjects}
          onToggleEntry={handleToggleTimetableEntry}
          onUpdateEntry={handleUpdateTimetableEntry}
        />
      </main>

      {/* Clean Footer */}
      <footer className="mt-10 border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-xs text-slate-500">
            StudySphere · Built for focused student learning
          </p>

          <button
            type="button"
            onClick={handleResetDemoData}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 rounded"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Sample Data</span>
          </button>
        </div>
      </footer>
    </div>
  );
}
