import { BrainCircuit, Coffee, Database, Globe, Plus, Timer } from 'lucide-react';
import { SubjectId, SubjectInfo } from '../types';

interface SubjectCardsProps {
  subjects: SubjectInfo[];
  activeSubjectId: SubjectId;
  onFocusSubject: (id: SubjectId) => void;
  onLogStudyTime: (id: SubjectId, minutes: number) => void;
}

function SubjectIcon({ id, className }: { id: SubjectId; className?: string }) {
  switch (id) {
    case 'java':
      return <Coffee className={className} />;
    case 'web':
      return <Globe className={className} />;
    case 'database':
      return <Database className={className} />;
    case 'ai':
      return <BrainCircuit className={className} />;
  }
}

function formatHours(minutes: number): string {
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hrs === 0) return `${mins}m`;
  if (mins === 0) return `${hrs}h`;
  return `${hrs}h ${mins}m`;
}

export function SubjectCards({
  subjects,
  activeSubjectId,
  onFocusSubject,
  onLogStudyTime,
}: SubjectCardsProps) {
  return (
    <section id="subjects" aria-labelledby="subjects-heading" className="scroll-mt-20">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 id="subjects-heading" className="font-display text-2xl font-bold tracking-tight text-slate-900">
            Core Subjects
          </h2>
          <p className="mt-1 text-sm text-slate-600">
            Select a subject to pair with your Pomodoro timer or log completed study blocks.
          </p>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {subjects.map((subject) => {
          const isSelected = activeSubjectId === subject.id;
          const pct = Math.round((subject.modulesCompleted / subject.totalModules) * 100);

          return (
            <article
              key={subject.id}
              className={`flex flex-col justify-between rounded-xl border bg-white p-5 transition-colors duration-150 ${
                isSelected
                  ? 'border-indigo-500 ring-1 ring-indigo-500/20'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-lg ${subject.bgTintClass} ${subject.textAccentClass}`}
                  >
                    <SubjectIcon id={subject.id} className="h-5 w-5" />
                  </div>
                  <span className="text-xs font-mono tabular-nums font-medium text-slate-500">
                    {pct}%
                  </span>
                </div>

                <h3 className="mt-4 font-display text-lg font-semibold text-slate-900">
                  {subject.name}
                </h3>

                <p className="mt-1.5 text-sm leading-relaxed text-slate-600">
                  {subject.summary}
                </p>
              </div>

              <div className="mt-5">
                <div className="flex items-center justify-between text-xs text-slate-500 tabular-nums">
                  <span>
                    {subject.modulesCompleted}/{subject.totalModules} modules
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{formatHours(subject.minutesStudied)} studied</span>
                </div>

                <div
                  className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100"
                  role="progressbar"
                  aria-valuenow={pct}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={`${subject.name} progress ${pct}%`}
                >
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${subject.barClass}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>

                <div className="mt-4 flex items-center gap-2 border-t border-slate-100 pt-3">
                  <button
                    type="button"
                    onClick={() => onFocusSubject(subject.id)}
                    className={`flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                      isSelected
                        ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                        : 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                    }`}
                  >
                    <Timer className="h-3.5 w-3.5" />
                    <span>{isSelected ? 'Focused' : 'Focus 25m'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onLogStudyTime(subject.id, 30)}
                    title={`Log 30 minutes for ${subject.name}`}
                    className="inline-flex items-center justify-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>30m</span>
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
