import { CheckCircle2 } from 'lucide-react';
import { StudyTask, SubjectInfo } from '../types';

interface ProgressPanelProps {
  tasks: StudyTask[];
  subjects: SubjectInfo[];
  sessionsCompleted: number;
}

export function ProgressPanel({ tasks, subjects, sessionsCompleted }: ProgressPanelProps) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.completed).length;
  const completionPct = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

  const totalMinutes = subjects.reduce((sum, s) => sum + s.minutesStudied, 0);
  const totalHours = (totalMinutes / 60).toFixed(1);

  return (
    <section
      id="progress"
      aria-labelledby="progress-heading"
      className="rounded-xl border border-slate-200 bg-white p-6 scroll-mt-20"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 id="progress-heading" className="font-display text-lg font-bold text-slate-900">
            Study Progress
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Real-time completion across your study tasks
          </p>
        </div>

        <span className="inline-flex items-center gap-1.5 text-sm font-mono font-bold tabular-nums text-indigo-600">
          <CheckCircle2 className="h-4 w-4" />
          {completionPct}%
        </span>
      </div>

      {/* Main Progress Bar */}
      <div className="mt-5">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium text-slate-700">Completed Tasks</span>
          <span className="font-mono font-semibold tabular-nums text-slate-900">
            {completedTasks} / {totalTasks}
          </span>
        </div>

        <div
          className="mt-2.5 h-3 w-full overflow-hidden rounded-full bg-slate-100"
          role="progressbar"
          aria-valuenow={completionPct}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-label={`Task completion ${completionPct}%`}
        >
          <div
            className="h-full rounded-full bg-indigo-600 transition-all duration-300"
            style={{ width: `${completionPct}%` }}
          />
        </div>

        <p className="mt-2 text-xs text-slate-500">
          {totalTasks === 0
            ? 'Add tasks to start tracking your progress.'
            : completedTasks === totalTasks
            ? 'All tasks completed. Great work today!'
            : `${totalTasks - completedTasks} ${
                totalTasks - completedTasks === 1 ? 'task' : 'tasks'
              } remaining in your study queue.`}
        </p>
      </div>

      {/* Summary Metrics Row */}
      <div className="mt-5 grid grid-cols-2 gap-4 border-t border-slate-100 pt-4">
        <div>
          <p className="text-xs text-slate-500">Total Study Time</p>
          <p className="mt-0.5 font-mono text-lg font-bold tabular-nums text-slate-900">
            {totalHours} hrs
          </p>
        </div>
        <div>
          <p className="text-xs text-slate-500">Focus Sessions</p>
          <p className="mt-0.5 font-mono text-lg font-bold tabular-nums text-slate-900">
            {sessionsCompleted} done
          </p>
        </div>
      </div>

      {/* Per-Subject Breakdown */}
      <div className="mt-5 border-t border-slate-100 pt-4">
        <p className="text-xs font-semibold text-slate-700">Subject Task Breakdown</p>
        <ul className="mt-3 space-y-2.5">
          {subjects.map((subj) => {
            const subjTasks = tasks.filter((t) => t.subjectId === subj.id);
            const subjDone = subjTasks.filter((t) => t.completed).length;
            const subjPct =
              subjTasks.length === 0 ? 0 : Math.round((subjDone / subjTasks.length) * 100);

            return (
              <li key={subj.id} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700">{subj.name}</span>
                  <span className="font-mono tabular-nums text-slate-500">
                    {subjDone}/{subjTasks.length} tasks
                  </span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${subj.barClass}`}
                    style={{ width: `${subjPct}%` }}
                  />
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
