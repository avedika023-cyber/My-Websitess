import { Check, Plus, Trash2 } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { StudyTask, SubjectId, SubjectInfo } from '../types';

interface TaskBoardProps {
  tasks: StudyTask[];
  subjects: SubjectInfo[];
  onAddTask: (title: string, subjectId: SubjectId | 'general') => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onClearCompleted: () => void;
}

type TaskFilter = 'all' | 'pending' | 'completed';

export function TaskBoard({
  tasks,
  subjects,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onClearCompleted,
}: TaskBoardProps) {
  const [title, setTitle] = useState('');
  const [subjectId, setSubjectId] = useState<SubjectId | 'general'>('java');
  const [filter, setFilter] = useState<TaskFilter>('all');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = title.trim();
    if (!trimmed) return;
    onAddTask(trimmed, subjectId);
    setTitle('');
  };

  const subjectMap = Object.fromEntries(subjects.map((s) => [s.id, s]));

  const filteredTasks = tasks.filter((task) => {
    if (filter === 'pending') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const completedCount = tasks.filter((t) => t.completed).length;

  return (
    <section
      id="tasks"
      aria-labelledby="tasks-heading"
      className="flex flex-col rounded-xl border border-slate-200 bg-white p-6 scroll-mt-20"
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 id="tasks-heading" className="font-display text-xl font-bold text-slate-900">
            Study To-Do List
          </h2>
          <p className="mt-0.5 text-sm text-slate-600 tabular-nums">
            {tasks.length - completedCount} pending · {completedCount} completed
          </p>
        </div>

        {/* Filter Segmented Tabs */}
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
          {(['all', 'pending', 'completed'] as TaskFilter[]).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                filter === tab
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Add Task Form */}
      <form onSubmit={handleSubmit} className="mt-5 flex flex-col gap-2.5 sm:flex-row">
        <label htmlFor="new-task-input" className="sr-only">
          New study task
        </label>
        <input
          id="new-task-input"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Add a study task (e.g., Practice SQL joins)..."
          className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
        />

        <label htmlFor="task-subject-select" className="sr-only">
          Subject
        </label>
        <select
          id="task-subject-select"
          value={subjectId}
          onChange={(e) => setSubjectId(e.target.value as SubjectId | 'general')}
          className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2.5 text-sm font-medium text-slate-700 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
        >
          {subjects.map((subj) => (
            <option key={subj.id} value={subj.id}>
              {subj.name}
            </option>
          ))}
          <option value="general">General</option>
        </select>

        <button
          type="submit"
          className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
        >
          <Plus className="h-4 w-4" />
          <span>Add Task</span>
        </button>
      </form>

      {/* Task Items */}
      <div className="mt-5 divide-y divide-slate-100 border-t border-slate-100">
        {filteredTasks.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-sm font-medium text-slate-700">
              {tasks.length === 0
                ? 'Your study list is clear.'
                : `No ${filter} tasks right now.`}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Add a task above to plan your next study session.
            </p>
          </div>
        ) : (
          filteredTasks.map((task) => {
            const subject = task.subjectId === 'general' ? null : subjectMap[task.subjectId];
            return (
              <div
                key={task.id}
                className="group flex items-center justify-between gap-3 py-3.5 transition-colors hover:bg-slate-50/70 px-1 rounded-md"
              >
                <div className="flex min-w-0 flex-1 items-start gap-3">
                  <button
                    type="button"
                    onClick={() => onToggleTask(task.id)}
                    aria-label={
                      task.completed
                        ? `Mark "${task.title}" as incomplete`
                        : `Mark "${task.title}" as completed`
                    }
                    aria-pressed={task.completed}
                    className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                      task.completed
                        ? 'border-indigo-600 bg-indigo-600 text-white'
                        : 'border-slate-300 bg-white hover:border-indigo-500'
                    }`}
                  >
                    {task.completed && <Check className="h-3.5 w-3.5 stroke-[2.5]" />}
                  </button>

                  <div className="min-w-0 flex-1">
                    <p
                      className={`text-sm font-medium leading-snug break-words ${
                        task.completed ? 'text-slate-400 line-through' : 'text-slate-800'
                      }`}
                    >
                      {task.title}
                    </p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      <span className={subject ? `font-medium ${subject.textAccentClass}` : 'font-medium text-slate-600'}>
                        {subject ? subject.name : 'General'}
                      </span>
                      <span aria-hidden="true"> · </span>
                      <span>{task.createdAt}</span>
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onDeleteTask(task.id)}
                  aria-label={`Delete task "${task.title}"`}
                  className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {completedCount > 0 && (
        <div className="mt-3 flex items-center justify-end border-t border-slate-100 pt-3">
          <button
            type="button"
            onClick={onClearCompleted}
            className="text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 rounded"
          >
            Clear completed ({completedCount})
          </button>
        </div>
      )}
    </section>
  );
}
