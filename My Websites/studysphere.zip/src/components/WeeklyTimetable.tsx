import { Check, Pencil, X } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { DAYS_OF_WEEK, TIME_SLOTS } from '../data/initialData';
import { SubjectId, SubjectInfo, TimetableEntry } from '../types';

interface WeeklyTimetableProps {
  entries: TimetableEntry[];
  subjects: SubjectInfo[];
  onToggleEntry: (id: string) => void;
  onUpdateEntry: (id: string, subjectId: SubjectId | 'review', topic: string) => void;
}

export function WeeklyTimetable({
  entries,
  subjects,
  onToggleEntry,
  onUpdateEntry,
}: WeeklyTimetableProps) {
  const [filterSubject, setFilterSubject] = useState<SubjectId | 'all'>('all');
  const [editingEntry, setEditingEntry] = useState<TimetableEntry | null>(null);
  const [editTopic, setEditTopic] = useState('');
  const [editSubject, setEditSubject] = useState<SubjectId | 'review'>('java');

  const subjectMap = Object.fromEntries(subjects.map((s) => [s.id, s]));

  const openEditor = (entry: TimetableEntry) => {
    setEditingEntry(entry);
    setEditTopic(entry.topic);
    setEditSubject(entry.subjectId);
  };

  const handleSaveEdit = (e: FormEvent) => {
    e.preventDefault();
    if (!editingEntry) return;
    const cleaned = editTopic.trim() || 'Study Session';
    onUpdateEntry(editingEntry.id, editSubject, cleaned);
    setEditingEntry(null);
  };

  const completedSlots = entries.filter((e) => e.completed).length;

  return (
    <section
      id="timetable"
      aria-labelledby="timetable-heading"
      className="rounded-xl border border-slate-200 bg-white p-6 scroll-mt-20"
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 id="timetable-heading" className="font-display text-2xl font-bold tracking-tight text-slate-900">
            Weekly Study Timetable
          </h2>
          <p className="mt-1 text-sm text-slate-600 tabular-nums">
            Click any block to mark complete, or edit a topic · {completedSlots}/{entries.length} blocks finished this week
          </p>
        </div>

        {/* Subject Filter Segmented Tabs */}
        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setFilterSubject('all')}
            className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
              filterSubject === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Subjects
          </button>
          {subjects.map((subj) => (
            <button
              key={subj.id}
              type="button"
              onClick={() => setFilterSubject(subj.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                filterSubject === subj.id
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {subj.shortName}
            </button>
          ))}
        </div>
      </div>

      {/* Inline Slot Editor Bar (when editing a slot) */}
      {editingEntry && (
        <form
          onSubmit={handleSaveEdit}
          className="mt-5 flex flex-col gap-3 rounded-lg border border-indigo-200 bg-indigo-50/50 p-4 sm:flex-row sm:items-end"
        >
          <div className="flex-1">
            <label htmlFor="edit-slot-topic" className="block text-xs font-semibold text-slate-700">
              Edit {editingEntry.day} ({editingEntry.timeLabel}) Topic
            </label>
            <input
              id="edit-slot-topic"
              type="text"
              value={editTopic}
              onChange={(e) => setEditTopic(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          <div>
            <label htmlFor="edit-slot-subject" className="block text-xs font-semibold text-slate-700">
              Subject
            </label>
            <select
              id="edit-slot-subject"
              value={editSubject}
              onChange={(e) => setEditSubject(e.target.value as SubjectId | 'review')}
              className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 focus:border-indigo-500 focus:outline-none cursor-pointer"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
              <option value="review">Review / Quiz</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="submit"
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Save
            </button>
            <button
              type="button"
              onClick={() => setEditingEntry(null)}
              aria-label="Cancel editing timetable slot"
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </form>
      )}

      {/* Responsive Timetable Grid */}
      <div className="mt-6 overflow-x-auto pb-1">
        <table className="w-full min-w-[780px] border-collapse text-left">
          <thead>
            <tr className="border-b border-slate-200">
              <th className="w-32 py-3 pr-4 text-xs font-semibold text-slate-500">
                Time Slot
              </th>
              {DAYS_OF_WEEK.map((day) => (
                <th key={day} className="px-1.5 py-3 text-xs font-semibold text-slate-800">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {TIME_SLOTS.map((slot) => (
              <tr key={slot.key}>
                <td className="py-3 pr-4 align-top">
                  <p className="text-sm font-semibold text-slate-800">{slot.label}</p>
                  <p className="mt-0.5 font-mono text-xs tabular-nums text-slate-500">
                    {slot.range}
                  </p>
                </td>

                {DAYS_OF_WEEK.map((day) => {
                  const entry = entries.find((e) => e.day === day && e.slot === slot.key);
                  if (!entry) return <td key={day} className="p-1.5" />;

                  const subject = entry.subjectId === 'review' ? null : subjectMap[entry.subjectId];
                  const isDimmed =
                    filterSubject !== 'all' && entry.subjectId !== filterSubject;

                  return (
                    <td key={entry.id} className="p-1.5 align-top">
                      <div
                        className={`relative rounded-lg border p-2.5 transition-all duration-150 ${
                          entry.completed
                            ? 'border-emerald-200 bg-emerald-50/60'
                            : subject
                            ? `border-slate-200 ${subject.bgTintClass}`
                            : 'border-slate-200 bg-slate-50'
                        } ${isDimmed ? 'opacity-35' : 'opacity-100'}`}
                      >
                        <div className="flex items-start justify-between gap-1">
                          <button
                            type="button"
                            onClick={() => onToggleEntry(entry.id)}
                            className="flex-1 text-left cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 rounded"
                            aria-label={`${day} ${slot.label}: ${
                              subject ? subject.shortName : 'Review'
                            } - ${entry.topic}. ${
                              entry.completed ? 'Completed' : 'Mark complete'
                            }`}
                          >
                            <div className="flex items-center gap-1.5">
                              <span
                                className={`text-xs font-semibold ${
                                  entry.completed
                                    ? 'text-emerald-700'
                                    : subject
                                    ? subject.textAccentClass
                                    : 'text-slate-700'
                                }`}
                              >
                                {subject ? subject.shortName : 'Review'}
                              </span>
                              {entry.completed && (
                                <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                              )}
                            </div>
                            <p
                              className={`mt-1 text-xs leading-snug ${
                                entry.completed
                                  ? 'text-slate-500 line-through'
                                  : 'text-slate-700'
                              }`}
                            >
                              {entry.topic}
                            </p>
                          </button>

                          <button
                            type="button"
                            onClick={() => openEditor(entry)}
                            aria-label={`Edit ${day} ${slot.label} slot`}
                            className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded text-slate-400 hover:bg-white/80 hover:text-slate-700 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
                          >
                            <Pencil className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
