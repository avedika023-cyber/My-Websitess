import { Check, Copy, RefreshCw } from 'lucide-react';
import { useState } from 'react';
import { Quote } from '../types';

interface QuoteCardProps {
  quotes: Quote[];
}

export function QuoteCard({ quotes }: QuoteCardProps) {
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const currentQuote = quotes[quoteIndex];

  const handleNextQuote = () => {
    setQuoteIndex((prev) => (prev + 1) % quotes.length);
    setCopied(false);
  };

  const handleCopyQuote = async () => {
    try {
      await navigator.clipboard.writeText(`"${currentQuote.text}" — ${currentQuote.author}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section
      aria-label="Motivational Quote"
      className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6"
    >
      <div>
        <div className="flex items-center justify-between gap-4">
          <span className="text-xs font-medium text-slate-500">
            Daily Motivation · {currentQuote.category}
          </span>
          <span className="text-xs font-mono tabular-nums text-slate-400">
            {quoteIndex + 1} / {quotes.length}
          </span>
        </div>

        <blockquote className="mt-4 text-lg font-medium leading-relaxed text-slate-900 sm:text-xl">
          “{currentQuote.text}”
        </blockquote>
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100 pt-4">
        <cite className="not-italic text-sm font-semibold text-slate-700">
          — {currentQuote.author}
        </cite>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyQuote}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-600" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5 text-slate-500" />
                <span>Copy</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleNextQuote}
            className="inline-flex items-center gap-1.5 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>New Quote</span>
          </button>
        </div>
      </div>
    </section>
  );
}
