import { Pause, Play, RotateCcw } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { SubjectInfo } from '../types';

interface PomodoroTimerProps {
  activeSubject: SubjectInfo;
  sessionsCompleted: number;
  onSessionComplete: (minutesEarned: number) => void;
  timerSectionRef: React.RefObject<HTMLElement | null>;
}

type TimerMode = 'focus' | 'shortBreak';

const MODE_DURATIONS: Record<TimerMode, number> = {
  focus: 25 * 60,
  shortBreak: 5 * 60,
};

function playGentleChime() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.16); // A5
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.6);
  } catch {
    // Ignore audio errors if blocked by browser autoplay policy
  }
}

export function PomodoroTimer({
  activeSubject,
  sessionsCompleted,
  onSessionComplete,
  timerSectionRef,
}: PomodoroTimerProps) {
  const [mode, setMode] = useState<TimerMode>('focus');
  const [secondsLeft, setSecondsLeft] = useState<number>(MODE_DURATIONS.focus);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const intervalRef = useRef<number | null>(null);

  const totalDuration = MODE_DURATIONS[mode];
  const progressRatio = (totalDuration - secondsLeft) / totalDuration;
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference * (1 - progressRatio);

  useEffect(() => {
    if (!isRunning) {
      if (intervalRef.current !== null) {
        window.clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    intervalRef.current = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setIsRunning(false);
          playGentleChime();
          if (mode === 'focus') {
            onSessionComplete(25);
            setStatusMessage(`Completed 25m ${activeSubject.shortName} focus session.`);
          } else {
            setStatusMessage('Break complete. Ready for the next focus block.');
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (intervalRef.current !== null) {
        window.clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isRunning, mode, activeSubject.shortName, onSessionComplete]);

  const handleModeChange = (nextMode: TimerMode) => {
    setIsRunning(false);
    setMode(nextMode);
    setSecondsLeft(MODE_DURATIONS[nextMode]);
    setStatusMessage('');
  };

  const handleStart = () => {
    if (secondsLeft === 0) {
      setSecondsLeft(MODE_DURATIONS[mode]);
    }
    setStatusMessage('');
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setSecondsLeft(MODE_DURATIONS[mode]);
    setStatusMessage('');
  };

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = secondsLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return (
    <section
      ref={timerSectionRef}
      aria-labelledby="pomodoro-heading"
      className="rounded-xl border border-slate-200 bg-white p-6"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 id="pomodoro-heading" className="font-display text-lg font-bold text-slate-900">
            Pomodoro Timer
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Studying <span className={`font-semibold ${activeSubject.textAccentClass}`}>{activeSubject.name}</span> · {sessionsCompleted} {sessionsCompleted === 1 ? 'session' : 'sessions'} today
          </p>
        </div>

        {/* Mode Segmented Control */}
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => handleModeChange('focus')}
            className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
              mode === 'focus'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            25m Focus
          </button>
          <button
            type="button"
            onClick={() => handleModeChange('shortBreak')}
            className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
              mode === 'shortBreak'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            5m Break
          </button>
        </div>
      </div>

      {/* Circular Countdown Display */}
      <div className="mt-6 flex flex-col items-center justify-center">
        <div className="relative flex h-40 w-40 items-center justify-center">
          <svg className="h-full w-full -rotate-90" viewBox="0 0 152 152" aria-hidden="true">
            <circle
              cx="76"
              cy="76"
              r={radius}
              fill="none"
              className="stroke-slate-100"
              strokeWidth="8"
            />
            <circle
              cx="76"
              cy="76"
              r={radius}
              fill="none"
              stroke={mode === 'focus' ? activeSubject.accentHex : '#059669'}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-300"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span
              className="font-mono text-3xl font-bold tracking-tight text-slate-900 tabular-nums"
              aria-live="off"
            >
              {formattedTime}
            </span>
            <span className="mt-1 text-xs font-medium text-slate-500">
              {isRunning ? 'Running' : secondsLeft === 0 ? 'Finished' : 'Ready'}
            </span>
          </div>
        </div>

        {statusMessage && (
          <p className="mt-3 text-center text-xs font-medium text-emerald-700">
            {statusMessage}
          </p>
        )}

        {/* Start / Pause / Reset Controls */}
        <div className="mt-6 flex w-full items-center justify-center gap-2.5">
          <button
            type="button"
            onClick={handleStart}
            disabled={isRunning}
            className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
          >
            <Play className="h-4 w-4" />
            <span>Start</span>
          </button>

          <button
            type="button"
            onClick={handlePause}
            disabled={!isRunning}
            className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
          >
            <Pause className="h-4 w-4" />
            <span>Pause</span>
          </button>

          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
            aria-label="Reset timer"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Reset</span>
          </button>
        </div>
      </div>
    </section>
  );
}
