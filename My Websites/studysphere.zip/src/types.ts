export type SubjectId = 'java' | 'web' | 'database' | 'ai';

export interface SubjectInfo {
  id: SubjectId;
  name: string;
  shortName: string;
  summary: string;
  modulesCompleted: number;
  totalModules: number;
  minutesStudied: number;
  accentHex: string;
  bgTintClass: string;
  textAccentClass: string;
  barClass: string;
  ringClass: string;
}

export interface StudyTask {
  id: string;
  title: string;
  subjectId: SubjectId | 'general';
  completed: boolean;
  createdAt: string;
}

export type DayOfWeek = 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat' | 'Sun';
export type TimeSlotKey = 'morning' | 'afternoon' | 'evening';

export interface TimetableEntry {
  id: string;
  day: DayOfWeek;
  slot: TimeSlotKey;
  subjectId: SubjectId | 'review';
  topic: string;
  timeLabel: string;
  completed: boolean;
}

export interface Quote {
  text: string;
  author: string;
  category: string;
}
