import { DayOfWeek, Quote, StudyTask, SubjectInfo, TimeSlotKey, TimetableEntry } from '../types';

export const INITIAL_SUBJECTS: SubjectInfo[] = [
  {
    id: 'java',
    name: 'Java',
    shortName: 'Java',
    summary: 'Object-oriented patterns, collections, streams, and concurrency.',
    modulesCompleted: 7,
    totalModules: 10,
    minutesStudied: 260,
    accentHex: '#EA580C',
    bgTintClass: 'bg-orange-50',
    textAccentClass: 'text-orange-700',
    barClass: 'bg-orange-500',
    ringClass: 'focus-visible:ring-orange-500',
  },
  {
    id: 'web',
    name: 'Web Development',
    shortName: 'Web Dev',
    summary: 'Semantic HTML, modern CSS grids, responsive UI, and JavaScript.',
    modulesCompleted: 9,
    totalModules: 12,
    minutesStudied: 340,
    accentHex: '#0284C7',
    bgTintClass: 'bg-sky-50',
    textAccentClass: 'text-sky-700',
    barClass: 'bg-sky-500',
    ringClass: 'focus-visible:ring-sky-500',
  },
  {
    id: 'database',
    name: 'Database',
    shortName: 'Database',
    summary: 'Relational schemas, SQL joins, indexing, and normalization.',
    modulesCompleted: 6,
    totalModules: 10,
    minutesStudied: 195,
    accentHex: '#059669',
    bgTintClass: 'bg-emerald-50',
    textAccentClass: 'text-emerald-700',
    barClass: 'bg-emerald-500',
    ringClass: 'focus-visible:ring-emerald-500',
  },
  {
    id: 'ai',
    name: 'Artificial Intelligence',
    shortName: 'AI',
    summary: 'Search algorithms, neural networks, and supervised learning.',
    modulesCompleted: 5,
    totalModules: 10,
    minutesStudied: 215,
    accentHex: '#7C3AED',
    bgTintClass: 'bg-violet-50',
    textAccentClass: 'text-violet-700',
    barClass: 'bg-violet-500',
    ringClass: 'focus-visible:ring-violet-500',
  },
];

export const INITIAL_TASKS: StudyTask[] = [
  {
    id: 'task-1',
    title: 'Implement binary search tree traversal in Java',
    subjectId: 'java',
    completed: true,
    createdAt: 'Today',
  },
  {
    id: 'task-2',
    title: 'Build responsive CSS Grid layout practice project',
    subjectId: 'web',
    completed: true,
    createdAt: 'Today',
  },
  {
    id: 'task-3',
    title: 'Write SQL inner and outer join queries for lab 4',
    subjectId: 'database',
    completed: false,
    createdAt: 'Today',
  },
  {
    id: 'task-4',
    title: 'Review gradient descent notes and loss functions',
    subjectId: 'ai',
    completed: false,
    createdAt: 'Today',
  },
  {
    id: 'task-5',
    title: 'Summarize Java Collections Framework cheat sheet',
    subjectId: 'java',
    completed: false,
    createdAt: 'Tomorrow',
  },
];

export const DAYS_OF_WEEK: DayOfWeek[] = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const TIME_SLOTS: { key: TimeSlotKey; label: string; range: string }[] = [
  { key: 'morning', label: 'Morning', range: '09:00 – 11:00' },
  { key: 'afternoon', label: 'Afternoon', range: '14:00 – 16:00' },
  { key: 'evening', label: 'Evening', range: '19:00 – 20:30' },
];

export const INITIAL_TIMETABLE: TimetableEntry[] = [
  { id: 'tt-mon-m', day: 'Mon', slot: 'morning', subjectId: 'java', topic: 'OOP & Interfaces', timeLabel: '09:00 – 11:00', completed: true },
  { id: 'tt-tue-m', day: 'Tue', slot: 'morning', subjectId: 'web', topic: 'DOM & Events Lab', timeLabel: '09:00 – 11:00', completed: true },
  { id: 'tt-wed-m', day: 'Wed', slot: 'morning', subjectId: 'database', topic: 'ER Diagrams & 3NF', timeLabel: '09:00 – 11:00', completed: false },
  { id: 'tt-thu-m', day: 'Thu', slot: 'morning', subjectId: 'ai', topic: 'A* Search & Heuristics', timeLabel: '09:00 – 11:00', completed: false },
  { id: 'tt-fri-m', day: 'Fri', slot: 'morning', subjectId: 'java', topic: 'Streams & Lambdas', timeLabel: '09:00 – 11:00', completed: false },
  { id: 'tt-sat-m', day: 'Sat', slot: 'morning', subjectId: 'web', topic: 'Portfolio Build', timeLabel: '09:00 – 11:00', completed: false },
  { id: 'tt-sun-m', day: 'Sun', slot: 'morning', subjectId: 'review', topic: 'Weekly Flashcards', timeLabel: '09:00 – 11:00', completed: false },

  { id: 'tt-mon-a', day: 'Mon', slot: 'afternoon', subjectId: 'database', topic: 'SQL Joins Practice', timeLabel: '14:00 – 16:00', completed: true },
  { id: 'tt-tue-a', day: 'Tue', slot: 'afternoon', subjectId: 'ai', topic: 'Linear Regression', timeLabel: '14:00 – 16:00', completed: false },
  { id: 'tt-wed-a', day: 'Wed', slot: 'afternoon', subjectId: 'web', topic: 'Fetch API & Async JS', timeLabel: '14:00 – 16:00', completed: false },
  { id: 'tt-thu-a', day: 'Thu', slot: 'afternoon', subjectId: 'java', topic: 'Exception Handling', timeLabel: '14:00 – 16:00', completed: false },
  { id: 'tt-fri-a', day: 'Fri', slot: 'afternoon', subjectId: 'database', topic: 'Indexing & Views', timeLabel: '14:00 – 16:00', completed: false },
  { id: 'tt-sat-a', day: 'Sat', slot: 'afternoon', subjectId: 'ai', topic: 'Neural Net Lab', timeLabel: '14:00 – 16:00', completed: false },
  { id: 'tt-sun-a', day: 'Sun', slot: 'afternoon', subjectId: 'review', topic: 'Mock Quiz Session', timeLabel: '14:00 – 16:00', completed: false },

  { id: 'tt-mon-e', day: 'Mon', slot: 'evening', subjectId: 'web', topic: 'CSS Grid Layout', timeLabel: '19:00 – 20:30', completed: false },
  { id: 'tt-tue-e', day: 'Tue', slot: 'evening', subjectId: 'java', topic: 'DSA Problem Solving', timeLabel: '19:00 – 20:30', completed: false },
  { id: 'tt-wed-e', day: 'Wed', slot: 'evening', subjectId: 'ai', topic: 'Python & NumPy Prep', timeLabel: '19:00 – 20:30', completed: false },
  { id: 'tt-thu-e', day: 'Thu', slot: 'evening', subjectId: 'database', topic: 'Transactions & ACID', timeLabel: '19:00 – 20:30', completed: false },
  { id: 'tt-fri-e', day: 'Fri', slot: 'evening', subjectId: 'review', topic: 'Week Recap Notes', timeLabel: '19:00 – 20:30', completed: false },
  { id: 'tt-sat-e', day: 'Sat', slot: 'evening', subjectId: 'review', topic: 'Light Reading', timeLabel: '19:00 – 20:30', completed: false },
  { id: 'tt-sun-e', day: 'Sun', slot: 'evening', subjectId: 'review', topic: 'Plan Next Week', timeLabel: '19:00 – 20:30', completed: false },
];

export const MOTIVATIONAL_QUOTES: Quote[] = [
  {
    text: 'Success is the sum of small efforts, repeated day in and day out.',
    author: 'Robert Collier',
    category: 'Consistency',
  },
  {
    text: 'The secret of getting ahead is getting started. Break complex problems into small, steady wins.',
    author: 'Mark Twain',
    category: 'Momentum',
  },
  {
    text: 'An investment in knowledge always pays the best interest.',
    author: 'Benjamin Franklin',
    category: 'Learning',
  },
  {
    text: 'Focus is a matter of deciding what things you are not going to do.',
    author: 'John Carmack',
    category: 'Deep Work',
  },
  {
    text: 'Live as if you were to die tomorrow. Learn as if you were to live forever.',
    author: 'Mahatma Gandhi',
    category: 'Curiosity',
  },
  {
    text: 'Don’t watch the clock; do what it does. Keep going with steady rhythm.',
    author: 'Sam Levenson',
    category: 'Persistence',
  },
];
