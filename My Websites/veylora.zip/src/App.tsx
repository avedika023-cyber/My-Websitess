import { useEffect, useState } from 'react';
import { PRODUCTS } from './data/products';
import { CartItem, CategoryName, Product } from './types';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import TrendingSection from './components/TrendingSection';
import CatalogSection from './components/CatalogSection';
import ContactSection from './components/ContactSection';
import CartDrawer from './components/CartDrawer';
import Footer from './components/Footer';

const CART_STORAGE_KEY = 'veylora_cart_items';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<CategoryName>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNav, setActiveNav] = useState('Home');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = window.localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
    } catch {
      // Ignore storage errors in restricted environments
    }
  }, [cartItems]);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  const totalCartCount = cartItems.reduce(
    (total, item) => total + item.quantity,
    0
  );

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setToastMessage(`${product.name} added to cart`);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item.product.id === productId
            ? { ...item, quantity: item.quantity + delta }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) =>
      prev.filter((item) => item.product.id !== productId)
    );
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const scrollToSection = (elementId: string) => {
    const el = document.getElementById(elementId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleNavigateHome = () => {
    setActiveNav('Home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCategory = (category: CategoryName) => {
    setSelectedCategory(category);
    if (
      category === 'Women' ||
      category === 'Men' ||
      category === 'New Arrivals'
    ) {
      setActiveNav(category);
    } else {
      setActiveNav('Home');
    }
    scrollToSection('collection');
  };

  const handleNavigateContact = () => {
    setActiveNav('Contact');
    scrollToSection('contact');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFA] text-zinc-900">
      <Header
        cartCount={totalCartCount}
        activeNav={activeNav}
        onNavigateHome={handleNavigateHome}
        onSelectCategory={handleSelectCategory}
        onNavigateContact={handleNavigateContact}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <main className="flex-1">
        <HeroSection
          onShopNow={() => handleSelectCategory('All')}
          onExploreNewArrivals={() => handleSelectCategory('New Arrivals')}
        />

        <TrendingSection
          products={PRODUCTS}
          onAddToCart={handleAddToCart}
          onViewAll={() => handleSelectCategory('All')}
        />

        <CatalogSection
          products={PRODUCTS}
          selectedCategory={selectedCategory}
          searchQuery={searchQuery}
          onSelectCategory={setSelectedCategory}
          onSearchChange={setSearchQuery}
          onAddToCart={handleAddToCart}
        />

        <ContactSection />
      </main>

      <Footer
        onNavigateHome={handleNavigateHome}
        onSelectCategory={handleSelectCategory}
        onNavigateContact={handleNavigateContact}
      />

      <CartDrawer
        isOpen={isCartOpen}
        items={cartItems}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Lightweight Add-to-Cart Toast Feedback */}
      {toastMessage && !isCartOpen && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-40 flex items-center gap-3 bg-zinc-900 text-white px-4 py-3 rounded-lg shadow-lg text-xs font-medium"
        >
          <span>{toastMessage}</span>
          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="text-rose-200 hover:text-white underline underline-offset-2 cursor-pointer"
          >
            View Cart
          </button>
        </div>
      )}
    </div>
  );
}
