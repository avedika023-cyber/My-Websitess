export type CategoryName =
  | 'All'
  | 'Women'
  | 'Men'
  | 'Dresses'
  | 'Tops'
  | 'Jeans'
  | 'Accessories'
  | 'New Arrivals';

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: 'Dresses' | 'Tops' | 'Jeans' | 'Accessories';
  audience: ('Women' | 'Men')[];
  badge?: 'New Arrival' | 'Sale';
  trending?: boolean;
  description: string;
  image: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ContactFormData {
  name: string;
  email: string;
  message: string;
}
