import { Product } from '../types';

export const HERO_IMAGE = '/src/assets/images/hero_veylora_fashion_1795611435761.jpg';

export const PRODUCTS: Product[] = [
  {
    id: 'classic-denim-jacket',
    name: 'Classic Denim Jacket',
    price: 1499,
    originalPrice: 1899,
    category: 'Tops',
    audience: ['Men', 'Women'],
    badge: 'Sale',
    trending: true,
    description: 'Structured indigo denim jacket with timeless contrast stitching and everyday comfort.',
    image: '/src/assets/images/product_denim_jacket_1795611436860.jpg',
  },
  {
    id: 'floral-summer-dress',
    name: 'Floral Summer Dress',
    price: 1299,
    category: 'Dresses',
    audience: ['Women'],
    badge: 'New Arrival',
    trending: true,
    description: 'Lightweight midi dress in soft botanical tones with a flattering tie waist.',
    image: '/src/assets/images/product_floral_dress_1795611488934.jpg',
  },
  {
    id: 'oversized-tshirt',
    name: 'Oversized T-Shirt',
    price: 699,
    originalPrice: 899,
    category: 'Tops',
    audience: ['Men'],
    badge: 'Sale',
    trending: false,
    description: 'Relaxed-fit heavyweight organic cotton tee crafted for effortless daily wear.',
    image: '/src/assets/images/product_oversized_tshirt_1795611436176.jpg',
  },
  {
    id: 'casual-hoodie',
    name: 'Casual Hoodie',
    price: 1099,
    category: 'Tops',
    audience: ['Men', 'Women'],
    badge: 'New Arrival',
    trending: true,
    description: 'Plush brushed-fleece pullover hoodie in warm oatmeal with ribbed cuffs.',
    image: '/src/assets/images/product_casual_hoodie_1795611489259.jpg',
  },
  {
    id: 'straight-fit-jeans',
    name: 'Straight Fit Jeans',
    price: 1399,
    category: 'Jeans',
    audience: ['Men', 'Women'],
    badge: 'New Arrival',
    trending: false,
    description: 'Clean vintage-wash straight-leg denim tailored for all-day versatility.',
    image: '/src/assets/images/product_straight_jeans_1795611486004.jpg',
  },
  {
    id: 'stylish-handbag',
    name: 'Stylish Handbag',
    price: 899,
    originalPrice: 1199,
    category: 'Accessories',
    audience: ['Women'],
    badge: 'Sale',
    trending: true,
    description: 'Structured espresso shoulder bag finished with a minimalist brushed clasp.',
    image: '/src/assets/images/product_stylish_handbag_1795611488475.jpg',
  },
];

export const CATEGORIES = [
  'All',
  'Women',
  'Men',
  'Dresses',
  'Tops',
  'Jeans',
  'Accessories',
] as const;

export function formatINR(amount: number): string {
  return `₹${amount.toLocaleString('en-IN')}`;
}
