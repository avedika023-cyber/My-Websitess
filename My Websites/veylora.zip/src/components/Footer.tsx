import { CategoryName } from '../types';

interface FooterProps {
  onNavigateHome: () => void;
  onSelectCategory: (category: CategoryName) => void;
  onNavigateContact: () => void;
}

export default function Footer({
  onNavigateHome,
  onSelectCategory,
  onNavigateContact,
}: FooterProps) {
  return (
    <footer className="border-t border-zinc-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div>
          <span className="font-serif text-xl font-semibold text-zinc-900">
            Veylora
          </span>
          <p className="mt-1 text-xs text-zinc-500">
            Discover trendy fashion made for your everyday style.
          </p>
        </div>

        <nav
          aria-label="Footer navigation"
          className="flex flex-wrap items-center gap-6 text-xs font-medium text-zinc-600"
        >
          <button
            type="button"
            onClick={onNavigateHome}
            className="hover:text-zinc-900 transition-colors cursor-pointer"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('Women')}
            className="hover:text-zinc-900 transition-colors cursor-pointer"
          >
            Women
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('Men')}
            className="hover:text-zinc-900 transition-colors cursor-pointer"
          >
            Men
          </button>
          <button
            type="button"
            onClick={() => onSelectCategory('New Arrivals')}
            className="hover:text-zinc-900 transition-colors cursor-pointer"
          >
            New Arrivals
          </button>
          <button
            type="button"
            onClick={onNavigateContact}
            className="hover:text-zinc-900 transition-colors cursor-pointer"
          >
            Contact
          </button>
        </nav>

        <p className="text-xs text-zinc-400">
          © {new Date().getFullYear()} Veylora Fashion. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
