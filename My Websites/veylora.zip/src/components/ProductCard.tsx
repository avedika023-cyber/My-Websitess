import { useState } from 'react';
import { Check, ShoppingBag, Shirt } from 'lucide-react';
import { Product } from '../types';
import { formatINR } from '../data/products';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const [added, setAdded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const handleAdd = () => {
    onAddToCart(product);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1200);
  };

  return (
    <article className="group flex flex-col bg-white border border-zinc-200/90 rounded-xl overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      {/* Product Image */}
      <div className="relative aspect-[4/3] w-full bg-[#F4F4F5] overflow-hidden">
        {!imgError ? (
          <img
            src={product.image}
            alt={product.name}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover object-center transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-zinc-100 to-zinc-200 text-zinc-500 p-4 text-center">
            <Shirt className="w-8 h-8 mb-2 text-zinc-400" aria-hidden="true" />
            <span className="text-xs font-medium text-zinc-600">{product.name}</span>
          </div>
        )}

        {/* Maximum 1 subtle tag for New Arrival or Sale */}
        {product.badge && (
          <span
            className={`absolute top-3 left-3 px-2.5 py-1 text-[11px] font-semibold tracking-wide uppercase rounded-sm ${
              product.badge === 'Sale'
                ? 'bg-[#881337] text-white'
                : 'bg-zinc-900 text-white'
            }`}
          >
            {product.badge}
          </span>
        )}
      </div>

      {/* Product Info */}
      <div className="flex flex-col flex-1 p-5">
        <div className="flex items-center gap-2 text-xs text-zinc-500">
          <span>{product.category}</span>
          <span aria-hidden="true">·</span>
          <span>{product.audience.join(' / ')}</span>
        </div>

        <h3 className="mt-1.5 text-base font-semibold text-zinc-900 leading-snug">
          {product.name}
        </h3>

        <p className="mt-1 text-sm text-zinc-500 line-clamp-2 leading-relaxed">
          {product.description}
        </p>

        {/* Price + Add to Cart */}
        <div className="mt-auto pt-4 flex items-center justify-between gap-3 border-t border-zinc-100">
          <div className="flex items-baseline gap-2 tabular-nums">
            <span className="text-base font-semibold text-zinc-900">
              {formatINR(product.price)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-zinc-400 line-through">
                {formatINR(product.originalPrice)}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={handleAdd}
            className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-md transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-1 focus-visible:ring-[#881337] ${
              added
                ? 'bg-emerald-700 text-white'
                : 'bg-zinc-900 text-white hover:bg-[#881337]'
            }`}
          >
            {added ? (
              <>
                <Check className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Added</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
