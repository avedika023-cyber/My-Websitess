import { useState } from 'react';
import { CheckCircle2, Mail, MapPin, Phone, Send } from 'lucide-react';
import { ContactFormData } from '../types';

export default function ContactSection() {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    message: '',
  });
  const [error, setError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !formData.name.trim() ||
      !formData.email.trim() ||
      !formData.message.trim()
    ) {
      setError('Please complete your name, email address, and message.');
      return;
    }

    setError('');
    setSubmitted(true);
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16"
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
        {/* Contact Information */}
        <div className="lg:col-span-5">
          <p className="text-xs font-medium uppercase tracking-wider text-[#881337]">
            Get in Touch
          </p>
          <h2
            id="contact-heading"
            className="mt-1 font-serif text-2xl sm:text-3xl font-semibold text-zinc-900"
          >
            Contact Veylora
          </h2>
          <p className="mt-3 text-sm sm:text-base text-zinc-600 leading-relaxed max-w-md">
            Have questions about sizing, styling, or an existing order? Reach
            out to our team and we will respond within one business day.
          </p>

          <div className="mt-8 space-y-5 text-sm text-zinc-700">
            <div className="flex items-start gap-3">
              <MapPin
                className="w-4 h-4 text-[#881337] mt-1 shrink-0"
                aria-hidden="true"
              />
              <div>
                <p className="font-semibold text-zinc-900">Flagship Studio</p>
                <p className="text-zinc-600">
                  42 Chapel Road, Bandra West, Mumbai 400050
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Mail
                className="w-4 h-4 text-[#881337] mt-1 shrink-0"
                aria-hidden="true"
              />
              <div>
                <p className="font-semibold text-zinc-900">Email</p>
                <p className="text-zinc-600">hello@veylora.store</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Phone
                className="w-4 h-4 text-[#881337] mt-1 shrink-0"
                aria-hidden="true"
              />
              <div>
                <p className="font-semibold text-zinc-900">Phone</p>
                <p className="text-zinc-600 tabular-nums">+91 98765 43210</p>
                <p className="text-xs text-zinc-500 mt-0.5">
                  Monday – Saturday, 10:00 AM – 7:00 PM IST
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white border border-zinc-200/90 rounded-xl p-6 sm:p-8">
          {submitted ? (
            <div className="py-10 text-center">
              <CheckCircle2
                className="w-10 h-10 text-emerald-700 mx-auto"
                aria-hidden="true"
              />
              <h3 className="mt-3 font-serif text-xl font-semibold text-zinc-900">
                Message Sent
              </h3>
              <p className="mt-2 text-sm text-zinc-600 max-w-sm mx-auto">
                Thank you for contacting Veylora. Our styling support team will
                reply to your email shortly.
              </p>
              <button
                type="button"
                onClick={() => setSubmitted(false)}
                className="mt-6 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors cursor-pointer"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label
                    htmlFor="contact-name"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Name
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="Your name"
                    className="w-full px-3.5 py-2.5 text-sm bg-[#FAFAFA] border border-zinc-200 rounded-md text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337] transition-colors"
                  />
                </div>

                <div>
                  <label
                    htmlFor="contact-email"
                    className="block text-xs font-medium text-zinc-700 mb-1.5"
                  >
                    Email
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    placeholder="you@example.com"
                    className="w-full px-3.5 py-2.5 text-sm bg-[#FAFAFA] border border-zinc-200 rounded-md text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="contact-message"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Message
                </label>
                <textarea
                  id="contact-message"
                  rows={4}
                  value={formData.message}
                  onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                  }
                  placeholder="How can we help you?"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#FAFAFA] border border-zinc-200 rounded-md text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:bg-white focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337] transition-colors"
                />
              </div>

              {error && (
                <p role="alert" className="text-xs font-medium text-[#881337]">
                  {error}
                </p>
              )}

              <button
                type="submit"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors duration-200 cursor-pointer"
              >
                <Send className="w-4 h-4" aria-hidden="true" />
                <span>Send Message</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
