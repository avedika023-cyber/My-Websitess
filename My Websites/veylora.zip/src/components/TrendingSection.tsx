import { ArrowRight } from 'lucide-react';
import { Product } from '../types';
import ProductCard from './ProductCard';

interface TrendingSectionProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onViewAll: () => void;
}

export default function TrendingSection({
  products,
  onAddToCart,
  onViewAll,
}: TrendingSectionProps) {
  const trendingProducts = products.filter((p) => p.trending).slice(0, 4);

  return (
    <section
      aria-labelledby="trending-heading"
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16 border-b border-zinc-200/80"
    >
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-[#881337]">
            Featured Picks
          </p>
          <h2
            id="trending-heading"
            className="mt-1 font-serif text-2xl sm:text-3xl font-semibold text-zinc-900"
          >
            Trending Now
          </h2>
        </div>

        <button
          type="button"
          onClick={onViewAll}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-zinc-700 hover:text-[#881337] transition-colors cursor-pointer whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <span>Browse Full Catalog</span>
          <ArrowRight className="w-4 h-4" aria-hidden="true" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {trendingProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={onAddToCart}
          />
        ))}
      </div>
    </section>
  );
}
