import { Search, X } from 'lucide-react';
import { CATEGORIES } from '../data/products';
import { CategoryName, Product } from '../types';
import ProductCard from './ProductCard';

interface CatalogSectionProps {
  products: Product[];
  selectedCategory: CategoryName;
  searchQuery: string;
  onSelectCategory: (category: CategoryName) => void;
  onSearchChange: (query: string) => void;
  onAddToCart: (product: Product) => void;
}

export default function CatalogSection({
  products,
  selectedCategory,
  searchQuery,
  onSelectCategory,
  onSearchChange,
  onAddToCart,
}: CatalogSectionProps) {
  const filterTabs: CategoryName[] = [...CATEGORIES, 'New Arrivals'];

  const filteredProducts = products.filter((product) => {
    const matchesCategory =
      selectedCategory === 'All'
        ? true
        : selectedCategory === 'New Arrivals'
          ? product.badge === 'New Arrival'
          : selectedCategory === 'Women' || selectedCategory === 'Men'
            ? product.audience.includes(selectedCategory)
            : product.category === selectedCategory;

    const query = searchQuery.trim().toLowerCase();
    const matchesSearch =
      query === '' ||
      product.name.toLowerCase().includes(query) ||
      product.category.toLowerCase().includes(query) ||
      product.audience.some((a) => a.toLowerCase().includes(query));

    return matchesCategory && matchesSearch;
  });

  return (
    <section
      id="collection"
      aria-labelledby="collection-heading"
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16 border-b border-zinc-200/80"
    >
      {/* Header + Search Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-[#881337]">
            Shop Collection
          </p>
          <h2
            id="collection-heading"
            className="mt-1 font-serif text-2xl sm:text-3xl font-semibold text-zinc-900"
          >
            All Products
          </h2>
        </div>

        {/* Simple Search Bar */}
        <div className="relative w-full md:w-80">
          <Search
            className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search jackets, dresses, jeans..."
            aria-label="Search products"
            className="w-full pl-10 pr-9 py-2.5 text-sm bg-white border border-zinc-200 rounded-md text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337] transition-colors"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              aria-label="Clear search"
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-zinc-700 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" aria-hidden="true" />
            </button>
          )}
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div
        role="tablist"
        aria-label="Product categories"
        className="flex flex-wrap items-center gap-2 mb-8 pb-4 border-b border-zinc-200/70"
      >
        {filterTabs.map((category) => {
          const isActive = selectedCategory === category;
          return (
            <button
              key={category}
              role="tab"
              aria-selected={isActive}
              type="button"
              onClick={() => onSelectCategory(category)}
              className={`px-4 py-2 text-xs font-medium rounded-md transition-colors duration-200 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#881337] ${
                isActive
                  ? 'bg-zinc-900 text-white'
                  : 'bg-zinc-100 text-zinc-700 hover:bg-zinc-200/80 hover:text-zinc-900'
              }`}
            >
              {category}
            </button>
          );
        })}

        <span className="ml-auto text-xs text-zinc-500 tabular-nums">
          {filteredProducts.length}{' '}
          {filteredProducts.length === 1 ? 'item' : 'items'}
        </span>
      </div>

      {/* Product Grid or Empty State */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white border border-zinc-200 rounded-xl p-12 text-center">
          <p className="font-serif text-xl text-zinc-900">
            No matching pieces found
          </p>
          <p className="mt-2 text-sm text-zinc-500">
            Try clearing your search or switching back to all categories.
          </p>
          <button
            type="button"
            onClick={() => {
              onSelectCategory('All');
              onSearchChange('');
            }}
            className="mt-5 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors cursor-pointer"
          >
            Show All Products
          </button>
        </div>
      )}
    </section>
  );
}
