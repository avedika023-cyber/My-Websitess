import { useState } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { HERO_IMAGE } from '../data/products';

interface HeroSectionProps {
  onShopNow: () => void;
  onExploreNewArrivals: () => void;
}

export default function HeroSection({
  onShopNow,
  onExploreNewArrivals,
}: HeroSectionProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="home"
      className="border-b border-zinc-200/80 bg-[#F4F4F5]/70"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          {/* Editorial Copy Column */}
          <div className="lg:col-span-5 flex flex-col justify-center bg-white border border-zinc-200/90 rounded-xl p-8 sm:p-10 lg:p-12">
            <p className="text-xs font-medium tracking-wider uppercase text-[#881337] mb-4">
              Curated Everyday Wardrobe
            </p>

            <h1 className="font-serif text-4xl sm:text-5xl lg:text-[3.35rem] font-semibold tracking-tight text-zinc-900 leading-[1.1] [text-wrap:balance]">
              Your Style. Your Story.
            </h1>

            <p className="mt-5 text-base sm:text-lg text-zinc-600 leading-relaxed max-w-md">
              Discover trendy fashion made for your everyday style.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onShopNow}
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-all duration-200 hover:-translate-y-0.5 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#881337]"
              >
                <span>Shop Now</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={onExploreNewArrivals}
                className="inline-flex items-center px-5 py-3 text-sm font-medium text-zinc-800 bg-zinc-100 hover:bg-zinc-200/80 rounded-md transition-colors duration-200 cursor-pointer whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#881337]"
              >
                New Arrivals
              </button>
            </div>

            <div className="mt-10 pt-6 border-t border-zinc-100 flex items-center gap-6 text-xs text-zinc-500">
              <span>Free delivery over ₹999</span>
              <span aria-hidden="true">·</span>
              <span>Easy 7-day returns</span>
            </div>
          </div>

          {/* Hero Fashion Visual Column */}
          <div className="lg:col-span-7 relative min-h-[300px] sm:min-h-[400px] lg:min-h-[480px] rounded-xl overflow-hidden bg-zinc-200 border border-zinc-200/90">
            {!imgError ? (
              <img
                src={HERO_IMAGE}
                alt="Models wearing Veylora minimalist tailored casualwear in a sunlit architectural studio"
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="w-full h-full object-cover object-center"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-zinc-100 to-zinc-200 text-zinc-600 p-8 text-center">
                <Sparkles className="w-8 h-8 mb-3 text-[#881337]" aria-hidden="true" />
                <p className="font-serif text-xl text-zinc-800">Veylora Lookbook</p>
                <p className="text-sm text-zinc-500 mt-1">Contemporary Everyday Essentials</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
