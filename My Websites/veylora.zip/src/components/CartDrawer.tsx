import { useState } from 'react';
import {
  CheckCircle2,
  Minus,
  Plus,
  ShoppingBag,
  Trash2,
  X,
} from 'lucide-react';
import { CartItem } from '../types';
import { formatINR } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  items: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  items,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [checkoutStep, setCheckoutStep] = useState<
    'cart' | 'checkout' | 'confirmed'
  >('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [formError, setFormError] = useState('');
  const [orderId, setOrderId] = useState('');
  const [confirmedTotal, setConfirmedTotal] = useState(0);

  if (!isOpen) return null;

  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const shipping = subtotal === 0 || subtotal >= 999 ? 0 : 99;
  const totalAmount = subtotal + shipping;

  const handleClose = () => {
    if (checkoutStep === 'confirmed') {
      setCheckoutStep('cart');
    }
    setFormError('');
    onClose();
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !customerName.trim() ||
      !customerPhone.trim() ||
      !customerAddress.trim()
    ) {
      setFormError('Please fill in your name, phone number, and address.');
      return;
    }

    const generatedId = `VYL-${Math.floor(1000 + Math.random() * 9000)}`;
    setOrderId(generatedId);
    setConfirmedTotal(totalAmount);
    setFormError('');
    setCheckoutStep('confirmed');
    onClearCart();
    setCustomerName('');
    setCustomerPhone('');
    setCustomerAddress('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-title"
    >
      {/* Backdrop */}
      <div
        onClick={handleClose}
        className="fixed inset-0 bg-zinc-950/40 backdrop-blur-[1px] transition-opacity"
      />

      {/* Drawer Panel */}
      <aside className="relative z-10 w-full max-w-md bg-white h-full flex flex-col shadow-2xl border-l border-zinc-200">
        {/* Drawer Header */}
        <div className="px-6 py-5 border-b border-zinc-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-zinc-900" aria-hidden="true" />
            <h2
              id="cart-drawer-title"
              className="font-serif text-xl font-semibold text-zinc-900"
            >
              {checkoutStep === 'cart' && 'Shopping Cart'}
              {checkoutStep === 'checkout' && 'Checkout Details'}
              {checkoutStep === 'confirmed' && 'Order Confirmed'}
            </h2>
          </div>
          <button
            type="button"
            onClick={handleClose}
            aria-label="Close shopping cart"
            className="p-2 text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Drawer Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {checkoutStep === 'confirmed' ? (
            <div className="py-10 text-center">
              <CheckCircle2
                className="w-12 h-12 text-emerald-700 mx-auto"
                aria-hidden="true"
              />
              <h3 className="mt-4 font-serif text-2xl font-semibold text-zinc-900">
                Thank you for your order
              </h3>
              <p className="mt-2 text-sm text-zinc-600">
                Order <span className="font-semibold text-zinc-900">{orderId}</span>{' '}
                for{' '}
                <span className="font-semibold text-zinc-900 tabular-nums">
                  {formatINR(confirmedTotal)}
                </span>{' '}
                has been confirmed and is being prepared for shipment.
              </p>
              <button
                type="button"
                onClick={handleClose}
                className="mt-8 w-full py-3 px-4 text-sm font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          ) : items.length === 0 ? (
            <div className="py-16 text-center">
              <ShoppingBag
                className="w-10 h-10 text-zinc-300 mx-auto"
                aria-hidden="true"
              />
              <p className="mt-4 font-serif text-lg text-zinc-900">
                Your cart is empty
              </p>
              <p className="mt-1.5 text-sm text-zinc-500">
                Explore our collection and add your favorite pieces.
              </p>
              <button
                type="button"
                onClick={handleClose}
                className="mt-6 px-5 py-2.5 text-xs font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors cursor-pointer"
              >
                Browse Products
              </button>
            </div>
          ) : checkoutStep === 'checkout' ? (
            <form
              id="checkout-form"
              onSubmit={handlePlaceOrder}
              className="space-y-4"
            >
              <div className="p-4 bg-[#FAFAFA] border border-zinc-200 rounded-lg text-sm flex items-center justify-between">
                <span className="text-zinc-600">
                  Order Total ({items.reduce((s, i) => s + i.quantity, 0)} items)
                </span>
                <span className="font-semibold text-zinc-900 tabular-nums">
                  {formatINR(totalAmount)}
                </span>
              </div>

              <div>
                <label
                  htmlFor="checkout-name"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Full Name
                </label>
                <input
                  id="checkout-name"
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Aarav Sharma"
                  className="w-full px-3.5 py-2.5 text-sm border border-zinc-200 rounded-md focus:outline-none focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337]"
                />
              </div>

              <div>
                <label
                  htmlFor="checkout-phone"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Phone Number
                </label>
                <input
                  id="checkout-phone"
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-3.5 py-2.5 text-sm border border-zinc-200 rounded-md focus:outline-none focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337]"
                />
              </div>

              <div>
                <label
                  htmlFor="checkout-address"
                  className="block text-xs font-medium text-zinc-700 mb-1.5"
                >
                  Delivery Address
                </label>
                <textarea
                  id="checkout-address"
                  rows={3}
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  placeholder="House / Flat No., Street, City, PIN Code"
                  className="w-full px-3.5 py-2.5 text-sm border border-zinc-200 rounded-md focus:outline-none focus:ring-2 focus:ring-[#881337]/30 focus:border-[#881337]"
                />
              </div>

              <p className="text-xs text-zinc-500">
                Payment method: Cash on Delivery / Pay on Arrival
              </p>

              {formError && (
                <p role="alert" className="text-xs font-medium text-[#881337]">
                  {formError}
                </p>
              )}
            </form>
          ) : (
            <ul className="divide-y divide-zinc-200/80">
              {items.map(({ product, quantity }) => (
                <li key={product.id} className="py-4 flex gap-4">
                  <div className="w-20 h-20 rounded-lg bg-zinc-100 overflow-hidden shrink-0 border border-zinc-200/70">
                    <img
                      src={product.image}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h3 className="text-sm font-semibold text-zinc-900 truncate">
                          {product.name}
                        </h3>
                        <p className="text-xs text-zinc-500 mt-0.5 tabular-nums">
                          {formatINR(product.price)} each
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(product.id)}
                        aria-label={`Remove ${product.name}`}
                        className="p-1.5 text-zinc-400 hover:text-[#881337] transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                      </button>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      {/* Quantity Stepper */}
                      <div className="inline-flex items-center border border-zinc-200 rounded-md">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(product.id, -1)}
                          aria-label={`Decrease quantity of ${product.name}`}
                          className="p-1.5 text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50 transition-colors cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                        <span className="px-3 text-xs font-semibold text-zinc-900 tabular-nums">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(product.id, 1)}
                          aria-label={`Increase quantity of ${product.name}`}
                          className="p-1.5 text-zinc-600 hover:text-zinc-900 hover:bg-zinc-50 transition-colors cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </div>

                      <span className="text-sm font-semibold text-zinc-900 tabular-nums">
                        {formatINR(product.price * quantity)}
                      </span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Drawer Footer */}
        {items.length > 0 && checkoutStep !== 'confirmed' && (
          <div className="px-6 py-5 border-t border-zinc-200 bg-[#FAFAFA] space-y-3">
            <div className="space-y-1.5 text-sm">
              <div className="flex items-center justify-between text-zinc-600">
                <span>Subtotal</span>
                <span className="tabular-nums">{formatINR(subtotal)}</span>
              </div>
              <div className="flex items-center justify-between text-zinc-600">
                <span>Shipping</span>
                <span className="tabular-nums">
                  {shipping === 0 ? 'Free' : formatINR(shipping)}
                </span>
              </div>
              <div className="pt-2 border-t border-zinc-200 flex items-center justify-between text-base font-semibold text-zinc-900">
                <span>Total Amount</span>
                <span className="tabular-nums">{formatINR(totalAmount)}</span>
              </div>
            </div>

            {checkoutStep === 'cart' ? (
              <button
                type="button"
                onClick={() => setCheckoutStep('checkout')}
                className="w-full py-3 px-4 text-sm font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors duration-200 cursor-pointer"
              >
                Checkout
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setCheckoutStep('cart')}
                  className="px-4 py-3 text-sm font-medium text-zinc-700 bg-white border border-zinc-200 hover:bg-zinc-50 rounded-md transition-colors cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  form="checkout-form"
                  className="flex-1 py-3 px-4 text-sm font-semibold text-white bg-zinc-900 hover:bg-[#881337] rounded-md transition-colors cursor-pointer"
                >
                  Confirm Order
                </button>
              </div>
            )}
          </div>
        )}
      </aside>
    </div>
  );
}
