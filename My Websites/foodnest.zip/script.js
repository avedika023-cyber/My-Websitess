// =========================================================
// FoodNest — Interactive E-Commerce Storefront Script
// Clean, beginner-friendly JavaScript using localStorage
// =========================================================

// ---------------------------------------------------------
// 1. SAMPLE DATA: Categories & 12 Food Products
// ---------------------------------------------------------
const CATEGORIES = [
  {
    name: 'Pizza',
    image: './src/assets/images/pizza_margherita_1795608434141.jpg',
  },
  {
    name: 'Burgers',
    image: './src/assets/images/burger_smash_1795608436002.jpg',
  },
  {
    name: 'Snacks',
    image: './src/assets/images/snack_kettle_chips_1795608436488.jpg',
  },
  {
    name: 'Desserts',
    image: './src/assets/images/dessert_tiramisu_1795608436657.jpg',
  },
  {
    name: 'Beverages',
    image: './src/assets/images/beverage_mango_cooler_1795608436787.jpg',
  },
  {
    name: 'Cakes',
    image: './src/assets/images/cake_chocolate_truffle_1795608437212.jpg',
  },
  {
    name: 'Indian Food',
    image: './src/assets/images/indian_butter_chicken_1795608437364.jpg',
  },
  {
    name: 'Healthy Food',
    image: './src/assets/images/healthy_quinoa_bowl_1795608486326.jpg',
  },
  {
    name: 'Frozen Food',
    image: './src/assets/images/frozen_artisan_momos_1795608438598.jpg',
  },
];

const PRODUCTS = [
  {
    id: 1,
    name: 'Margherita Wood-Fired Pizza',
    category: 'Pizza',
    description:
      'Hand-stretched 48-hour fermented sourdough crust topped with San Marzano tomato sauce, fresh buffalo mozzarella, basil leaves, and extra-virgin olive oil.',
    ingredients:
      'Sourdough wheat flour, San Marzano tomatoes, fresh buffalo mozzarella, sweet basil, cold-pressed olive oil, sea salt.',
    originalPrice: 449,
    discountPercent: 20,
    finalPrice: 359,
    rating: 4.9,
    reviewCount: 428,
    image: './src/assets/images/pizza_margherita_1795608434141.jpg',
    isPopular: true,
    isDeal: true,
    isBestSeller: true,
    reviews: [
      { author: 'Meera Nair', rating: 5, text: 'Crust is blistered and airy just like a proper Neapolitan bake.' },
      { author: 'Kabir Sen', rating: 5, text: 'Fresh mozzarella and basil aroma stayed intact on delivery.' },
    ],
  },
  {
    id: 2,
    name: 'Smoky Pepperoni & Hot Honey Pizza',
    category: 'Pizza',
    description:
      'Crisp artisan pizza layered with spicy cupped pepperoni, aged mozzarella, dried oregano, and a warm wildflower chili-honey drizzle.',
    ingredients:
      'Artisan wheat dough, aged mozzarella, smoked pepperoni, wildflower chili honey, oregano, crushed red pepper.',
    originalPrice: 549,
    discountPercent: 18,
    finalPrice: 449,
    rating: 4.8,
    reviewCount: 312,
    image: './src/assets/images/pizza_pepperoni_1795608435019.jpg',
    isPopular: true,
    isDeal: false,
    isBestSeller: true,
    reviews: [
      { author: 'Devansh Rao', rating: 5, text: 'Sweet heat from the hot honey pairs amazingly with crispy pepperoni.' },
    ],
  },
  {
    id: 3,
    name: 'Double Brioche Smash Burger',
    category: 'Burgers',
    description:
      'Two seared lacy-edged patties stacked with melted aged cheddar, caramelized onions, crisp pickles, lettuce, and house smoky sauce in a toasted brioche bun.',
    ingredients:
      'Toasted butter brioche bun, seared patties, aged cheddar cheese, caramelized onions, dill pickles, crisp lettuce, smoky burger sauce.',
    originalPrice: 369,
    discountPercent: 19,
    finalPrice: 299,
    rating: 4.8,
    reviewCount: 389,
    image: './src/assets/images/burger_smash_1795608436002.jpg',
    isPopular: true,
    isDeal: true,
    isBestSeller: true,
    reviews: [
      { author: 'Nikhil Joshi', rating: 5, text: 'Juicy patties, soft brioche, and not soggy at all.' },
    ],
  },
  {
    id: 4,
    name: 'Crispy Paneer Tikka Burger',
    category: 'Burgers',
    description:
      'Golden-crusted spiced cottage cheese fillet topped with cooling mint-yogurt drizzle, pickled red onions, and rocket leaves on a sesame brioche bun.',
    ingredients:
      'Sesame brioche bun, spiced cottage cheese (paneer), hung curd mint chutney, pickled red onions, arugula, Kashmiri chili spice.',
    originalPrice: 299,
    discountPercent: 17,
    finalPrice: 249,
    rating: 4.7,
    reviewCount: 245,
    image: './src/assets/images/burger_paneer_1795608436069.jpg',
    isPopular: true,
    isDeal: false,
    isBestSeller: false,
    reviews: [
      { author: 'Priya Menon', rating: 5, text: 'Thick crispy paneer slab with super refreshing mint dressing.' },
    ],
  },
  {
    id: 5,
    name: 'Herb-Roasted Kettle Chips & Salsa',
    category: 'Snacks',
    description:
      'Small-batch thick-cut potato chips kettle-cooked in sunflower oil, tossed with rosemary and flaky sea salt, paired with roasted tomato salsa.',
    ingredients:
      'Farm potatoes, sunflower oil, dried rosemary, flaky sea salt, fire-roasted tomatoes, cilantro, lime juice.',
    originalPrice: 179,
    discountPercent: 22,
    finalPrice: 139,
    rating: 4.6,
    reviewCount: 184,
    image: './src/assets/images/snack_kettle_chips_1795608436488.jpg',
    isPopular: false,
    isDeal: true,
    isBestSeller: false,
    reviews: [
      { author: 'Siddharth M.', rating: 5, text: 'Extra crunchy and the fresh roasted salsa makes it addictive.' },
    ],
  },
  {
    id: 6,
    name: 'Salted Caramel Espresso Tiramisu',
    category: 'Desserts',
    description:
      'Velvety mascarpone cream layered with espresso-soaked sponge fingers, ribbons of salted caramel, dark cocoa dusting, and an almond biscotti.',
    ingredients:
      'Mascarpone cheese, freshly brewed Arabica espresso, ladyfinger sponge, salted butter caramel, Dutch-process cocoa, almond biscotti.',
    originalPrice: 279,
    discountPercent: 15,
    finalPrice: 237,
    rating: 4.9,
    reviewCount: 296,
    image: './src/assets/images/dessert_tiramisu_1795608436657.jpg',
    isPopular: true,
    isDeal: false,
    isBestSeller: true,
    reviews: [
      { author: 'Rhea Kapoor', rating: 5, text: 'Balanced coffee bitterness with creamy mascarpone and salted caramel.' },
    ],
  },
  {
    id: 7,
    name: 'Cold-Pressed Alphonso Mango Cooler',
    category: 'Beverages',
    description:
      'Chilled Ratnagiri Alphonso mango puree muddled with garden mint leaves, fresh lime juice, and sparkling spring water.',
    ingredients:
      'Alphonso mango pulp, fresh garden mint, key lime juice, raw cane syrup, chilled sparkling water.',
    originalPrice: 169,
    discountPercent: 18,
    finalPrice: 139,
    rating: 4.7,
    reviewCount: 210,
    image: './src/assets/images/beverage_mango_cooler_1795608436787.jpg',
    isPopular: false,
    isDeal: true,
    isBestSeller: false,
    reviews: [
      { author: 'Tanvi Deshmukh', rating: 5, text: 'Tastes like real ripe mangoes and stays refreshingly chilled.' },
    ],
  },
  {
    id: 8,
    name: 'Belgian Dark Chocolate Truffle Cake',
    category: 'Cakes',
    description:
      'Three moist layers of dark cocoa sponge filled and coated in silky 54% Belgian chocolate ganache, finished with hand-shaved chocolate curls.',
    ingredients:
      '54% Belgian dark chocolate, farm cream, organic cane sugar, cocoa powder, free-range butter, unbleached flour.',
    originalPrice: 499,
    discountPercent: 16,
    finalPrice: 419,
    rating: 4.9,
    reviewCount: 514,
    image: './src/assets/images/cake_chocolate_truffle_1795608437212.jpg',
    isPopular: true,
    isDeal: false,
    isBestSeller: true,
    reviews: [
      { author: 'Ananya Verma', rating: 5, text: 'Rich, silky ganache without being overly sweet. Bakery-grade!' },
    ],
  },
  {
    id: 9,
    name: 'Old Delhi Butter Chicken & Garlic Naan',
    category: 'Indian Food',
    description:
      'Char-grilled tandoori chicken simmered in velvety tomato-cashew makhani gravy with kasuri methi, served alongside two buttered garlic naans.',
    ingredients:
      'Tandoori chicken, vine-ripened tomatoes, cashew paste, cultured butter, fresh cream, fenugreek leaves, stone-ground wheat naan, roasted garlic.',
    originalPrice: 459,
    discountPercent: 17,
    finalPrice: 379,
    rating: 4.9,
    reviewCount: 602,
    image: './src/assets/images/indian_butter_chicken_1795608437364.jpg',
    isPopular: true,
    isDeal: false,
    isBestSeller: true,
    reviews: [
      { author: 'Rohan Kulkarni', rating: 5, text: 'Authentic smoky gravy and soft garlicky naans.' },
    ],
  },
  {
    id: 10,
    name: 'Chef’s Grand Family Feast Box',
    category: 'Indian Food',
    description:
      'Complete weekend sharing spread featuring Butter Chicken & Garlic Naan, Wood-Fired Margherita Pizza, Smash Burger with fries, Mango Cooler, and Truffle Cake.',
    ingredients:
      'Butter chicken curry, garlic naan, sourdough margherita pizza, double cheddar smash burger, seasoned fries, mango cooler, dark chocolate cake slice.',
    originalPrice: 1499,
    discountPercent: 25,
    finalPrice: 1124,
    rating: 4.9,
    reviewCount: 175,
    image: './src/assets/images/hero_food_spread_1795608435200.jpg',
    isPopular: false,
    isDeal: true,
    isBestSeller: true,
    reviews: [
      { author: 'Vikramaditya P.', rating: 5, text: 'Ordered for four friends—saved money and everyone got their favorite.' },
    ],
  },
  {
    id: 11,
    name: 'Avocado Quinoa Harvest Bowl',
    category: 'Healthy Food',
    description:
      'Tri-color quinoa, roasted sweet potato cubes, spiced crispy chickpeas, Hass avocado slices, baby spinach, and lemon-tahini dressing.',
    ingredients:
      'Organic quinoa, Hass avocado, roasted sweet potato, crispy chickpeas, baby spinach, cherry tomatoes, toasted pumpkin seeds, lemon-tahini dressing.',
    originalPrice: 349,
    discountPercent: 14,
    finalPrice: 299,
    rating: 4.8,
    reviewCount: 263,
    image: './src/assets/images/healthy_quinoa_bowl_1795608486326.jpg',
    isPopular: true,
    isDeal: false,
    isBestSeller: false,
    reviews: [
      { author: 'Shruti Iyer', rating: 5, text: 'Super fresh greens and filling lunch bowl with bright tahini dressing.' },
    ],
  },
  {
    id: 12,
    name: 'Artisan Cheese & Corn Momos (Pack of 12)',
    category: 'Frozen Food',
    description:
      'Ready-to-steam or pan-sear handcrafted dumplings stuffed with sweet golden corn, melted mozzarella, spring onions, and fiery chili-garlic dip.',
    ingredients:
      'Refined wheat wrapper, sweet golden corn, mozzarella cheese, scallions, ginger, garlic, white pepper, roasted red chili dipping sauce.',
    originalPrice: 289,
    discountPercent: 21,
    finalPrice: 229,
    rating: 4.7,
    reviewCount: 198,
    image: './src/assets/images/frozen_artisan_momos_1795608438598.jpg',
    isPopular: false,
    isDeal: true,
    isBestSeller: false,
    reviews: [
      { author: 'Ishaan Gupta', rating: 5, text: 'Pan-seared them in 6 minutes at home—crispy bottoms and spicy dip!' },
    ],
  },
];

// ---------------------------------------------------------
// 2. APPLICATION STATE & LOCALSTORAGE HELPERS
// ---------------------------------------------------------
const STORAGE_KEYS = {
  CART: 'foodnest_cart',
  WISHLIST: 'foodnest_wishlist',
  ORDERS: 'foodnest_orders',
  USER: 'foodnest_user',
};

function loadFromStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

const DEFAULT_USER = {
  isLoggedIn: true,
  name: 'Aarav Sharma',
  email: 'aarav.sharma@example.com',
  phone: '9876543210',
  location: 'Bengaluru 560001',
  addresses: [
    {
      id: 'addr-1',
      label: 'Home',
      line: 'Flat 402, Oakwood Residency, 12th Main Road',
      city: 'Bengaluru',
      pincode: '560001',
      isDefault: true,
    },
    {
      id: 'addr-2',
      label: 'Work',
      line: 'Level 5, Meridian Tech Park, Outer Ring Road',
      city: 'Bengaluru',
      pincode: '560103',
      isDefault: false,
    },
  ],
};

const DEFAULT_ORDERS = [
  {
    id: 'FN-2026-4108',
    date: 'Nov 22, 2026',
    status: 'Delivered',
    paymentMethod: 'UPI (GPay / PhonePe)',
    address: 'Flat 402, Oakwood Residency, 12th Main Road, Bengaluru - 560001',
    items: [
      { id: 1, name: 'Margherita Wood-Fired Pizza', qty: 1, price: 359 },
      { id: 7, name: 'Cold-Pressed Alphonso Mango Cooler', qty: 2, price: 139 },
    ],
    total: 637,
  },
];

const state = {
  currentView: 'home',
  selectedCategory: 'All',
  searchQuery: '',
  sortBy: 'featured',
  homeTab: 'popular',
  activeDetailId: 1,
  detailQty: 1,
  promoApplied: false,
  cart: loadFromStorage(STORAGE_KEYS.CART, []),
  wishlist: loadFromStorage(STORAGE_KEYS.WISHLIST, [1, 8]),
  orders: loadFromStorage(STORAGE_KEYS.ORDERS, DEFAULT_ORDERS),
  user: loadFromStorage(STORAGE_KEYS.USER, DEFAULT_USER),
  accountTab: 'profile',
  lastConfirmedOrder: null,
};

// ---------------------------------------------------------
// 3. UTILITY FUNCTIONS
// ---------------------------------------------------------
function formatPrice(amount) {
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function getProductById(id) {
  return PRODUCTS.find((p) => p.id === Number(id)) || null;
}

function showToast(message) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = 'toast-item';
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 2600);
}

// Handles broken images gracefully with a styled culinary fallback
function renderProductImageHtml(product, cssClass = 'product-img') {
  return `
    <img
      src="${escapeHtml(product.image)}"
      alt="${escapeHtml(product.name)}"
      class="${cssClass}"
      referrerpolicy="no-referrer"
      onerror="this.outerHTML='<div class=\\'product-img-fallback\\'><svg width=\\'28\\' height=\\'28\\' viewBox=\\'0 0 24 24\\' fill=\\'none\\' stroke=\\'currentColor\\' stroke-width=\\'1.8\\'><path d=\\'M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2\\'/><path d=\\'M7 2v20\\'/><path d=\\'M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7\\'/></svg><span>${escapeHtml(product.name)}</span></div>'"
    />
  `;
}

// ---------------------------------------------------------
// 4. CART & WISHLIST LOGIC
// ---------------------------------------------------------
function getCartCount() {
  return state.cart.reduce((sum, item) => sum + item.qty, 0);
}

function calculateCartTotals() {
  let subtotal = 0;
  let originalTotal = 0;

  state.cart.forEach((cartItem) => {
    const product = getProductById(cartItem.id);
    if (product) {
      subtotal += product.finalPrice * cartItem.qty;
      originalTotal += product.originalPrice * cartItem.qty;
    }
  });

  const productSavings = Math.max(0, originalTotal - subtotal);
  const promoDiscount = state.promoApplied ? Math.round(subtotal * 0.1) : 0;
  const deliveryCharge = subtotal === 0 || subtotal >= 499 ? 0 : 40;
  const finalTotal = Math.max(0, subtotal - promoDiscount + deliveryCharge);

  return {
    subtotal,
    originalTotal,
    productSavings,
    promoDiscount,
    totalDiscountDisplay: productSavings + promoDiscount,
    deliveryCharge,
    finalTotal,
  };
}

function addToCart(productId, qty = 1) {
  const product = getProductById(productId);
  if (!product) return;

  const existing = state.cart.find((item) => item.id === product.id);
  if (existing) {
    existing.qty += qty;
  } else {
    state.cart.push({ id: product.id, qty });
  }

  saveToStorage(STORAGE_KEYS.CART, state.cart);
  updateHeaderBadges();
  showToast(`Added "${product.name}" to cart`);
}

function updateCartQuantity(productId, delta) {
  const item = state.cart.find((entry) => entry.id === Number(productId));
  if (!item) return;

  item.qty += delta;
  if (item.qty <= 0) {
    state.cart = state.cart.filter((entry) => entry.id !== Number(productId));
  }

  saveToStorage(STORAGE_KEYS.CART, state.cart);
  updateHeaderBadges();
  renderCartView();
}

function removeFromCart(productId) {
  state.cart = state.cart.filter((entry) => entry.id !== Number(productId));
  saveToStorage(STORAGE_KEYS.CART, state.cart);
  updateHeaderBadges();
  renderCartView();
  showToast('Item removed from cart');
}

function toggleWishlist(productId) {
  const id = Number(productId);
  const product = getProductById(id);
  if (!product) return;

  const index = state.wishlist.indexOf(id);
  if (index >= 0) {
    state.wishlist.splice(index, 1);
    showToast(`Removed "${product.name}" from wishlist`);
  } else {
    state.wishlist.push(id);
    showToast(`Saved "${product.name}" to wishlist`);
  }

  saveToStorage(STORAGE_KEYS.WISHLIST, state.wishlist);
  refreshVisibleProductCards();
  if (state.currentView === 'product-detail') {
    renderProductDetailView();
  }
  if (state.currentView === 'account') {
    renderAccountWishlist();
  }
}

function updateHeaderBadges() {
  const badge = document.getElementById('cart-count-badge');
  if (badge) {
    badge.textContent = String(getCartCount());
  }

  const locLabel = document.getElementById('current-location-label');
  const mobileLocLabel = document.getElementById('mobile-location-label');
  if (locLabel) locLabel.textContent = state.user.location;
  if (mobileLocLabel) mobileLocLabel.textContent = state.user.location;

  const accountLabel = document.getElementById('header-account-label');
  if (accountLabel) {
    accountLabel.textContent = state.user.isLoggedIn
      ? state.user.name.split(' ')[0]
      : 'Login';
  }
}

// ---------------------------------------------------------
// 5. CARD RENDERING (Reusable Product Card Builder)
// ---------------------------------------------------------
function buildProductCardHtml(product) {
  const isWishlisted = state.wishlist.includes(product.id);
  const fullStars = '★'.repeat(Math.round(product.rating));

  return `
    <article class="product-card" data-product-id="${product.id}">
      <div class="product-media-wrap" data-open-detail="${product.id}">
        ${renderProductImageHtml(product, 'product-img')}
        <button
          type="button"
          class="wishlist-card-btn ${isWishlisted ? 'is-active' : ''}"
          data-wishlist-toggle="${product.id}"
          aria-label="${isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}"
          title="Save to wishlist"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
          </svg>
        </button>
      </div>

      <div class="product-card-body">
        <div class="product-meta-line">
          <span class="product-category-text">${escapeHtml(product.category)}</span>
          <span aria-hidden="true">&middot;</span>
          <span>Freshly Prepared</span>
        </div>

        <button type="button" class="product-title-btn" data-open-detail="${product.id}">
          ${escapeHtml(product.name)}
        </button>

        <p class="product-desc">${escapeHtml(product.description)}</p>

        <div class="product-rating-row">
          <span class="stars-text" aria-hidden="true">${fullStars}</span>
          <span class="rating-score tabular-nums">${product.rating.toFixed(1)}</span>
          <span aria-hidden="true">&middot;</span>
          <span class="tabular-nums">${product.reviewCount} reviews</span>
        </div>

        <div class="product-footer-row">
          <div class="price-block">
            <div class="price-main-line">
              <span class="price-final tabular-nums">${formatPrice(product.finalPrice)}</span>
              <span class="price-original tabular-nums">${formatPrice(product.originalPrice)}</span>
            </div>
            <span class="price-discount-label tabular-nums">${product.discountPercent}% off</span>
          </div>

          <button type="button" class="add-cart-card-btn" data-add-cart="${product.id}">
            Add to Cart
          </button>
        </div>
      </div>
    </article>
  `;
}

function refreshVisibleProductCards() {
  renderHomeDeals();
  renderHomeProducts();
  if (state.currentView === 'products') {
    renderCatalogView();
  }
}

// ---------------------------------------------------------
// 6. VIEW NAVIGATION & ROUTING
// ---------------------------------------------------------
function navigateTo(viewName, options = {}) {
  state.currentView = viewName;

  // Hide all page views
  const allViews = document.querySelectorAll('.page-view');
  allViews.forEach((section) => section.classList.add('hidden'));

  // Update active sub-nav link
  document.querySelectorAll('.sub-nav-link').forEach((btn) => {
    const target = btn.getAttribute('data-nav');
    const isActive =
      target === viewName ||
      (viewName === 'products' && target === 'deals' && options.dealsOnly) ||
      (viewName === 'products' && target === 'bestsellers' && options.bestSellersOnly);
    btn.classList.toggle('is-active', Boolean(isActive));
  });

  // Show requested view
  if (viewName === 'home') {
    document.getElementById('view-home')?.classList.remove('hidden');
    if (options.scrollToCategories) {
      setTimeout(() => {
        document.getElementById('categories-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 40);
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  } else if (viewName === 'products') {
    if (options.category) state.selectedCategory = options.category;
    document.getElementById('view-products')?.classList.remove('hidden');
    renderCatalogView(options);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (viewName === 'product-detail') {
    if (options.productId) {
      state.activeDetailId = Number(options.productId);
      state.detailQty = 1;
    }
    document.getElementById('view-product-detail')?.classList.remove('hidden');
    renderProductDetailView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (viewName === 'cart') {
    document.getElementById('view-cart')?.classList.remove('hidden');
    renderCartView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (viewName === 'checkout') {
    if (state.cart.length === 0) {
      showToast('Add at least one item before checking out.');
      navigateTo('cart');
      return;
    }
    document.getElementById('view-checkout')?.classList.remove('hidden');
    renderCheckoutView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (viewName === 'order-confirmation') {
    document.getElementById('view-order-confirmation')?.classList.remove('hidden');
    renderOrderConfirmationView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } else if (viewName === 'account') {
    if (options.tab) state.accountTab = options.tab;
    document.getElementById('view-account')?.classList.remove('hidden');
    renderAccountView();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  closeMobileDrawer();
}

// ---------------------------------------------------------
// 7. HOME VIEW RENDERERS
// ---------------------------------------------------------
function renderCategories() {
  const grid = document.getElementById('categories-grid');
  if (!grid) return;

  grid.innerHTML = CATEGORIES.map((cat) => {
    const count = PRODUCTS.filter((p) => p.category === cat.name).length;
    return `
      <button type="button" class="category-card" data-category-card="${escapeHtml(cat.name)}">
        <div class="category-thumb">
          <img src="${escapeHtml(cat.image)}" alt="${escapeHtml(cat.name)}" referrerpolicy="no-referrer" />
        </div>
        <span class="category-name">${escapeHtml(cat.name)}</span>
        <span class="category-count tabular-nums">${count} ${count === 1 ? 'item' : 'items'}</span>
      </button>
    `;
  }).join('');
}

function renderHomeDeals() {
  const grid = document.getElementById('deals-grid');
  if (!grid) return;

  const dealProducts = PRODUCTS.filter((p) => p.isDeal).slice(0, 4);
  grid.innerHTML = dealProducts.map(buildProductCardHtml).join('');
}

function renderHomeProducts() {
  const grid = document.getElementById('home-products-grid');
  if (!grid) return;

  let list = PRODUCTS;
  if (state.homeTab === 'popular') {
    list = PRODUCTS.filter((p) => p.isPopular);
  } else if (state.homeTab === 'bestsellers') {
    list = PRODUCTS.filter((p) => p.isBestSeller);
  }

  grid.innerHTML = list.slice(0, 8).map(buildProductCardHtml).join('');
}

// ---------------------------------------------------------
// 8. CATALOG / SEARCH / FILTER VIEW RENDERER
// ---------------------------------------------------------
function renderCatalogView(options = {}) {
  const filterBar = document.getElementById('category-filter-tabs');
  const grid = document.getElementById('catalog-products-grid');
  const emptyState = document.getElementById('empty-search-state');
  const titleEl = document.getElementById('products-view-title');
  const subtitleEl = document.getElementById('products-view-subtitle');
  if (!filterBar || !grid || !emptyState || !titleEl || !subtitleEl) return;

  // Render category filter buttons
  const categoryNames = ['All', ...CATEGORIES.map((c) => c.name)];
  filterBar.innerHTML = categoryNames
    .map(
      (cat) => `
      <button
        type="button"
        class="filter-btn ${state.selectedCategory === cat ? 'is-active' : ''}"
        data-filter-category="${escapeHtml(cat)}"
      >
        ${escapeHtml(cat)}
      </button>
    `
    )
    .join('');

  // Filter products
  let filtered = [...PRODUCTS];

  if (options.dealsOnly) {
    filtered = filtered.filter((p) => p.isDeal);
    titleEl.textContent = "Today's Deals";
    subtitleEl.textContent = 'Save up to 25% on our daily featured meals and combos.';
  } else if (options.bestSellersOnly) {
    filtered = filtered.filter((p) => p.isBestSeller);
    titleEl.textContent = 'Best Sellers';
    subtitleEl.textContent = 'Customer-favorite dishes ordered again and again.';
  } else if (state.searchQuery.trim() !== '') {
    titleEl.textContent = `Search Results for "${state.searchQuery.trim()}"`;
    subtitleEl.textContent = 'Matching dishes from our fresh kitchen catalog.';
  } else if (state.selectedCategory !== 'All') {
    titleEl.textContent = state.selectedCategory;
    subtitleEl.textContent = `Fresh ${state.selectedCategory.toLowerCase()} selections ready for delivery.`;
  } else {
    titleEl.textContent = 'All Food Products';
    subtitleEl.textContent = 'Browse all 12 freshly prepared meals, snacks, cakes, and drinks.';
  }

  if (state.selectedCategory !== 'All') {
    filtered = filtered.filter((p) => p.category === state.selectedCategory);
  }

  const query = state.searchQuery.trim().toLowerCase();
  if (query) {
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.ingredients.toLowerCase().includes(query)
    );
  }

  // Sort products
  if (state.sortBy === 'price-asc') {
    filtered.sort((a, b) => a.finalPrice - b.finalPrice);
  } else if (state.sortBy === 'price-desc') {
    filtered.sort((a, b) => b.finalPrice - a.finalPrice);
  } else if (state.sortBy === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  } else if (state.sortBy === 'discount') {
    filtered.sort((a, b) => b.discountPercent - a.discountPercent);
  }

  if (filtered.length === 0) {
    grid.innerHTML = '';
    emptyState.classList.remove('hidden');
    const msgEl = document.getElementById('empty-search-message');
    if (msgEl) {
      msgEl.textContent = query
        ? `We couldn't find any food products matching "${state.searchQuery.trim()}". Try searching for pizza, burger, cake, or biryani.`
        : 'No products found in this category filter.';
    }
  } else {
    emptyState.classList.add('hidden');
    grid.innerHTML = filtered.map(buildProductCardHtml).join('');
  }
}

// ---------------------------------------------------------
// 9. PRODUCT DETAILS VIEW RENDERER
// ---------------------------------------------------------
function renderProductDetailView() {
  const product = getProductById(state.activeDetailId) || PRODUCTS[0];
  if (!product) return;

  const isWishlisted = state.wishlist.includes(product.id);

  document.getElementById('detail-breadcrumb-cat').textContent = product.category;
  document.getElementById('detail-breadcrumb-cat').onclick = () => {
    state.searchQuery = '';
    navigateTo('products', { category: product.category });
  };
  document.getElementById('detail-breadcrumb-name').textContent = product.name;

  document.getElementById('detail-image-wrap').innerHTML = renderProductImageHtml(product);
  document.getElementById('detail-category-kicker').textContent = product.category;
  document.getElementById('detail-title').textContent = product.name;
  document.getElementById('detail-stars').textContent = '★'.repeat(Math.round(product.rating));
  document.getElementById('detail-rating-num').textContent = product.rating.toFixed(1);
  document.getElementById('detail-reviews-count').textContent = `${product.reviewCount} reviews`;

  document.getElementById('detail-final-price').textContent = formatPrice(product.finalPrice);
  document.getElementById('detail-original-price').textContent = formatPrice(product.originalPrice);
  document.getElementById('detail-discount-text').textContent = `Save ${product.discountPercent}%`;
  document.getElementById('detail-description').textContent = product.description;
  document.getElementById('detail-ingredients').textContent = product.ingredients;
  document.getElementById('detail-qty-value').textContent = String(state.detailQty);

  const wishBtn = document.getElementById('detail-wishlist-btn');
  wishBtn.classList.toggle('is-active', isWishlisted);

  // Render reviews
  const reviewsEl = document.getElementById('detail-reviews-list');
  reviewsEl.innerHTML = product.reviews
    .map(
      (rev) => `
      <article class="review-card">
        <div class="review-stars">${'★'.repeat(rev.rating)}</div>
        <p class="review-quote">"${escapeHtml(rev.text)}"</p>
        <div class="review-author">
          <strong class="author-name">${escapeHtml(rev.author)}</strong>
          <span class="author-meta">Verified FoodNest Buyer</span>
        </div>
      </article>
    `
    )
    .join('');

  // Related products
  const related = PRODUCTS.filter((p) => p.id !== product.id)
    .sort((a, b) => (a.category === product.category ? -1 : b.category === product.category ? 1 : 0))
    .slice(0, 4);
  document.getElementById('related-products-grid').innerHTML = related
    .map(buildProductCardHtml)
    .join('');
}

// ---------------------------------------------------------
// 10. SHOPPING CART VIEW RENDERER
// ---------------------------------------------------------
function renderCartView() {
  const emptyState = document.getElementById('empty-cart-state');
  const activeLayout = document.getElementById('cart-active-layout');
  const itemsContainer = document.getElementById('cart-items-container');
  if (!emptyState || !activeLayout || !itemsContainer) return;

  if (state.cart.length === 0) {
    emptyState.classList.remove('hidden');
    activeLayout.classList.add('hidden');
    return;
  }

  emptyState.classList.add('hidden');
  activeLayout.classList.remove('hidden');

  itemsContainer.innerHTML = state.cart
    .map((entry) => {
      const product = getProductById(entry.id);
      if (!product) return '';
      const lineTotal = product.finalPrice * entry.qty;
      return `
        <article class="cart-item-card">
          <div class="cart-item-thumb">
            ${renderProductImageHtml(product)}
          </div>
          <div>
            <h3 class="cart-item-title">${escapeHtml(product.name)}</h3>
            <p class="cart-item-meta">${escapeHtml(product.category)} &middot; ${formatPrice(product.finalPrice)} each</p>
            <div class="cart-item-controls">
              <div class="qty-stepper cart-qty-stepper">
                <button type="button" class="qty-btn" data-cart-dec="${product.id}" aria-label="Decrease quantity">&minus;</button>
                <span class="qty-val tabular-nums">${entry.qty}</span>
                <button type="button" class="qty-btn" data-cart-inc="${product.id}" aria-label="Increase quantity">+</button>
              </div>
              <button type="button" class="remove-item-btn" data-cart-remove="${product.id}">Remove</button>
            </div>
          </div>
          <div class="cart-item-price-col">
            <strong class="price-final tabular-nums">${formatPrice(lineTotal)}</strong>
          </div>
        </article>
      `;
    })
    .join('');

  const totals = calculateCartTotals();
  document.getElementById('cart-subtotal').textContent = formatPrice(totals.originalTotal);
  document.getElementById('cart-delivery').textContent =
    totals.deliveryCharge === 0 ? 'FREE' : formatPrice(totals.deliveryCharge);
  document.getElementById('cart-discount').textContent = `-${formatPrice(totals.totalDiscountDisplay)}`;
  document.getElementById('cart-final-total').textContent = formatPrice(totals.finalTotal);

  const hintEl = document.getElementById('free-delivery-hint');
  if (totals.subtotal >= 499) {
    hintEl.textContent = 'You unlocked FREE doorstep delivery on this order.';
  } else {
    const remaining = 499 - totals.subtotal;
    hintEl.textContent = `Add ${formatPrice(remaining)} more to unlock free delivery.`;
  }
}

// ---------------------------------------------------------
// 11. CHECKOUT & ORDER CONFIRMATION RENDERERS
// ---------------------------------------------------------
function renderCheckoutView() {
  const defaultAddr =
    state.user.addresses.find((a) => a.isDefault) || state.user.addresses[0] || null;

  if (state.user.isLoggedIn) {
    document.getElementById('checkout-name').value = state.user.name || '';
    document.getElementById('checkout-phone').value = state.user.phone || '';
    document.getElementById('checkout-email').value = state.user.email || '';
    if (defaultAddr) {
      document.getElementById('checkout-address').value = defaultAddr.line;
      document.getElementById('checkout-city').value = defaultAddr.city;
      document.getElementById('checkout-pincode').value = defaultAddr.pincode;
    }
  }

  document.getElementById('checkout-error').classList.add('hidden');

  const previewEl = document.getElementById('checkout-summary-items');
  previewEl.innerHTML = state.cart
    .map((entry) => {
      const product = getProductById(entry.id);
      if (!product) return '';
      return `
        <div class="checkout-preview-row">
          <span>${entry.qty}&times; ${escapeHtml(product.name)}</span>
          <strong class="tabular-nums">${formatPrice(product.finalPrice * entry.qty)}</strong>
        </div>
      `;
    })
    .join('');

  const totals = calculateCartTotals();
  document.getElementById('checkout-subtotal').textContent = formatPrice(totals.originalTotal);
  document.getElementById('checkout-delivery').textContent =
    totals.deliveryCharge === 0 ? 'FREE' : formatPrice(totals.deliveryCharge);
  document.getElementById('checkout-discount').textContent = `-${formatPrice(totals.totalDiscountDisplay)}`;
  document.getElementById('checkout-total').textContent = formatPrice(totals.finalTotal);
}

function renderOrderConfirmationView() {
  const order = state.lastConfirmedOrder;
  if (!order) return;

  document.getElementById('confirm-order-id').textContent = order.id;
  document.getElementById('confirm-delivery-summary').innerHTML = `
    <p><strong>Delivering to:</strong> ${escapeHtml(order.customerName)} (${escapeHtml(order.phone)})</p>
    <p><strong>Address:</strong> ${escapeHtml(order.address)}</p>
    <p><strong>Payment Method:</strong> ${escapeHtml(order.paymentMethod)}</p>
    <p><strong>Estimated Arrival:</strong> 25 – 35 minutes</p>
  `;

  document.getElementById('confirm-order-items').innerHTML = `
    ${order.items
      .map(
        (item) => `
      <div class="checkout-preview-row" style="margin-bottom:6px;">
        <span>${item.qty}&times; ${escapeHtml(item.name)}</span>
        <strong class="tabular-nums">${formatPrice(item.price * item.qty)}</strong>
      </div>
    `
      )
      .join('')}
    <div class="summary-divider"></div>
    <div class="checkout-preview-row" style="margin-top:8px;">
      <strong>Total Paid</strong>
      <strong class="tabular-nums">${formatPrice(order.total)}</strong>
    </div>
  `;
}

// ---------------------------------------------------------
// 12. USER ACCOUNT & ORDERS VIEW RENDERERS
// ---------------------------------------------------------
function renderAccountView() {
  const loginPanel = document.getElementById('account-login-panel');
  const dashboardPanel = document.getElementById('account-dashboard-panel');

  if (!state.user.isLoggedIn) {
    loginPanel.classList.remove('hidden');
    dashboardPanel.classList.add('hidden');
    return;
  }

  loginPanel.classList.add('hidden');
  dashboardPanel.classList.remove('hidden');

  const initials = state.user.name
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  document.getElementById('account-avatar').textContent = initials || 'FN';
  document.getElementById('account-sidebar-name').textContent = state.user.name;
  document.getElementById('account-sidebar-email').textContent = state.user.email;

  // Activate selected tab
  document.querySelectorAll('.account-tab-btn').forEach((btn) => {
    btn.classList.toggle('is-active', btn.getAttribute('data-account-tab') === state.accountTab);
  });
  document.querySelectorAll('.account-tab-panel').forEach((panel) => {
    panel.classList.add('hidden');
  });
  document.getElementById(`tab-${state.accountTab}`)?.classList.remove('hidden');

  // Populate profile form
  document.getElementById('profile-name').value = state.user.name;
  document.getElementById('profile-email').value = state.user.email;
  document.getElementById('profile-phone').value = state.user.phone;

  renderAccountOrders();
  renderAccountAddresses();
  renderAccountWishlist();
}

function renderAccountOrders() {
  const container = document.getElementById('orders-list-container');
  if (!container) return;

  if (state.orders.length === 0) {
    container.innerHTML = '<p class="section-subtitle">No orders placed yet.</p>';
    return;
  }

  container.innerHTML = state.orders
    .map(
      (order) => `
      <article class="order-card">
        <div class="order-card-head">
          <div>
            <strong class="tabular-nums">Order #${escapeHtml(order.id)}</strong>
            <div style="font-size:13px; color:var(--text-muted);">${escapeHtml(order.date)} &middot; ${escapeHtml(order.paymentMethod)}</div>
          </div>
          <div style="text-align:right;">
            <div class="order-status-text">${escapeHtml(order.status)}</div>
            <strong class="tabular-nums">${formatPrice(order.total)}</strong>
          </div>
        </div>
        <div style="font-size:13.5px; color:var(--text-secondary); margin-bottom:8px;">
          ${order.items.map((i) => `${i.qty}&times; ${escapeHtml(i.name)}`).join(', ')}
        </div>
        <div style="font-size:12.5px; color:var(--text-muted);">
          Delivered to: ${escapeHtml(order.address)}
        </div>
      </article>
    `
    )
    .join('');
}

function renderAccountAddresses() {
  const container = document.getElementById('addresses-list-container');
  if (!container) return;

  container.innerHTML = state.user.addresses
    .map(
      (addr) => `
      <article class="address-card ${addr.isDefault ? 'is-default' : ''}">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
          <strong>${escapeHtml(addr.label)}</strong>
          ${
            addr.isDefault
              ? '<span style="font-size:12px; font-weight:700; color:var(--accent-orange);">Default</span>'
              : `<button type="button" class="text-link-btn" data-set-default-addr="${escapeHtml(addr.id)}">Set Default</button>`
          }
        </div>
        <p style="margin:0; font-size:13.5px; color:var(--text-secondary);">
          ${escapeHtml(addr.line)}, ${escapeHtml(addr.city)} - ${escapeHtml(addr.pincode)}
        </p>
      </article>
    `
    )
    .join('');
}

function renderAccountWishlist() {
  const grid = document.getElementById('wishlist-grid');
  const empty = document.getElementById('empty-wishlist-state');
  if (!grid || !empty) return;

  const items = state.wishlist.map(getProductById).filter(Boolean);
  if (items.length === 0) {
    grid.innerHTML = '';
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    grid.innerHTML = items.map(buildProductCardHtml).join('');
  }
}

// ---------------------------------------------------------
// 13. DRAWER & MODAL HELPERS
// ---------------------------------------------------------
function openMobileDrawer() {
  document.getElementById('drawer-backdrop')?.classList.remove('hidden');
  document.getElementById('mobile-drawer')?.classList.remove('hidden');
  document.getElementById('mobile-menu-btn')?.setAttribute('aria-expanded', 'true');
}

function closeMobileDrawer() {
  document.getElementById('drawer-backdrop')?.classList.add('hidden');
  document.getElementById('mobile-drawer')?.classList.add('hidden');
  document.getElementById('mobile-menu-btn')?.setAttribute('aria-expanded', 'false');
}

function openLocationModal() {
  document.getElementById('location-modal')?.classList.remove('hidden');
}

function closeLocationModal() {
  document.getElementById('location-modal')?.classList.add('hidden');
}

// ---------------------------------------------------------
// 14. EVENT LISTENERS & INITIALIZATION
// ---------------------------------------------------------
function bindEvents() {
  // Global delegated click handlers for dynamic buttons & cards
  document.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;

    // 1) Wishlist toggle button
    const wishlistBtn = target.closest('[data-wishlist-toggle]');
    if (wishlistBtn) {
      event.stopPropagation();
      toggleWishlist(wishlistBtn.getAttribute('data-wishlist-toggle'));
      return;
    }

    // 2) Add to Cart button on cards
    const addCartBtn = target.closest('[data-add-cart]');
    if (addCartBtn) {
      event.stopPropagation();
      addToCart(addCartBtn.getAttribute('data-add-cart'), 1);
      return;
    }

    // 3) Open Product Detail view
    const detailTrigger = target.closest('[data-open-detail]');
    if (detailTrigger) {
      navigateTo('product-detail', {
        productId: detailTrigger.getAttribute('data-open-detail'),
      });
      return;
    }

    // 4) Home Category Card click
    const catCard = target.closest('[data-category-card]');
    if (catCard) {
      state.searchQuery = '';
      document.getElementById('search-input').value = '';
      navigateTo('products', { category: catCard.getAttribute('data-category-card') });
      return;
    }

    // 5) Catalog Filter Button click
    const filterBtn = target.closest('[data-filter-category]');
    if (filterBtn) {
      state.selectedCategory = filterBtn.getAttribute('data-filter-category') || 'All';
      renderCatalogView();
      return;
    }

    // 6) Navigation triggers
    const navTrigger = target.closest('[data-nav]');
    if (navTrigger) {
      const dest = navTrigger.getAttribute('data-nav');
      if (dest === 'home') {
        navigateTo('home');
      } else if (dest === 'categories') {
        navigateTo('home', { scrollToCategories: true });
      } else if (dest === 'products') {
        state.selectedCategory = 'All';
        navigateTo('products');
      } else if (dest === 'deals') {
        state.selectedCategory = 'All';
        navigateTo('products', { dealsOnly: true });
      } else if (dest === 'bestsellers') {
        state.selectedCategory = 'All';
        navigateTo('products', { bestSellersOnly: true });
      } else if (dest === 'cart') {
        navigateTo('cart');
      } else if (dest === 'account') {
        navigateTo('account', { tab: 'profile' });
      } else if (dest === 'orders') {
        navigateTo('account', { tab: 'orders' });
      } else if (dest === 'wishlist') {
        navigateTo('account', { tab: 'wishlist' });
      }
      return;
    }

    // 7) Cart quantity & removal buttons
    const incBtn = target.closest('[data-cart-inc]');
    if (incBtn) {
      updateCartQuantity(incBtn.getAttribute('data-cart-inc'), 1);
      return;
    }
    const decBtn = target.closest('[data-cart-dec]');
    if (decBtn) {
      updateCartQuantity(decBtn.getAttribute('data-cart-dec'), -1);
      return;
    }
    const removeBtn = target.closest('[data-cart-remove]');
    if (removeBtn) {
      removeFromCart(removeBtn.getAttribute('data-cart-remove'));
      return;
    }

    // 8) Account Tabs
    const accTabBtn = target.closest('[data-account-tab]');
    if (accTabBtn) {
      state.accountTab = accTabBtn.getAttribute('data-account-tab') || 'profile';
      renderAccountView();
      return;
    }

    // 9) Set default address
    const defAddrBtn = target.closest('[data-set-default-addr]');
    if (defAddrBtn) {
      const id = defAddrBtn.getAttribute('data-set-default-addr');
      state.user.addresses.forEach((a) => {
        a.isDefault = a.id === id;
      });
      saveToStorage(STORAGE_KEYS.USER, state.user);
      renderAccountAddresses();
      showToast('Default delivery address updated');
      return;
    }

    // 10) Home Popular/Best Sellers tabs
    const homeTabBtn = target.closest('[data-home-tab]');
    if (homeTabBtn) {
      state.homeTab = homeTabBtn.getAttribute('data-home-tab') || 'popular';
      document.querySelectorAll('[data-home-tab]').forEach((b) => {
        const active = b === homeTabBtn;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-selected', String(active));
      });
      renderHomeProducts();
    }
  });

  // Header Logo & Action Buttons
  document.getElementById('nav-home-logo')?.addEventListener('click', (e) => {
    e.preventDefault();
    navigateTo('home');
  });
  document.getElementById('nav-account-btn')?.addEventListener('click', () => {
    navigateTo('account', { tab: 'profile' });
  });
  document.getElementById('nav-orders-btn')?.addEventListener('click', () => {
    navigateTo('account', { tab: 'orders' });
  });
  document.getElementById('nav-cart-btn')?.addEventListener('click', () => {
    navigateTo('cart');
  });

  // Hero CTA Buttons
  document.getElementById('hero-shop-btn')?.addEventListener('click', () => {
    state.selectedCategory = 'All';
    state.searchQuery = '';
    navigateTo('products');
  });
  document.getElementById('hero-deals-btn')?.addEventListener('click', () => {
    navigateTo('products', { dealsOnly: true });
  });

  // Search Bar Form & Live Input
  const searchForm = document.getElementById('search-form');
  const searchInput = document.getElementById('search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');

  searchInput?.addEventListener('input', () => {
    const val = searchInput.value;
    searchClearBtn?.classList.toggle('hidden', val.length === 0);
    state.searchQuery = val;
    if (state.currentView === 'products') {
      renderCatalogView();
    }
  });

  searchClearBtn?.addEventListener('click', () => {
    searchInput.value = '';
    state.searchQuery = '';
    searchClearBtn.classList.add('hidden');
    if (state.currentView === 'products') {
      renderCatalogView();
    }
  });

  searchForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    state.searchQuery = searchInput.value;
    state.selectedCategory = 'All';
    navigateTo('products');
  });

  // Catalog Sort & Reset Filters
  document.getElementById('sort-select')?.addEventListener('change', (e) => {
    state.sortBy = e.target.value;
    renderCatalogView();
  });

  document.getElementById('reset-filters-btn')?.addEventListener('click', () => {
    state.selectedCategory = 'All';
    state.searchQuery = '';
    if (searchInput) searchInput.value = '';
    searchClearBtn?.classList.add('hidden');
    renderCatalogView();
  });

  // Product Detail Controls
  document.getElementById('detail-qty-minus')?.addEventListener('click', () => {
    if (state.detailQty > 1) {
      state.detailQty -= 1;
      document.getElementById('detail-qty-value').textContent = String(state.detailQty);
    }
  });
  document.getElementById('detail-qty-plus')?.addEventListener('click', () => {
    state.detailQty += 1;
    document.getElementById('detail-qty-value').textContent = String(state.detailQty);
  });
  document.getElementById('detail-add-cart-btn')?.addEventListener('click', () => {
    addToCart(state.activeDetailId, state.detailQty);
  });
  document.getElementById('detail-buy-now-btn')?.addEventListener('click', () => {
    addToCart(state.activeDetailId, state.detailQty);
    navigateTo('checkout');
  });
  document.getElementById('detail-wishlist-btn')?.addEventListener('click', () => {
    toggleWishlist(state.activeDetailId);
  });

  // Cart Promo Code & Proceed to Checkout
  document.getElementById('promo-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const code = document.getElementById('promo-input').value.trim().toUpperCase();
    const feedback = document.getElementById('promo-feedback');
    if (code === 'FOOD10') {
      state.promoApplied = true;
      feedback.textContent = 'Promo code FOOD10 applied (extra 10% off)!';
      feedback.style.color = 'var(--accent-green)';
      feedback.classList.remove('hidden');
      renderCartView();
    } else {
      state.promoApplied = false;
      feedback.textContent = 'Invalid code. Try FOOD10 for an extra 10% off.';
      feedback.style.color = 'var(--accent-red)';
      feedback.classList.remove('hidden');
      renderCartView();
    }
  });

  document.getElementById('proceed-checkout-btn')?.addEventListener('click', () => {
    navigateTo('checkout');
  });

  // Checkout Form Submission
  document.getElementById('checkout-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const errorBanner = document.getElementById('checkout-error');

    const name = document.getElementById('checkout-name').value.trim();
    const phone = document.getElementById('checkout-phone').value.trim();
    const email = document.getElementById('checkout-email').value.trim();
    const addressLine = document.getElementById('checkout-address').value.trim();
    const city = document.getElementById('checkout-city').value.trim();
    const pincode = document.getElementById('checkout-pincode').value.trim();
    const paymentRadio = document.querySelector('input[name="paymentMethod"]:checked');
    const paymentMethod = paymentRadio ? paymentRadio.value : 'UPI';

    if (!name || !/^\d{10}$/.test(phone) || !email.includes('@') || !addressLine || !city || !/^\d{6}$/.test(pincode)) {
      errorBanner.textContent =
        'Please complete all fields with a valid 10-digit mobile number, email, and 6-digit pincode.';
      errorBanner.classList.remove('hidden');
      return;
    }

    errorBanner.classList.add('hidden');
    const totals = calculateCartTotals();

    const orderItems = state.cart
      .map((entry) => {
        const prod = getProductById(entry.id);
        return prod ? { id: prod.id, name: prod.name, qty: entry.qty, price: prod.finalPrice } : null;
      })
      .filter(Boolean);

    const newOrder = {
      id: `FN-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
      status: 'Confirmed · Preparing',
      customerName: name,
      phone,
      paymentMethod,
      address: `${addressLine}, ${city} - ${pincode}`,
      items: orderItems,
      total: totals.finalTotal,
    };

    state.orders.unshift(newOrder);
    state.lastConfirmedOrder = newOrder;
    state.cart = [];
    state.promoApplied = false;

    saveToStorage(STORAGE_KEYS.ORDERS, state.orders);
    saveToStorage(STORAGE_KEYS.CART, state.cart);
    updateHeaderBadges();
    navigateTo('order-confirmation');
  });

  // Account Forms & Logout
  document.getElementById('profile-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    state.user.name = document.getElementById('profile-name').value.trim();
    state.user.phone = document.getElementById('profile-phone').value.trim();
    state.user.email = document.getElementById('profile-email').value.trim();
    saveToStorage(STORAGE_KEYS.USER, state.user);
    updateHeaderBadges();
    renderAccountView();
    showToast('Profile updated successfully');
  });

  document.getElementById('add-address-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const label = document.getElementById('addr-label').value.trim();
    const city = document.getElementById('addr-city').value.trim();
    const line = document.getElementById('addr-line').value.trim();
    const pincode = document.getElementById('addr-pincode').value.trim();

    if (!label || !city || !line || !pincode) return;

    state.user.addresses.push({
      id: `addr-${Date.now()}`,
      label,
      city,
      line,
      pincode,
      isDefault: false,
    });
    saveToStorage(STORAGE_KEYS.USER, state.user);
    e.target.reset();
    renderAccountAddresses();
    showToast('New delivery address added');
  });

  document.getElementById('logout-btn')?.addEventListener('click', () => {
    state.user.isLoggedIn = false;
    saveToStorage(STORAGE_KEYS.USER, state.user);
    updateHeaderBadges();
    renderAccountView();
    showToast('Logged out of FoodNest');
  });

  document.getElementById('login-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    state.user.isLoggedIn = true;
    state.user.name = document.getElementById('login-name').value.trim() || 'FoodNest Guest';
    state.user.email = document.getElementById('login-email').value.trim() || 'guest@foodnest.example';
    saveToStorage(STORAGE_KEYS.USER, state.user);
    updateHeaderBadges();
    renderAccountView();
    showToast(`Welcome back, ${state.user.name}!`);
  });

  // Mobile Drawer Controls
  document.getElementById('mobile-menu-btn')?.addEventListener('click', openMobileDrawer);
  document.getElementById('mobile-drawer-close')?.addEventListener('click', closeMobileDrawer);
  document.getElementById('drawer-backdrop')?.addEventListener('click', closeMobileDrawer);

  // Location Picker Modal Controls
  document.getElementById('location-btn')?.addEventListener('click', openLocationModal);
  document.getElementById('mobile-location-btn')?.addEventListener('click', () => {
    closeMobileDrawer();
    openLocationModal();
  });
  document.getElementById('location-modal-close')?.addEventListener('click', closeLocationModal);
  document.getElementById('location-modal')?.addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeLocationModal();
  });

  document.querySelectorAll('.city-preset-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.user.location = btn.getAttribute('data-city') || 'Bengaluru 560001';
      saveToStorage(STORAGE_KEYS.USER, state.user);
      updateHeaderBadges();
      closeLocationModal();
      showToast(`Delivery location set to ${state.user.location}`);
    });
  });

  document.getElementById('custom-location-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.getElementById('custom-location-input');
    const val = input.value.trim();
    if (!val) return;
    state.user.location = val;
    saveToStorage(STORAGE_KEYS.USER, state.user);
    updateHeaderBadges();
    input.value = '';
    closeLocationModal();
    showToast(`Delivery location set to ${val}`);
  });

  // Newsletter Form
  document.getElementById('newsletter-form')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const emailInput = document.getElementById('newsletter-email');
    const feedback = document.getElementById('newsletter-feedback');
    if (!emailInput.value.trim()) return;
    feedback.textContent = `Subscribed ${emailInput.value.trim()}! Use code FOOD10 at checkout.`;
    feedback.classList.remove('hidden');
    emailInput.value = '';
  });
}

// Initialize FoodNest on DOM load
function initApp() {
  renderCategories();
  renderHomeDeals();
  renderHomeProducts();
  updateHeaderBadges();
  bindEvents();
}

initApp();
